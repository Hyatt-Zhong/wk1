#include<stdlib.h>
#include<stdio.h>

#include"foo.h"
typedef void (*pfn)(int i);

int main()
{
    printf("hello\n");
    printf("%d\n",add(3,4));
    pfn pi=0;
    pi(2);    
    return 0;
}