#include "ffmpeg_codec.h"
#include "codec/frame_video.h"
#include "pw_split_video.h"
#include "pw_base_api.h"
#include "pw_typedef.h"

void PwFFmpegCodec::stop()
{
	std::lock_guard<std::mutex> lockGuard(playMutex);
	if(playState == State::Configed) {
		av_frame_free(&videoFrame);
		avcodec_free_context(&videoCodecContext);
		playState = State::Inited;
	}
}

int PwFFmpegCodec::config(int enc_type, int width, int height)
{
	std::lock_guard<std::mutex> lockGuard(playMutex);
    if (playState != State::Inited) {
        printf("PwFFmpegCodec::config - not inited\n");
        return -1;
    }

    mEncType = enc_type;
    lastWidth = width;
    lastHeight = height;

    if (mEncType == PSV_ENC_H264) {
        videoCodec = const_cast<AVCodec *>(avcodec_find_decoder(AV_CODEC_ID_H264));
    } else if (mEncType == PSV_ENC_H265) {
        videoCodec = const_cast<AVCodec *>(avcodec_find_decoder(AV_CODEC_ID_H265));
    } else {
        printf("PwFFmpegCodec::config - unsupported stream type (encType=%d)\n", mEncType);
        return -1;
    }

    if(!videoCodec) {
        printf("PwFFmpegCodec::config - avcodec_find_decoder failed (encType=%d)\n", mEncType);
        return -1;
    }

    videoCodecContext = avcodec_alloc_context3(videoCodec);
    if(!videoCodecContext) {
        printf("PwFFmpegCodec::config - avcodec_alloc_context3 failed\n");
        return -1;
    }
//		videoCodecContext->pix_fmt = AV_PIX_FMT_NV12;
//		videoCodecContext->get_format = PwFFmpegCodec::getOutFormat;

    videoFrame = av_frame_alloc();
    if(!videoFrame) {
        printf("PwFFmpegCodec::config - av_frame_alloc failed\n");
        return -1;
    }

    int ret = avcodec_open2(videoCodecContext, videoCodec, nullptr);
    if(ret < 0) {
        printf("PwFFmpegCodec::config - avcodec_open2 failed (ret=%d)\n", ret);
        return -1;
    }

    playState = State::Configed;

    return 0;
}

int PwFFmpegCodec::inputData(PwFrameVideo *pData, GVM_SCREEN **out)
{
	std::lock_guard<std::mutex> lockGuard(playMutex);
	if(playState != State::Configed) {
		//未被正确初始化
		printf("PwFFmpegCodec::inputData - not configed\n");
		return -1;
	}
	AVPacket pkt;
	av_init_packet(&pkt);
	pkt.data = pData->data;
	pkt.size = pData->dataLength;

	//把数据放进系统的软解码器里
	int sendResult = avcodec_send_packet(videoCodecContext, &pkt);
	if (sendResult < 0) {
        printf("avcodec_send_packet failed: %d\n", sendResult);
    }

	//取出解码数据
	int ret = avcodec_receive_frame(videoCodecContext, videoFrame);
	if (ret < 0) {
        printf("avcodec_send_packet failed: %d\n", ret);
        return -1;
	}

	// 软解默认是YUV420P，但h265可能解出YUVJ420P
	if(videoFrame->format == AV_PIX_FMT_YUV420P || videoFrame->format == AV_PIX_FMT_YUVJ420P) {
        int width = videoFrame->width;
		int height = videoFrame->height;

		GVM_SCREEN *yuv = pwbCreateImage(width, height, VM_FORMAT_YUV420_P);

		int offset = 0;
        for (int i = 0; i < height; i++) {
			memcpy((uint8_t *)yuv->PixelArray.planar.pPixelArray[0] + offset,
				   videoFrame->data[0] + i * videoFrame->linesize[0], width);
			offset += width;
        }

		offset = 0;
        for (int i = 0; i < height / 2; i++) {
            memcpy((uint8_t *)yuv->PixelArray.planar.pPixelArray[1] + offset,
				   videoFrame->data[1] + i * videoFrame->linesize[1], width / 2);
            offset += width / 2;
        }

		offset = 0;
        for (int i = 0; i < height / 2; i++) {
            memcpy((uint8_t *)yuv->PixelArray.planar.pPixelArray[2] + offset,
				   videoFrame->data[2] + i * videoFrame->linesize[2], width / 2);
            offset += width / 2;
        }

        *out = yuv;
	} else {
		printf("PwFFmpegCodec::inputData - decode unsupported format (%d)\n", videoFrame->format);
		return -1;
	}

	return 0;
}

void PwFFmpegCodec::flush () {
    avcodec_send_packet(videoCodecContext, nullptr);
    while (avcodec_receive_frame(videoCodecContext, videoFrame) != AVERROR_EOF) {}
    avcodec_flush_buffers(videoCodecContext);
}
