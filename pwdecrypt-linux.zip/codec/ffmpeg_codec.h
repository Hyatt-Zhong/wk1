#ifndef ANDROIDSDK_PWFFMPEGCODEC_H
#define ANDROIDSDK_PWFFMPEGCODEC_H

extern "C" {
#include "libavcodec/avcodec.h"
#include "libswscale/swscale.h"
};

#include <mutex>
#include "frame_video.h"
#include "pw_typedef.h"

class PwFFmpegCodec
{
private:
    enum class State {
        Inited,
        Configed,
    };

    std::mutex playMutex;
    State playState = State::Inited;

    AVCodec *videoCodec;
    AVCodecContext *videoCodecContext;

    AVFrame *videoFrame;

    int mEncType;
    int lastWidth;
    int lastHeight;

  public:
    ~PwFFmpegCodec () {}

    int config(int enc_type, int width, int height);
    void stop();
    void flush();
    int inputData(PwFrameVideo *data, GVM_SCREEN **out);
    bool isConfiged() { return playState == State::Configed; }
};

#endif //ANDROIDSDK_PWFFMPEGCODEC_H
