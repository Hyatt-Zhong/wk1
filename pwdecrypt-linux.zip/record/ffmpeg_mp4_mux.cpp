#include "ffmpeg_mp4_mux.h"
#include "pw_split_video.h"

void FFMPEGMP4Mux::setVideoRotate(){
    //设置视频旋转角度
    //如果不是这三个角度 不用设置
    if (!strcmp(m_rotate, "90") || !strcmp(m_rotate, "180") || !strcmp(m_rotate, "270")) {
         av_dict_set(&m_video_stream->metadata,"rotate",m_rotate,0);
    }
}

void FFMPEGMP4Mux::setvideoExtraData(){
//    printf("setvideoExtraData len:%d \n", m_extraDataLen);
    m_video_stream->codecpar->extradata_size = m_extraDataLen;
    uint8_t* resultd = (uint8_t*)av_malloc(m_extraDataLen);
    memcpy(resultd, m_extraData, m_extraDataLen);
    m_video_stream->codecpar->extradata = resultd;

}

bool FFMPEGMP4Mux::createVideoStream(int encType){
    m_video_stream = avformat_new_stream(m_formatCxt, NULL);
    if (!m_video_stream) {
        printf("FFMPEGMP4Mux::createVideoStream - create video stream failed");
        return false;
    }

    m_video_stream->time_base = (AVRational){ 1, m_fps };
    m_video_baseTime = m_video_stream->time_base;
    
    m_video_stream->codecpar->codec_tag = 0;
        //Mp4等容器需要一个global header
//    m_video_stream->codecpar->flags |= AV_CODEC_FLAG_GLOBAL_HEADER ;

    m_video_stream->codecpar->bit_rate = 512000;
    m_video_stream->codecpar->codec_type = AVMEDIA_TYPE_VIDEO;
    m_video_stream->codecpar->codec_id = encType == PSV_ENC_H265 ? AV_CODEC_ID_H265 : AV_CODEC_ID_H264;
    m_video_stream->codecpar->width = m_videoWidth;
    m_video_stream->codecpar->height = m_videoHeight;
    m_video_stream->codecpar->format = AV_PIX_FMT_YUV420P;

    setVideoRotate();
    return true;
}

bool FFMPEGMP4Mux::createAudioStream(){
    m_audio_stream = avformat_new_stream(m_formatCxt, NULL);
    if (m_audio_stream == NULL) {
        printf("FFMPEGMP4Mux::createAudioStream - create audio stream failed");
        return false;
    }

    m_audio_stream->time_base = (AVRational){ 1, SAMPLE_RATE };
    m_audio_baseTime = m_audio_stream->time_base;
    AVCodecParameters *codecPar = m_audio_stream->codecpar;
    codecPar->sample_rate = SAMPLE_RATE;
//    codecPar->flags |= AV_CODEC_FLAG_GLOBAL_HEADER ;

    //AVSampleFormat
    codecPar->codec_type = AVMEDIA_TYPE_AUDIO;
    codecPar->codec_id = AV_CODEC_ID_AAC;
    codecPar->format = AV_SAMPLE_FMT_FLTP;
    codecPar->bit_rate = 48000;//
    codecPar->channels = CHANAELS_NUM;
    codecPar->channel_layout = 3;
    codecPar->frame_size = 1024;

    //AAC BITSTREAM INIT
    //    https://blog.csdn.net/weiyuefei/article/details/68067944
//    m_aacbsfc = av_bitstream_filter_init("aac_adtstoasc");

//    Use av_bsf_get_by_name(), av_bsf_alloc(), and av_bsf_init()

    const AVBitStreamFilter *bitStreamFilter = av_bsf_get_by_name("aac_adtstoasc");
    av_bsf_alloc(bitStreamFilter, &m_bsfCtx);
    m_bsfCtx->par_in->codec_id = AV_CODEC_ID_AAC;
    av_bsf_init(m_bsfCtx);

    return true;
}

//音频的码率=采样率（44.1k）*位深度（16）*通道数（2）
bool FFMPEGMP4Mux::initFaacEncoder(){
    int nPCMBitSize = 16;
    //
    m_hAACEncoder = faacEncOpen(SAMPLE_RATE, CHANAELS_NUM, &m_nAACInputSamples, &m_nAACMaxOutputBytes);
//    printf("initFaacEncoder m_nAACInputSamples:%lu m_nAACMaxOutputBytes：%lu \n",m_nAACInputSamples,m_nAACMaxOutputBytes);
    m_nPCMBufferSize = m_nAACInputSamples * nPCMBitSize / 8;
    m_pbPCMBuffer = new GUInt8 [m_nPCMBufferSize];
    m_pbAACBuffer = new GUInt8 [m_nAACMaxOutputBytes];
    if(m_hAACEncoder == NULL)
    {
        printf("FFMPEGMP4Mux::initFaacEncoder - Failed to call faacEncOpen()");
        return false;
    }
    // (2.1) Get current encoding configuration
    m_pAACConfiguration = faacEncGetCurrentConfiguration(m_hAACEncoder);
    m_pAACConfiguration->outputFormat = 1;//0表示裸流数据 1表示带ADTS头的AAC数据
    m_pAACConfiguration->useTns = 1/*true*/;
    m_pAACConfiguration->allowMidside = 1;
    m_pAACConfiguration->inputFormat = FAAC_INPUT_16BIT;
    m_pAACConfiguration->useLfe = 0/*false*/;
    m_pAACConfiguration->aacObjectType = LOW;
    m_pAACConfiguration->shortctl = SHORTCTL_NORMAL;
    m_pAACConfiguration->quantqual = 500;
    m_pAACConfiguration->bitRate = 48000;
    m_pAACConfiguration->bandWidth = 32000;
    m_pAACConfiguration->mpegVersion = MPEG4;

    // (2.2) Set encoding configuration
    faacEncSetConfiguration(m_hAACEncoder, m_pAACConfiguration);
    //
    return true;
}
void FFMPEGMP4Mux::closeFAACEncoder(){
    if(m_pbPCMBuffer){
        delete[] m_pbPCMBuffer;
        m_pbPCMBuffer = nullptr;
    }
    if (m_pbAACBuffer) {
        delete[] m_pbAACBuffer;
        m_pbAACBuffer = nullptr;
    }
    if (m_hAACEncoder) {
        faacEncClose(m_hAACEncoder);
        m_hAACEncoder = nullptr;
    }
}

bool FFMPEGMP4Mux::initFormatContext(){
    
    avformat_alloc_output_context2(&m_formatCxt, NULL, NULL, m_filename);
    if (!m_formatCxt) {
//        printf("Could not deduce output format from file extension: using MPEG.\n");
        avformat_alloc_output_context2(&m_formatCxt, NULL, "mpeg", m_filename);
    }
    
    if (!m_formatCxt)
        return false;
    
    m_outfmt = m_formatCxt->oformat;
    
    return true;
}

bool FFMPEGMP4Mux::opneFileAndWriteHeader(){
    int ret;
    av_dump_format(m_formatCxt, 0, m_filename, 1);
    /* open the output file, if needed */
    if (!(m_outfmt->flags & AVFMT_NOFILE)) {
        ret = avio_open(&m_formatCxt->pb, m_filename, AVIO_FLAG_WRITE);
        if (ret < 0) {
//            fprintf(stderr, "Could not open '%s': %s\n", m_filename,
//                    av_err2str(ret));
            return false;
        }
    }
    /* Write the stream header, if any. */
    ret = avformat_write_header(m_formatCxt, NULL);
    if (ret < 0) {
//        fprintf(stderr, "Error occurred when opening output file: %s\n",
//                av_err2str(ret));
        return false;
    }
    
    return true;
}

void FFMPEGMP4Mux::initStream(int encType){
    bool creVSuc = createVideoStream(encType);

    bool creASuc = createAudioStream();
    
    bool openSuc = opneFileAndWriteHeader();

    printf("FFMPEGMP4Mux::initStream type=%d, cv=%d, ca=%d,open=%d", encType, creVSuc, creASuc, openSuc);
    if (creVSuc && creASuc && openSuc) {
        m_initStream = true;
    }
}

bool FFMPEGMP4Mux::writeVideoFrame(const char*  data, int nLen,bool keyFrame){
    int ret;
    AVPacket pkt;
    av_init_packet( &pkt );
    pkt.flags |=  keyFrame ? AV_PKT_FLAG_KEY : 0;
    pkt.data = (uint8_t*)data;
    pkt.size = nLen;
    //没有B帧 直接按顺序展示
    pkt.dts = m_vdts;
    pkt.pts = m_vpts;
    m_vdts ++ ;
    m_vpts ++ ;
    av_packet_rescale_ts(&pkt, m_video_baseTime, m_video_stream->time_base);
    pkt.stream_index = m_video_stream->index;
    ret = av_interleaved_write_frame(m_formatCxt, &pkt );
    av_packet_unref(&pkt);
    if (ret < 0) {
//        printf("cannot write frame");
    }
    return true;
}

bool FFMPEGMP4Mux::writeAudioFrame(const char*  data, int nLen){
    AVPacket pkt = { 0 }; // data and size must be 0;
    int ret;
    //    int dst_nb_samples;
    av_init_packet(&pkt);
    
    uint8_t *pData = (uint8_t *)data;
    int iLen = nLen;
    
//    if (pData[0] == 0xff && (pData[1]&0xf0) == 0xf0) {
//        printf("111111wrireAudioFrame 0xFFF\n");
//    }
    
    pkt.size = iLen;
    pkt.data = pData;
    
    //
//    av_bitstream_filter_filter(m_aacbsfc, m_audio_stream->codec, NULL, &pkt.data, &pkt.size, pkt.data, pkt.size, 0);
//     Use av_bsf_send_packet() and av_bsf_receive_packet()
    av_bsf_send_packet(m_bsfCtx, &pkt);
    av_bsf_receive_packet(m_bsfCtx, &pkt);
    
    //    取number_of_raw_data_blocks_in_frame ADTS 一般7个字节 也可能9个字节
    //    https://www.jianshu.com/p/b5ca697535bd
    uint8_t frameSampleLength = pData[6];
    frameSampleLength = frameSampleLength & 0x3;//取最后两个bit
    frameSampleLength += 1;
    m_adts += 1024 * frameSampleLength;
    m_apts += 1024 * frameSampleLength;
    
//    printf("wrireAudioFrame:%d==%d \n",frameSampleLength,nLen);
    
    pkt.dts = m_adts;
    pkt.pts = m_apts;
    pkt.duration = 1024 * frameSampleLength;
    
    //    printf("dts  %d  ",pkt.dts);
    //    printf("pts  %d  ",pkt.pts);
    
    //    ret = write_frame(oc, &c->time_base, ost->st, &pkt);
    
    av_packet_rescale_ts(&pkt, m_audio_baseTime, m_audio_stream->time_base);
    pkt.stream_index = m_audio_stream->index;
    ret = av_interleaved_write_frame(m_formatCxt, &pkt);
    if (ret < 0) {
//        fprintf(stderr, "%d======failed error while writing audio frame: %s\n",nLen,av_err2str(ret));
        m_adts -= 1024 * frameSampleLength;
        m_apts -= 1024 * frameSampleLength;
        return false;
    }
    return true;
}

bool FFMPEGMP4Mux::encodePCMToAAC(char* buff,long len){
    //    printf("pcmToAACEncode len:%d MaxpcmBUfflen:%d m_nRecordPos:%d\n",len,m_nPCMBufferSize,m_nRecordPos);
    int nRet = 0;
    int pcmBufferLeftLen = m_nPCMBufferSize - m_nRecordPos;
    if ((m_nRecordPos+len)>=m_nPCMBufferSize) {
        memcpy(m_pbPCMBuffer+m_nRecordPos, buff, pcmBufferLeftLen);
        //这里的样本数是m_pbPCMBuffer缓冲区实际数据大小的一半(根据声道计算)，样本数必须大于一定的值，暂时定1024，这个是faac打开的时候获取的，较小的值不行，压缩后的声音不对,因为编码后如果样本数不到1024个会在编码好的数据后自动补0(源代码中看到)
        nRet = faacEncEncode( m_hAACEncoder, (int*)m_pbPCMBuffer, m_nAACInputSamples, m_pbAACBuffer, m_nAACMaxOutputBytes);
        if(nRet>0){
            //这是一帧AAC音频 带ADTS config中设置outputFormat
            writeAudioFrame((char*)m_pbAACBuffer, nRet);
        }else{
//            printf("faacEncEncode err \n");
        }
        m_nRecordPos=0;
        //        printf("pcmBufferLeftLen == %d\n",pcmBufferLeftLen);
        encodePCMToAAC(buff+pcmBufferLeftLen,len-pcmBufferLeftLen);
    } else {
        memcpy(m_pbPCMBuffer+m_nRecordPos, buff, len);
        m_nRecordPos += len;
    }
    return true;
}

/**************************************************************/
bool FFMPEGMP4Mux::FFMPEG_StartWrite(const char *filename,const char *rotate)
{
    m_nRecordPos = 0;
    
    m_videoWidth = 0;
    m_videoHeight = 0;
    m_fps = 0;
    m_lastVideoHei = 0;
    m_lastVideowid = 0;
    m_lastfps = 0;

    m_extraDataLen = 0;
    
    m_vdts = 0;
    m_vpts = 0;
    m_adts = 0;
    m_apts = 0;
    
    m_initStream = false;
    m_isGetExtra = false;
    m_bSetExtra = false;
    m_bStop = false;
    
    memset(m_filename,0, MAX_FILE_NAME_LEN);
    memcpy(m_filename,filename,strlen(filename));
    
    memset(m_rotate,0,sizeof(m_rotate));
    memcpy(m_rotate,rotate,strlen(rotate));
    
    initFormatContext();
    
    initFaacEncoder();
    
    return true;
}

bool FFMPEGMP4Mux::FFMPEG_InputData(const char*  data, int nLen, MP4_MUX_FRAME_TYPE type, MP4_MUX_STREAM_INFO *info, const char* extraData, int extraDataLen)
{
    if (m_bStop)
        return false;

    mutexStopWrite.lock();
    std::lock_guard<std::recursive_mutex> lck(mutexStopWrite, std::adopt_lock);
   
    //*********************init stream*********************
    if (!m_initStream && info->fps > 0 && info->frameWidth > 0 && info->frameHeight > 0) {
        
        m_videoWidth = info->frameWidth;
        m_videoHeight = info->frameHeight;
        m_fps = info->fps;
        
        m_lastfps =  info->fps;
        m_lastVideowid = info->frameWidth;
        m_lastVideoHei = info->frameHeight;

        initStream(info->encType);
    }

//    if (!m_initStream) {
//        ALOGW("FFMPEGMP4Mux::FFMPEG_InputData frameType=%d, m_videoWidth:%d m_videoHeight:%d m_fps:%d\n",
//              type, info->frameWidth, info->frameHeight, info->fps);
//    }
    
    //检测视频码流 是否发生变化
    if (m_initStream && info->fps > 0 && info->frameWidth > 0 && info->frameHeight > 0) {
        if (m_lastfps != info->fps) {
            if (m_ffmpegMp4WriteEventCallback) {
                char msg[] = "MP4_RECORDER_FRAME_SIZE_CHANGED";
                m_ffmpegMp4WriteEventCallback(msg, m_ffmpegMp4WriteEventUserData);
            }
        } else if (m_lastVideowid != info->frameWidth || m_lastVideoHei != info->frameHeight) {
            if (m_ffmpegMp4WriteEventCallback) {
                char msg[] = "MP4_RECORDER_FRAME_SIZE_CHANGED";
                m_ffmpegMp4WriteEventCallback(msg, m_ffmpegMp4WriteEventUserData);
            }
            return false;
        }
    }
    //*********************init stream********************************
    
    if (!m_initStream) {
        printf("FFMPEGMP4Mux::FFMPEG_InputData - videostream & audiostream not set\n");
        return false;
    }

    if (extraData && extraDataLen > 0) {
        m_extraDataLen = extraDataLen;
        memcpy(m_extraData, extraData, m_extraDataLen);
        m_isGetExtra = true;
    }

    if (!m_isGetExtra) {
        printf("FFMPEGMP4Mux::FFMPEG_InputData - extra is NOT GETTED");
        return false;
    }

    if (!m_bSetExtra) {
        setvideoExtraData();
        m_bSetExtra = true;
    }
    //*********************extra data********************************
    
    if ((type == MP4_MUX_FRAME_TYPE_I || type == MP4_MUX_FRAME_TYPE_P)) {
        bool keyFrame = false;
        int indxData = 0;
        if (type == MP4_MUX_FRAME_TYPE_I) {
            int indexData = getH264IFrameIndex((char *)data,nLen);
            if(indexData!=-1) {
                indxData =  indexData;
            }
            keyFrame = true;
        }
        if (type == MP4_MUX_FRAME_TYPE_P) {
            int indexData = getH264TypeFrameIndex((char *)data,nLen,CODEC_H264_NAL_P);
            if(indexData!=-1) {
                indxData =  indexData;
            }
        }
        writeVideoFrame(data+indxData, nLen-indxData, keyFrame);
    }
    
    if(type == MP4_MUX_FRAME_TYPE_G711A) {
//        char dst[nLen*2];
//        int  dstLen = 0;
        //G711A -> PCM
//        mp4_g711a_Decode((unsigned char *)data,dst,nLen,&dstLen);
        
        //PCM -> AAC
        encodePCMToAAC((char *)data, nLen);
    }
    
    return true;
}

bool FFMPEGMP4Mux::FFMPEG_StopWrite()
{
    mutexStopWrite.lock();
    std::lock_guard<std::recursive_mutex> lck(mutexStopWrite, std::adopt_lock);
    m_bStop = true;
    ///
    if (m_formatCxt && m_initStream) {
        av_write_trailer(m_formatCxt);
        av_bsf_free(&m_bsfCtx);
    }
    /// Free m_formatCxt
    if( m_formatCxt ) {
//        av_bitstream_filter_close(m_aacbsfc);
        avio_close(m_formatCxt->pb);
        avformat_free_context(m_formatCxt);
        m_formatCxt = NULL;
    }

    closeFAACEncoder();
    
    return true;
}
