
#include "pw_split_video.h"
#include <string.h>
#include "sei_read/pw_sei_read.h"
#include "h264parse/h264parse.h"
#include "h265parse/h265parse.h"
#include "pw_mem.h"

enum HEVCNALUnitType {
	HEVC_NAL_TRAIL_N    = 0,
	HEVC_NAL_TRAIL_R    = 1,
	HEVC_NAL_TSA_N      = 2,
	HEVC_NAL_TSA_R      = 3,
	HEVC_NAL_STSA_N     = 4,
	HEVC_NAL_STSA_R     = 5,
	HEVC_NAL_RADL_N     = 6,
	HEVC_NAL_RADL_R     = 7,
	HEVC_NAL_RASL_N     = 8,
	HEVC_NAL_RASL_R     = 9,
	HEVC_NAL_VCL_N10    = 10,
	HEVC_NAL_VCL_R11    = 11,
	HEVC_NAL_VCL_N12    = 12,
	HEVC_NAL_VCL_R13    = 13,
	HEVC_NAL_VCL_N14    = 14,
	HEVC_NAL_VCL_R15    = 15,
	HEVC_NAL_BLA_W_LP   = 16,
	HEVC_NAL_BLA_W_RADL = 17,
	HEVC_NAL_BLA_N_LP   = 18,
	HEVC_NAL_IDR_W_RADL = 19,
	HEVC_NAL_IDR_N_LP   = 20,
	HEVC_NAL_CRA_NUT    = 21,
	HEVC_NAL_IRAP_VCL22 = 22,
	HEVC_NAL_IRAP_VCL23 = 23,
	HEVC_NAL_RSV_VCL24  = 24,
	HEVC_NAL_RSV_VCL25  = 25,
	HEVC_NAL_RSV_VCL26  = 26,
	HEVC_NAL_RSV_VCL27  = 27,
	HEVC_NAL_RSV_VCL28  = 28,
	HEVC_NAL_RSV_VCL29  = 29,
	HEVC_NAL_RSV_VCL30  = 30,
	HEVC_NAL_RSV_VCL31  = 31,
	HEVC_NAL_VPS        = 32,
	HEVC_NAL_SPS        = 33,
	HEVC_NAL_PPS        = 34,
	HEVC_NAL_AUD        = 35,
	HEVC_NAL_EOS_NUT    = 36,
	HEVC_NAL_EOB_NUT    = 37,
	HEVC_NAL_FD_NUT     = 38,
	HEVC_NAL_SEI_PREFIX = 39,
	HEVC_NAL_SEI_SUFFIX = 40,
};

typedef struct _psv_jpg_tail_ptz_pano_
{
	GUInt32		ulVersion		:10;	//	= 03
	GUInt32		ulTailSize		:8;		//	ulVersion == 03 : ulTailSize = 8;
	GUInt32		ulBeDownward	:1;		//	ulVersion == 03 : ulTailSize = 8;
	GUInt32		ulPanHalfRange	:8;		//	0~180 : Pan range is 180 - ulPanHalfRange ~ 180 + ulPanHalfRange
	GUInt32		ulExten : 5;
	GUInt16		usTopTilt_10;			//	( -180~180 + 180 ) *10
	GUInt16		usBtmTilt_10;			//	( -180~180 + 180 ) *10
}PSV_JPG_TAIL_PTZ_PANO;	//	8 Bytes

typedef struct _psv_nal_p_
{
	GUInt8*	pbyS;
	GInt32	lType;	// 1-PNal, 6-SEI, 16-PWSei, 5-INal, 7-SPS, 8-PPS
	GInt32	lLen;
	GInt32	lOff;
}PSV_NAL_P;

static PSV_ENC_TYPE _CheckEncBrief( GUInt8 *pbyData, GInt32 lDataLen )
{
	GUInt32 i, ulH, ulFlag=0;
	PSV_ENC_TYPE eRes = PSV_ENC_UNKNOWN;

	for(i=0; i<4; i++){
		GUInt32 ulV = pbyData[i];
		ulFlag = (ulFlag << 8) + ulV;
	}
	PW_CHK_N( ERREXT, ulFlag, 0x01 );

	ulH	= (pbyData[4] & 0x7E) >> 1;
	if( HEVC_NAL_SEI_PREFIX == ulH && 0x01 == pbyData[5] )
		eRes = PSV_ENC_H265;
	else if( 6 == pbyData[4] && 0xf0 == pbyData[5] )
		eRes = PSV_ENC_H264;
	else
		goto ERREXT;

ERREXT:
	return eRes;
}

static PSV_ENC_TYPE _CheckEncBrief_sps( GUInt8 *pbyData, GInt32 lDataLen )
{
	GUInt32 i, ulH, ulFlag=0;
	PSV_ENC_TYPE eRes = PSV_ENC_UNKNOWN;

	for(i=0; i<4; i++){
		GUInt32 ulV = pbyData[i];
		ulFlag = (ulFlag << 8) + ulV;
	}
	PW_CHK_N( ERREXT, ulFlag, 0x01 );

	ulH	= (pbyData[4] & 0x7E) >> 1;
	if( HEVC_NAL_SPS == ulH && 0x01 == pbyData[5] )
		eRes = PSV_ENC_H265;
	else if( 7 == ( pbyData[4] & 0x1f ) )
		eRes = PSV_ENC_H264;
	else
		goto ERREXT;

ERREXT:
	return eRes;
}



PSV_ENC_TYPE _CheckEnc( GUInt8 *pbyData, GInt32 lDataLen )
{
	PSV_ENC_TYPE eRes = PSV_ENC_UNKNOWN;
	GInt32 i, lOff, lMax = PW_MIN( 256, lDataLen-16 );
	GUInt8 *pbyCur, *pbyStart;
	GUInt32 ulFlag;

	pbyCur = pbyData;
	ulFlag = 0xffffffff;
	for( i=0; i<lMax; i++, pbyCur++ )
	{
		GUInt8 byVal = *pbyCur, byHead, byHead2, byHead3;
		ulFlag = ( ulFlag << 8 ) + byVal;

		if( (ulFlag & 0xffffff) == 0x01 )
		{
			lOff = ulFlag & 0xff000000 ? 2 : 3;
			pbyStart = pbyCur - lOff;
			lOff = i - lOff;
			byHead	= ( pbyCur[1] & 0x7E ) >> 1;
			byHead2	= pbyCur[2];
			byHead3	= pbyCur[3];
			if( 0x01 == byHead2 &&
               ( HEVC_NAL_SEI_PREFIX == byHead ||
                HEVC_NAL_VPS == byHead ||
                HEVC_NAL_SPS == byHead ||
                HEVC_NAL_IDR_W_RADL == byHead ||
                HEVC_NAL_TRAIL_R == byHead ||
                HEVC_NAL_PPS == byHead
                )){
				eRes = PSV_ENC_H265;
				goto EXT;
			}
		}
	}

	pbyCur = pbyData;
	ulFlag = 0xffffffff;
	for( i=0; i<lMax; i++, pbyCur++ )
	{
		GUInt8 byVal = *pbyCur, byHead, byHead2;
		ulFlag = ( ulFlag << 8 ) + byVal;

		if( (ulFlag & 0xffffff) == 0x01 )
		{
			lOff = ulFlag & 0xff000000 ? 2 : 3;
			pbyStart = pbyCur - lOff;
			lOff = i - lOff;
			byHead	= pbyCur[1] & 0x1f;
			byHead2	= pbyCur[2];

			if( 6 == byHead || 7 == byHead || 8 == byHead || 1 == byHead || 5 == byHead){
				eRes = PSV_ENC_H264;
				goto EXT;
			}
		}
	}

	EXT:
	return eRes;
}

static GVoid _ParseH264( GUInt8 *pbyData, GInt32 lBufflen, PSV_VIDEO_NAL *pstOut )
{
	GInt32 lNalPNum=0, i, lOff, l0N, lMax = lBufflen-2;//PW_MIN( 1024, lBufflen-16 );
	GUInt8 *pbyCur = pbyData, *pbyStart;
	GUInt32 ulFlag = 0xffffffff;
	GBool bPwSEI=GFalse;
	PSV_NAL_P astNalP[10]={0};

	for( i=0; i<lMax; i++, pbyCur++ )
	{
		GUInt8 byVal = *pbyCur, byHead, byHead2;
		ulFlag = ( ulFlag << 8 ) + byVal;

		if( (ulFlag & 0xffffff) == 0x01 )
		{
			l0N = ulFlag & 0xff000000 ? 2 : 3;
			pbyStart = pbyCur - l0N;
			lOff = i - l0N;
			byHead	= pbyCur[1] & 0x1f;
			byHead2	= pbyCur[2];

			if( 6 == byHead ){
				GInt32 lLen;
				lLen = pbyStart[6];
				pbyCur	+= lLen + 5 - l0N;
				i		+= lLen + 5 - l0N;
				if( 0xf0 == byHead2 ){
					astNalP[lNalPNum].pbyS	= pbyStart;
					astNalP[lNalPNum].lType	= 16;
					astNalP[lNalPNum].lOff	= lOff;
					lNalPNum++;
				}else{
					astNalP[lNalPNum].pbyS = pbyStart;
					astNalP[lNalPNum].lType= 6;
					astNalP[lNalPNum].lOff	= lOff;
					lNalPNum++;
				}
			} else if( GNull == pstOut->pbyRemoPWS ){
				pstOut->pbyRemoPWS	= pbyStart;
				pstOut->lLen_RemoPWS= lBufflen - lOff;
			}	//	Whether SEI

			if( 5 == byHead ){
				pstOut->bIFrame		= GTrue;
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 5;
				astNalP[lNalPNum].lOff	= lOff;
				astNalP[lNalPNum].lLen	= lBufflen - lOff;
				lNalPNum++;
				break;
			} else if( 1 == byHead ){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 1;
				astNalP[lNalPNum].lOff	= lOff;
				astNalP[lNalPNum].lLen	= lBufflen - lOff;
				lNalPNum++;
				break;
			} else if(7 == byHead){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 7;
				astNalP[lNalPNum].lOff	= lOff;
				lNalPNum++;
			}else if( 8 == byHead ){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 8;
				astNalP[lNalPNum].lOff	= lOff;
				lNalPNum++;
			}
		}
	}	// for
	PW_CHK( ERREXT, lNalPNum, 0 );	
	for( i=0; i<lNalPNum-1; i++ ){
		if( !astNalP[i].lLen )
			astNalP[i].lLen = astNalP[i+1].lOff - astNalP[i].lOff;
	}
	if( !astNalP[i].lLen )
		astNalP[i].lLen = astNalP[i+1].lOff - astNalP[i].lOff;
	for( i=0; i<lNalPNum; i++ ){
		if(astNalP[i].lLen){
			if( 1 == astNalP[i].lType ){
				pstOut->pbyIPNal	= astNalP[i].pbyS;
				pstOut->lLen_IPNal	= astNalP[i].lLen;
			} else if( 5 == astNalP[i].lType ){
				pstOut->pbyIPNal	= astNalP[i].pbyS;
				pstOut->lLen_IPNal	= astNalP[i].lLen;
			} else if( 6 == astNalP[i].lType ){
				pstOut->pbySEI		= astNalP[i].pbyS;
				pstOut->lLen_SEI	= astNalP[i].lLen;
			} else if( 7 == astNalP[i].lType ){
				pstOut->pbySPS		= astNalP[i].pbyS;
				pstOut->lLen_SPS	= astNalP[i].lLen;
			} else if( 8 == astNalP[i].lType ){
				pstOut->pbyPPS		= astNalP[i].pbyS;
				pstOut->lLen_PPS	= astNalP[i].lLen;
			} else if( 16 == astNalP[i].lType ){
				pstOut->pbyPWSEI	= astNalP[i].pbyS;
				pstOut->lLen_PWSEI	= astNalP[i].lLen;
			}
		}
	}
	
ERREXT:
	return;
}

static GVoid _ParseH265( GUInt8 *pbyData, GInt32 lBufflen, PSV_VIDEO_NAL *pstOut )
{
	GInt32 lNalPNum=0, i, lOff, l0N, lMax = lBufflen-2;//PW_MIN( 1024, lBufflen-16 );
	GUInt8 *pbyCur = pbyData, *pbyStart;
	GUInt32 ulFlag = 0xffffffff;
	GBool bPwSEI=GFalse;
	PSV_NAL_P astNalP[10]={0};

//	memset( pstOut, 0, sizeof( PSV_VIDEO_NAL ) );

	for( i=0; i<lMax; i++, pbyCur++ )
	{
		GUInt8 byVal = *pbyCur, byHead, byHead3;
		ulFlag = ( ulFlag << 8 ) + byVal;

		if( (ulFlag & 0xffffff) == 0x01 )
		{
			l0N = ulFlag & 0xff000000 ? 2 : 3;
			pbyStart = pbyCur - l0N;
			lOff = i - l0N;
			byHead	= ( pbyCur[1] & 0x7E ) >> 1;
			byHead3	= pbyCur[3];

			if( HEVC_NAL_SEI_PREFIX == byHead ){
				GInt32 lLen;
				lLen = pbyStart[7];
				pbyCur	+= lLen + 6 - l0N;
				i		+= lLen + 6 - l0N;
				if( 0xf0 == byHead3 ){
					astNalP[lNalPNum].pbyS = pbyStart;
					astNalP[lNalPNum].lType= 16;
					lNalPNum++;
				} else{
					astNalP[lNalPNum].pbyS = pbyStart;
					astNalP[lNalPNum].lType= 6;
					lNalPNum++;
				}
			}else if( GNull == pstOut->pbyRemoPWS ){
				pstOut->pbyRemoPWS	= pbyStart;
				pstOut->lLen_RemoPWS= lBufflen - lOff;
			}	//	Whether SEI

			if( HEVC_NAL_IDR_W_RADL == byHead ){
				pstOut->bIFrame		= GTrue;
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 5;
				astNalP[lNalPNum].lLen	= lBufflen - lOff;
				lNalPNum++;	
				break;
			} else if( HEVC_NAL_TRAIL_R == byHead ){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 1;
				astNalP[lNalPNum].lLen	= lBufflen - lOff;
				lNalPNum++;	
				break;
			} else if(HEVC_NAL_VPS == byHead){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 19;
				lNalPNum++;
			} else if(HEVC_NAL_SPS == byHead){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 7;
				lNalPNum++;
			} else if(HEVC_NAL_PPS == byHead){
				astNalP[lNalPNum].pbyS	= pbyStart;
				astNalP[lNalPNum].lType	= 8;
				lNalPNum++;
			} 
		}
	}

	PW_CHK( ERREXT, lNalPNum, 0 );	
	for( i=0; i<lNalPNum-1; i++ ){
		if( !astNalP[i].lLen )
			astNalP[i].lLen = (GUInt64)astNalP[i+1].pbyS - (GUInt64)astNalP[i].pbyS;
	}
	if( !astNalP[i].lLen )
		astNalP[i].lLen = (GUInt64)astNalP[i+1].pbyS - (GUInt64)astNalP[i].pbyS;
	for( i=0; i<lNalPNum; i++ ){
		if(astNalP[i].lLen){
			if( 1 == astNalP[i].lType ){
				pstOut->pbyIPNal	= astNalP[i].pbyS;
				pstOut->lLen_IPNal	= astNalP[i].lLen;
			} else if( 5 == astNalP[i].lType ){
				pstOut->pbyIPNal	= astNalP[i].pbyS;
				pstOut->lLen_IPNal	= astNalP[i].lLen;
			} else if( 6 == astNalP[i].lType ){
				pstOut->pbySEI		= astNalP[i].pbyS;
				pstOut->lLen_SEI	= astNalP[i].lLen;
			} else if( 7 == astNalP[i].lType ){
				pstOut->pbySPS		= astNalP[i].pbyS;
				pstOut->lLen_SPS	= astNalP[i].lLen;
			} else if( 8 == astNalP[i].lType ){
				pstOut->pbyPPS		= astNalP[i].pbyS;
				pstOut->lLen_PPS	= astNalP[i].lLen;
			} else if( 19 == astNalP[i].lType ){
				pstOut->pbyVPS		= astNalP[i].pbyS;
				pstOut->lLen_VPS	= astNalP[i].lLen;
			} else if( 16 == astNalP[i].lType ){
				pstOut->pbyPWSEI	= astNalP[i].pbyS;
				pstOut->lLen_PWSEI	= astNalP[i].lLen;
			}
		}
	}
	
ERREXT:
	return;
}

GBool psvSplitVideo( GUInt8 *pbyData, GInt32 lDataLen, PSV_VIDEO_NAL *pstOut )
{
	PW_CHK( ERREXT, pbyData, GNull );
	PW_CHK( ERREXT, lDataLen, 0 );
	PW_CHK( ERREXT, pstOut, GNull );

	memset( pstOut, 0, sizeof( PSV_VIDEO_NAL ) );
	pstOut->lEncType = PSV_ENC_UNKNOWN;

	pstOut->lEncType = _CheckEnc( pbyData, lDataLen );

	switch(pstOut->lEncType){
	case PSV_ENC_H264:	_ParseH264( pbyData, lDataLen, pstOut );	break;
	case PSV_ENC_H265:	_ParseH265( pbyData, lDataLen, pstOut );	break;
	default:	goto ERREXT;
	}

	return GTrue;
ERREXT:
	return GFalse;
}

GBool psvParseSPS( GUInt8 *pbySPS, GInt32 lLen_SPS, PSV_SPS_INFO *pstOut )
{
	PSV_ENC_TYPE eEncType = PSV_ENC_UNKNOWN;
	GUInt8 abyCopy[256];
	GInt32 i, lLen;
	PW_CHK( ERREXT, pstOut, GNull );
	memset( pstOut, 0, sizeof(PSV_SPS_INFO) );
	PW_CHK( ERREXT, pbySPS, GNull );
	PW_CHK( ERREXT, lLen_SPS < 8, 1 );

	eEncType = _CheckEncBrief_sps( pbySPS, lLen_SPS );
	PW_CHK( ERREXT, eEncType, PSV_ENC_UNKNOWN );

	lLen = PW_MIN( lLen_SPS, sizeof(abyCopy) );
	stack_memcpy( abyCopy, pbySPS, lLen );

	if( PSV_ENC_H264 == eEncType ){
		GVM_H264SPSINFO stH264Inf={0};
		H264ParseSps( abyCopy + 5, lLen - 5, &stH264Inf );
		if( stH264Inf.ulFrameHeight == 1088 )	
			stH264Inf.ulFrameHeight = 1080;
		pstOut->lWidth	= stH264Inf.ulFrameWidth;
		pstOut->lHeight	= stH264Inf.ulFrameHeight;
		pstOut->lFPS	= PW_ROUND( stH264Inf.fFrameRate );
	}else if( PSV_ENC_H265 == eEncType ){
		GVM_H265SPSINFO stH265Inf={0};
		H265ParseSps( abyCopy + 6, lLen - 6, &stH265Inf );
		if( stH265Inf.ulFrameHeight == 1088 )	
			stH265Inf.ulFrameHeight = 1080;
		pstOut->lWidth	= stH265Inf.ulFrameWidth;
		pstOut->lHeight	= stH265Inf.ulFrameHeight;
		pstOut->lFPS	= PW_ROUND( stH265Inf.fFrameRate );
	}

	return GTrue;
ERREXT:
	return GFalse;
}

GBool psvParseSEI( GUInt8 *pbyPWSEI, GInt32 lLen_PWSEI, PSV_SEI_INFO *pstOut )
{
	GInt32 lT;
	PSR_SEI_MSG stSeiMsg={0};
	PSV_ENC_TYPE eEncType = PSV_ENC_UNKNOWN;
	PW_CHK( ERREXT, pstOut, GNull );
	memset( pstOut, 0, sizeof(PSV_SEI_INFO) );
	PW_CHK( ERREXT, pbyPWSEI, GNull );
	PW_CHK( ERREXT, lLen_PWSEI < 16, 1 );

	eEncType = _CheckEncBrief( pbyPWSEI, lLen_PWSEI );
	PW_CHK( ERREXT, eEncType, PSV_ENC_UNKNOWN );

	lT = PSV_ENC_H265 == eEncType ? 6 : 5;

	GOF( ERREXT, psrReadSEI( pbyPWSEI + lT, &stSeiMsg ), GTrue );
	pstOut->ulBeIFrame			= stSeiMsg.ulBeIFrame;
	pstOut->ullPanoTypeEx		= stSeiMsg.ullPanoTypeEx;
	pstOut->ullSecurityFlag		= stSeiMsg.ullSecurityFlag;
	pstOut->ullINalStart		= stSeiMsg.ulINalStart;
	pstOut->ullPNalStart		= stSeiMsg.ulPNalStart;
	pstOut->ullAudioStart		= stSeiMsg.ulAudioStart;
	pstOut->usVideoInterSize	= stSeiMsg.usVideoInterSize;
	pstOut->usAudioInterSize	= stSeiMsg.usAudioInterSize;
	pstOut->ulSecuDataMaxLen	= stSeiMsg.ulSecuDataMaxLen;
	pstOut->fViewVirAngle		= stSeiMsg.usPanRange_100 * 0.01f;
	pstOut->ulBeRotated			= stSeiMsg.ulBeRotated;
	pstOut->ullYear		= (GUInt32)stSeiMsg.uTime.stTime.ulYear + 2000;
	pstOut->ullMonth	= stSeiMsg.uTime.stTime.ulMonth;
	pstOut->ullDay		= stSeiMsg.uTime.stTime.ulDay;
	pstOut->ullHour		= stSeiMsg.uTime.stTime.ulHour;
	pstOut->ullMinute	= stSeiMsg.uTime.stTime.ulMinute;
	pstOut->ullSecond	= stSeiMsg.uTime.stTime.ulSecond;
	pstOut->sPan_10		= PW_ROUND_SF( stSeiMsg.fPTZPan * 10 );
	pstOut->sTilt_10	= PW_ROUND_SF( stSeiMsg.fPTZTilt * 10 );
	pstOut->sRotate_10	= PW_ROUND_SF( stSeiMsg.fPTZRotate * 10 );
	pstOut->sZoom_10	= 10;
	pstOut->fFPS		= stSeiMsg.fCurrentFPS;
	pstOut->ulDefWid	= stSeiMsg.ulDefWid;
	pstOut->ulDefHei	= stSeiMsg.ulDefHei;
	pstOut->bUnEncryption	= stSeiMsg.ulBeUnEncrypt;
	pstOut->fViewAngle		= pstOut->fViewVirAngle * 1.1f;	//	LGY 大致估算
	pstOut->ulBeVerLens		= stSeiMsg.ulBeVerLens;

    //add by wus
	pstOut->ulStreamChl = stSeiMsg.ulStreamChl;

	/* 区分新老版本拼接的标识 */
	pstOut->ulBeUnitArray = stSeiMsg.ulBeUnitArray;

	/* 新版本拼接需要赋值 */
    if(stSeiMsg.ulBeUnitArray)
    {
        stack_memcpy(pstOut->uForward.ulForward, stSeiMsg.uForward.ulForward, sizeof(pstOut->uForward.ulForward));

    }
	
	pstOut->fCenterX	= stSeiMsg.fCenterX;
	pstOut->fCenterY	= stSeiMsg.fCenterY;
	pstOut->fRadius		= stSeiMsg.fRadius;
	pstOut->fPanoPan	= stSeiMsg.fPanoPan;
	pstOut->fPanoTilt	= stSeiMsg.fPanoTilt;
	pstOut->fPanoRotate	= stSeiMsg.fPanoRotate;
	pstOut->fPTZPan		= stSeiMsg.fPTZPan;
	pstOut->fPTZTilt	= stSeiMsg.fPTZTilt;
	pstOut->fPTZRotate	= stSeiMsg.fPTZRotate;
	pstOut->fPTZZoom	= stSeiMsg.fPTZZoom;
	pstOut->uTime.stTime= stSeiMsg.uTime.stTime;

	if(stSeiMsg.ulBeUnitArray)
	{ //新版本拼接相关数据
        stack_memcpy(pstOut->uUnitCfg.abyUnitData, stSeiMsg.uUnitCfg.abyUnitData, sizeof(pstOut->uUnitCfg.abyUnitData));

	}
	else
	{ //老版本拼接相关数据
        pstOut->uUnitCfg.stOld.ullPan10 = stSeiMsg.uUnitCfg.stOld.ullPan10;
        pstOut->uUnitCfg.stOld.ullTilt10 = stSeiMsg.uUnitCfg.stOld.ullTilt10;
        pstOut->uUnitCfg.stOld.ullRgtOffX = stSeiMsg.uUnitCfg.stOld.ullRgtOffX;
        pstOut->uUnitCfg.stOld.ullRgtOffY = stSeiMsg.uUnitCfg.stOld.ullRgtOffY;
        pstOut->uUnitCfg.stOld.ullRgtOffYMi = stSeiMsg.uUnitCfg.stOld.ullRgtOffYMi;
        pstOut->uUnitCfg.stOld.ullb4DirMean = stSeiMsg.uUnitCfg.stOld.ullb4DirMean;
        pstOut->uUnitCfg.stOld.ulDefZ10 = stSeiMsg.uUnitCfg.stOld.ulDefZ10;
        pstOut->uUnitCfg.stOld.ullBe2ndCrt = stSeiMsg.uUnitCfg.stOld.ullBe2ndCrt;
        pstOut->uUnitCfg.stOld.ulFrmDirect = stSeiMsg.uUnitCfg.stOld.ulFrmDirect;
        pstOut->uUnitCfg.stOld.ulExtern2 = stSeiMsg.uUnitCfg.stOld.ulExtern2;
        pstOut->uUnitCfg.stOld.fMtrX0 = stSeiMsg.uUnitCfg.stOld.fMtrX0;
        pstOut->uUnitCfg.stOld.fMtrY0 = stSeiMsg.uUnitCfg.stOld.fMtrY0;
        pstOut->uUnitCfg.stOld.fMtrX1Y2 = stSeiMsg.uUnitCfg.stOld.fMtrX1Y2;
        pstOut->uUnitCfg.stOld.fMtrX3Y4 = stSeiMsg.uUnitCfg.stOld.fMtrX3Y4;
        pstOut->uUnitCfg.stOld.fMtrX5 = stSeiMsg.uUnitCfg.stOld.fMtrX5;
        pstOut->uUnitCfg.stOld.fMtrY5 = stSeiMsg.uUnitCfg.stOld.fMtrY5;
        
        for ( GInt32 i = 0; i < 9; i++ ){
            pstOut->uUnitCfg.stOld.af2ndMtrLft[i] = stSeiMsg.uUnitCfg.stOld.af2ndMtrLft[i];
            pstOut->uUnitCfg.stOld.af2ndMtrRgt[i] = stSeiMsg.uUnitCfg.stOld.af2ndMtrRgt[i];
        }

	}

    stack_memcpy(pstOut->uForward2.ulForward, stSeiMsg.uForward2.ulForward, sizeof(pstOut->uForward2.ulForward));

	lT = stSeiMsg.fPanoTilt;
	lT %= 360;		
	if( lT < 0 ) lT += 360;
	if( lT < 45 )		pstOut->ulLensDir = 0;
	else if( lT < 135 )	pstOut->ulLensDir = 90;
	else if( lT < 225 )	pstOut->ulLensDir = 180;
	else if( lT < 315 )	pstOut->ulLensDir = 270;
	else				pstOut->ulLensDir = 0;

	return GTrue;
ERREXT:
	return GFalse;
}

GBool psvParseJpgTail( GUInt8 *pbyJpgData, GInt32 lLen, PSV_JPG_INFO *pstOut )
{
	GBool bHit = GFalse;
	GUInt32 lTailOff, i, lJpgType=0;	//	0 panoramic jpg, 1 ptz_pano jpg
	GUInt8 *pbyTail, byValF, byValB; 
    PSV_JPG_TAIL_PTZ_PANO stTail={0};

	PW_CHK( ERREXT, pstOut, GNull );
	memset( pstOut, 0, sizeof( PSV_JPG_INFO ) );
	PW_CHK( ERREXT, pbyJpgData, GNull );
	PW_CHK( ERREXT, lLen < 16, 1 );

	if( lLen < 512 )	goto ERREXT;

	lTailOff = lLen - 1;
	pbyTail = pbyJpgData + lTailOff;

	byValB = *pbyTail;	pbyTail--;
	byValF = *pbyTail;	pbyTail--;
	for ( i=0; i<(lLen>>1); i++, lTailOff-- )
	{
		if( 0xff == byValF && 0xd9 == byValB )
		{
            stack_memcpy( &stTail, pbyTail + 3, sizeof(PSV_JPG_TAIL_PTZ_PANO));
			bHit = GTrue;
			break;
		}
		byValB = byValF;
		byValF = *pbyTail;	pbyTail--;
	}
	PW_CHK( ERREXT, bHit, GFalse );
	PW_CHK_N( ERREXT, stTail.ulVersion, 3 );
	PW_CHK_N( ERREXT, stTail.ulTailSize, sizeof(PSV_JPG_TAIL_PTZ_PANO) );

	pstOut->usTopTilt_10 = stTail.usTopTilt_10;
	pstOut->usBtmTilt_10 = stTail.usBtmTilt_10;

	//m_stJpgTail = *pstPanoramicTail;

	return GTrue;
ERREXT:
	return GFalse;
}
