#include "pw_mem.h"

pwmem_man* pwmem_man::pwmemManIns = new pwmem_man();

pwmPT* pwmem_alloc(int ilen)
{
    unsigned char* pbuf;
    pbuf=(unsigned char*)malloc(ilen);
    if (!pbuf) return NULL;
    pwmPT* pwpt=pwmem_man::instance()->item_alloc();
    pwpt->assign(pbuf,ilen);
    return pwpt;
}

int pwmem_free(pwmPT* item)
{
    unsigned char* pbuf=item->getbuf();
    int iret = pwmem_man::instance()->item_free(item);
    if (iret==0){
        free(pbuf);
        return 0;
    }
    return -1;
}

void mem_us(pwmPT *pwpt)
{
    autoRef myref(pwpt);

    char myname[]="123456789";
    void *pt = pwpt->pw_memcpy((unsigned char*)myname,sizeof(myname));

    int isref = pwpt->is_ref();
    printf("mem_us is ref %d pt %p\n",isref,pt);
  
    int iret = pwmem_free(pwpt);
    printf("free return %d \n",iret);
    return;
}

int main1()
{
    pwmPT* pwbuf = pwmem_alloc(10);
    mem_us(pwbuf);
    int isref = pwbuf->is_ref();
    printf("main is ref %d \n",isref);
    printf("value:%s \n",pwbuf->getbuf());

    int iret = pwmem_free(pwbuf);
    printf("free return %d \n",iret);
    return 0;
}
