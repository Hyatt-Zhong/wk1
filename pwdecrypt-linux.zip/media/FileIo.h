#ifndef _FILE_IO_H_
#define _FILE_IO_H_
#include <stdio.h>
#include <time.h>
#include <string>
#include <vector>
#include "pw_general_type.h"
using namespace std;

#define MAXH264FRAMESIZE 1024 * 100
#define ALARM_NUMBERS 8

enum Alarm
{
    ALARM_MOVE=1,
    ALARM_PRI=2,
    ALARM_BUTTON=4
};

typedef struct TF_AlarmFile
{
    int startTime;
    int endTime;
    int alarm_type;
}TF_AlarmFile_t;

//typedef struct AlarmFile
//{
//    char filename[1024];
//    int alarm_type;
//}AlarmFile_t;

typedef struct Cloud_AlarmFile
{
    char filename[1024];
    int startTime;
    int endTime;
    int alarm_type;
}Cloud_AlarmFile_t;

extern FILE* sdk_pVideo_H264_File;

FILE* sdk_OpenFile(char* FileName, const char* OpenMode);
void  sdk_CloseFile(FILE* pFile);
int   sdk_ReadFile(FILE* pFile, unsigned char* Buffer, int BufferSize);
int   sdk_WriteFile(FILE* pFile, char* Buffer, int BufferSize);

/*Function:
 *  Get stream file from day_index file.
 */
int sdk_GetStreamFile(vector<AlarmFile_t> *vfile_264, time_t start, time_t end, const char *path);

int GuessMin6EventIdx(const char *szIndexPath);

int sdk_ParseCloudIndexFile(vector<Cloud_AlarmFile_t> *cloudFile, time_t start, time_t end, const char *path);

int sdk_ParseTFIndexInfoEx(vector<TF_AlarmFile_t> *tfAlarmFile, char *indexInfo,int len,time_t time);

int sdk_ParseTFIndexInfo(vector<TF_AlarmFile_t> *tfAlarmFile, char *indexPath,time_t time);

bool sdk_ResetIndexFile(time_t start, time_t end, const char *path, time_t zero_t);

int sdk_tagFullDayIndex(const char *indexPath);

//确定当前的index是否是完整的一天
int sdk_isFullDay(const char *indexPath);



#endif
