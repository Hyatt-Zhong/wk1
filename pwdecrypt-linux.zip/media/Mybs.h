#ifndef _MY_BS_H_
#define _MY_BS_H_

typedef struct Tag_bs
{
    unsigned char* p_start;     //缓冲区首地址
    unsigned char* p;           //缓冲区当前的读写指针
    unsigned char* p_end;       //缓冲区尾地址
    int      i_left;            //p所指字节
}bs_t;

/*功能：初始化结构体
 */
void bs_init(bs_t *s, void *p_data, int i_data);

int  bs_read(bs_t *s, int i_count);

/*功能：从s中读取1位，并返回
 */
int bs_read1(bs_t* s);

int  bs_read_ue(bs_t *s);

#endif
