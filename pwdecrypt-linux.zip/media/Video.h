#ifndef _VIDEO_H_H_H
#define _VIDEO_H_H_H

#include <stdio.h>
#include <stdlib.h>
#include "FileIo.h"
#include "pw_general_type.h"

#define MAX_VIDEO_TAG_BUF_SIZE   1024 * 1024
#define VIDEO_TAG_HEADER_LENGTH  11
#define MAX_ONE_FRAME_DATA_SIZE 1024 * 1024

#define PWT_AUDIO_HEAD_LEN  4   

#define PWT_I_FRAME_HEAD_LEN    12

#define PWT_P_FRAME_HEAD_LEN    4

extern int s_enc_type;

typedef struct tagFRAME_INFO
{
    unsigned int                frm_type;
    unsigned int                buf_size;
    unsigned int                time;
}FRAME_INFO;

typedef struct Tag_NALU_t
{
    unsigned char forbidden_bit;			//禁止位
    unsigned char nal_reference_idc;		//重要级别
    unsigned char nal_unit_type;			//NALU类型
    unsigned int  startcodeprefix_len;		//前缀字节数
    unsigned int  len;						//包含nal头的nal长度
    unsigned int  max_size;					//做多一个nal的长度
    unsigned char *buf;						//包含nal头的nal数据
    unsigned char Frametype;				//帧类型
    unsigned int  read_mode;				//预留
	unsigned int private_head_len;			//私有头长度
}NALU_t;

//nal类型
enum nal_unit_type_e
{
    NAL_UNKNOWN   = 0,
    NAL_SLICE     = 1,  /* P帧  */
    NAL_SLICE_DPA = 2,
    NAL_SLICE_DPB = 3,
    NAL_SLICE_DPC = 4,
    NAL_SLICE_IDR = 5,  ///*ref_idc != 0 I帧*/
    NAL_SEI       = 6,  ///*ref_idc == 0*/
    NAL_SPS       = 7,
    NAL_PPS       = 8,
    /*ref_idc == 0 for 6,9,10,11,12*/
    NAL_I         = 0x1C,  /*puwell */
    NAL_P         = 0x1D,  /*puwell*/
    NAL_A         = 0x1A   /*puwell*/
};

enum Frametype_e{
	FRAME_I = 0,
	FRAME_P = 1,
	FRAME_A = 2,
	FRAME_B = 3,
    FRAME_OTHER = 4,
};

typedef struct _AUDIO_HEAD_PWT{
    //  GUInt8  byFlag[4];                                                                
    unsigned char byCodeType;
    unsigned char bySampleRate;
    unsigned short usDatalen;
}Audio_Head_PW_t;
 
typedef struct _iframe_head_pwt_{ 
    unsigned char byCT;
    unsigned char byFPS;
    unsigned char byWid_8L;
    unsigned char byHei_8L;
    unsigned int ulTime;    
    unsigned int ulDatalen;
}IFrame_Head_PW_t;

typedef struct _pframe_head_pwt_{ 
    unsigned int ulDatalen;
}PFrame_Head_PW_t;

typedef struct 
{
	uint8	*pbyPW1Head;	
	uint8	*pbyData;	
	uint32 ulFrameLength;
	uint32 ulDataLength;

	uint64	ullBeVideo			:1;	//	GTrue : Video;	GFalse : Audio
	uint64	ullBeIFrame			:1;
	uint64	ullAudioChannel		:2; //	1 or 2
	uint64	ullAudioSampleBits	:3; //	0 : illegal; 1 : 8 Bit; 2 : 16 Bit; 3 : 32 Bit; 4 : 64 Bit;
	uint64	ullAudioSampleRate	:16; //	
	uint64	ullExtern			:41;

} PWH_FRAME_INFO;

enum PARSE_TYPE
{
    PARSE_TYPE_TF = 0,
    PARSE_TYPE_CLOUD = 1
};

class PwCloudFileParse
{
public:
	PwCloudFileParse();

	~PwCloudFileParse();

public:
	int CreateParse(uint32 uMaxBuffSize = 0);

	void ReleaseParse();

	int StartParseNewFile(const char *fileName);

	PWH_FRAME_INFO* GetOneFrame();

	bool IsStartParse() { return m_startParse; }

	void SetStopParse() { m_startParse = false; }

    int GetFrameParamByType(uint8 fcode, uint8* chead, uint32* frame_type, uint32* frame_len);

public:
	static int FindFrameStartCode(uint8* Buf, int len);

	static int GetFrameType(NALU_t* nal);

    static int GetFrameType264(NALU_t* nal);

private:
	int _GetAnnexNALU(NALU_t* nalu);

    int _GetAnnexNALUTF(NALU_t* nalu);

	int _GetAnnexH264(NALU_t* nalu,int has_startof, unsigned char* pre_buf,int pre_buflen);

	int _GetH264HeadFromFile();

private:
	FILE* m_CloudFileHandler;

	char m_CloudFilepath[256];

	uint8 *m_FrameBuff;

	uint32 m_MaxBuffSize;

	PWH_FRAME_INFO m_StCurOut;

	bool m_startParse;

    int parse_type_ = PARSE_TYPE_TF;
};


#endif
