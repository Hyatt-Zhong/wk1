
#ifndef _PW_PASS_STEAM_SECURITY_INDEF_H_
#define _PW_PASS_STEAM_SECURITY_INDEF_H_

#include "pwPassStreamSecurity.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define SECURITY_CODE_TYPE_NULL		0 
#define SECURITY_CODE_TYPE_DEFAULT	1 
#define SECURITY_CODE_TYPE_CUSTOM	2 
#define SECURITY_CODE_TYPE_TEMP		3 
#define SECURITY_CODE_TYPE_DEF_OLD	4 
#define SECURITY_CODE_TYPE_COUNT	4 


// enum STREAM_SECURITY_LV
// {
// 	STREAM_SECURITY_LV_I		=0, 
// 	STREAM_SECURITY_LV_V		, 
// 	STREAM_SECURITY_LV_AV		, 
// 	STREAM_SECURITY_LV_FREE		, 
// };

#define PWPS_TYPE_2_PACKNO( lLv )	( (lLv) - 1 )	
#define PWPS_PACKNO_2_TYPE( lNo )	( (lNo) + 1 )	

typedef struct _pw_security_flag_
{
	GUInt64 ullCodeType				:3;		//	0 = no_security; 1 = default code; 2 = custom code;	3 = temp code
	GUInt64 ullSecurityLv			:8;		//	
	GUInt64 ullProCodePiece_2		:5;		//	ProCode[2]  0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'
	GUInt64 ullProCodePiece_3		:5;		//	ProCode[3]  0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'
	GUInt64 ullProCodePiece_5		:5;		//	ProCode[5]  0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'
	GUInt64 ullProCodePiece_7		:5;		//	ProCode[7]	0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'	
	GUInt64 ullProCodePiece_11		:5;		//	ProCode[11]  0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'
	GUInt64 ullProCodePiece_13		:5;		//	ProCode[13]  0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'
	GUInt64 ullProCodePiece_17		:5;		//	ProCode[17]  0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'
	GUInt64 ullProCodePiece_19		:5;		//	ProCode[19]	0 ~ 9 = '0' ~ '9';	10 ~ 31 = 'A' ~ 'V'	
	GUInt64 ullProCodePieceC		:8;		//	ProCode[0]^ProCode[1]^...[4][6][8][9][10][12][14][15][16]...^ProCode[18]
	GUInt64	ullExtern				:5;
}PW_SECURITY_FLAG;

#endif	//	_PW_PASS_STEAM_SECURITY_INDEF_H_