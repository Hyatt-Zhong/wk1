
#include "pwPassStreamSecurity_indef.h"
#include "pw_security_encryption.h"

/* typedef a 32 bit type */
//typedef unsigned long int UINT4;
typedef GUInt32 UINT4;


/* Data structure for MD5 (Message Digest) computation */
// typedef struct {
//   UINT4 i[2];                   /* number of _bits_ handled mod 2^64 */
//   UINT4 buf[4];                                    /* scratch buffer */
//   unsigned char ulIn[64];                              /* input buffer */
//   unsigned char digest[16];     /* actual digest after MD5Final call */
// } MD5_CTX;

typedef struct {
	GUInt32 i[2];                   /* number of _bits_ handled mod 2^64 */
	GUInt32 buf[4];                                    /* scratch buffer */
	GUInt8 ulIn[64];                              /* input buffer */
	GUInt8 digest[16];     /* actual digest after MD5Final call */
} MD5_CTX;
 
/* F, G and H are basic MD5 functions: selection, majority, parity */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z))) 

/* ROTATE_LEFT rotates x left n bits */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/* FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4 */
/* Rotation is separate from addition to prevent recomputation *///UINT4
#define FF(a, b, c, d, x, s, ac) \
{(a) += F ((b), (c), (d)) + (x) + (GUInt32)(ac); \
	(a) = ROTATE_LEFT ((a), (s)); \
	(a) += (b); \
}
#define GG(a, b, c, d, x, s, ac) \
{(a) += G ((b), (c), (d)) + (x) + (GUInt32)(ac); \
	(a) = ROTATE_LEFT ((a), (s)); \
	(a) += (b); \
}
#define HH(a, b, c, d, x, s, ac) \
{(a) += H ((b), (c), (d)) + (x) + (GUInt32)(ac); \
	(a) = ROTATE_LEFT ((a), (s)); \
	(a) += (b); \
}
#define II(a, b, c, d, x, s, ac) \
{(a) += I ((b), (c), (d)) + (x) + (GUInt32)(ac); \
	(a) = ROTATE_LEFT ((a), (s)); \
	(a) += (b); \
  }

//static GVoid Transform ( UINT4 *ulBuff, UINT4 *ulIn )
static GVoid Transform ( GUInt32 *ulBuff, GUInt32 *ulIn )
{
//	UINT4 a = ulBuff[0], b = ulBuff[1], c = ulBuff[2], d = ulBuff[3];
	GUInt32 a = ulBuff[0], b = ulBuff[1], c = ulBuff[2], d = ulBuff[3];
	
	/* Round 1 */
#define S11 7
#define S12 12
#define S13 17
#define S14 22
	FF ( a, b, c, d, ulIn[ 0], S11, 3614090360); /* 1 */
	FF ( d, a, b, c, ulIn[ 1], S12, 3905402710); /* 2 */
	FF ( c, d, a, b, ulIn[ 2], S13,  606105819); /* 3 */
	FF ( b, c, d, a, ulIn[ 3], S14, 3250441966); /* 4 */
	FF ( a, b, c, d, ulIn[ 4], S11, 4118548399); /* 5 */
	FF ( d, a, b, c, ulIn[ 5], S12, 1200080426); /* 6 */
	FF ( c, d, a, b, ulIn[ 6], S13, 2821735955); /* 7 */
	FF ( b, c, d, a, ulIn[ 7], S14, 4249261313); /* 8 */
	FF ( a, b, c, d, ulIn[ 8], S11, 1770035416); /* 9 */
	FF ( d, a, b, c, ulIn[ 9], S12, 2336552879); /* 10 */
	FF ( c, d, a, b, ulIn[10], S13, 4294925233); /* 11 */
	FF ( b, c, d, a, ulIn[11], S14, 2304563134); /* 12 */
	FF ( a, b, c, d, ulIn[12], S11, 1804603682); /* 13 */
	FF ( d, a, b, c, ulIn[13], S12, 4254626195); /* 14 */
	FF ( c, d, a, b, ulIn[14], S13, 2792965006); /* 15 */
	FF ( b, c, d, a, ulIn[15], S14, 1236535329); /* 16 */
	
	/* Round 2 */
#define S21 5
#define S22 9
#define S23 14
#define S24 20
	GG ( a, b, c, d, ulIn[ 1], S21, 4129170786); /* 17 */
	GG ( d, a, b, c, ulIn[ 6], S22, 3225465664); /* 18 */
	GG ( c, d, a, b, ulIn[11], S23,  643717713); /* 19 */
	GG ( b, c, d, a, ulIn[ 0], S24, 3921069994); /* 20 */
	GG ( a, b, c, d, ulIn[ 5], S21, 3593408605); /* 21 */
	GG ( d, a, b, c, ulIn[10], S22,   38016083); /* 22 */
	GG ( c, d, a, b, ulIn[15], S23, 3634488961); /* 23 */
	GG ( b, c, d, a, ulIn[ 4], S24, 3889429448); /* 24 */
	GG ( a, b, c, d, ulIn[ 9], S21,  568446438); /* 25 */
	GG ( d, a, b, c, ulIn[14], S22, 3275163606); /* 26 */
	GG ( c, d, a, b, ulIn[ 3], S23, 4107603335); /* 27 */
	GG ( b, c, d, a, ulIn[ 8], S24, 1163531501); /* 28 */
	GG ( a, b, c, d, ulIn[13], S21, 2850285829); /* 29 */
	GG ( d, a, b, c, ulIn[ 2], S22, 4243563512); /* 30 */
	GG ( c, d, a, b, ulIn[ 7], S23, 1735328473); /* 31 */
	GG ( b, c, d, a, ulIn[12], S24, 2368359562); /* 32 */
	
	/* Round 3 */
#define S31 4
#define S32 11
#define S33 16
#define S34 23
	HH ( a, b, c, d, ulIn[ 5], S31, 4294588738); /* 33 */
	HH ( d, a, b, c, ulIn[ 8], S32, 2272392833); /* 34 */
	HH ( c, d, a, b, ulIn[11], S33, 1839030562); /* 35 */
	HH ( b, c, d, a, ulIn[14], S34, 4259657740); /* 36 */
	HH ( a, b, c, d, ulIn[ 1], S31, 2763975236); /* 37 */
	HH ( d, a, b, c, ulIn[ 4], S32, 1272893353); /* 38 */
	HH ( c, d, a, b, ulIn[ 7], S33, 4139469664); /* 39 */
	HH ( b, c, d, a, ulIn[10], S34, 3200236656); /* 40 */
	HH ( a, b, c, d, ulIn[13], S31,  681279174); /* 41 */
	HH ( d, a, b, c, ulIn[ 0], S32, 3936430074); /* 42 */
	HH ( c, d, a, b, ulIn[ 3], S33, 3572445317); /* 43 */
	HH ( b, c, d, a, ulIn[ 6], S34,   76029189); /* 44 */
	HH ( a, b, c, d, ulIn[ 9], S31, 3654602809); /* 45 */
	HH ( d, a, b, c, ulIn[12], S32, 3873151461); /* 46 */
	HH ( c, d, a, b, ulIn[15], S33,  530742520); /* 47 */
	HH ( b, c, d, a, ulIn[ 2], S34, 3299628645); /* 48 */
	
	/* Round 4 */
#define S41 6
#define S42 10
#define S43 15
#define S44 21
	II ( a, b, c, d, ulIn[ 0], S41, 4096336452); /* 49 */
	II ( d, a, b, c, ulIn[ 7], S42, 1126891415); /* 50 */
	II ( c, d, a, b, ulIn[14], S43, 2878612391); /* 51 */
	II ( b, c, d, a, ulIn[ 5], S44, 4237533241); /* 52 */
	II ( a, b, c, d, ulIn[12], S41, 1700485571); /* 53 */
	II ( d, a, b, c, ulIn[ 3], S42, 2399980690); /* 54 */
	II ( c, d, a, b, ulIn[10], S43, 4293915773); /* 55 */
	II ( b, c, d, a, ulIn[ 1], S44, 2240044497); /* 56 */
	II ( a, b, c, d, ulIn[ 8], S41, 1873313359); /* 57 */
	II ( d, a, b, c, ulIn[15], S42, 4264355552); /* 58 */
	II ( c, d, a, b, ulIn[ 6], S43, 2734768916); /* 59 */
	II ( b, c, d, a, ulIn[13], S44, 1309151649); /* 60 */
	II ( a, b, c, d, ulIn[ 4], S41, 4149444226); /* 61 */
	II ( d, a, b, c, ulIn[11], S42, 3174756917); /* 62 */
	II ( c, d, a, b, ulIn[ 2], S43,  718787259); /* 63 */
	II ( b, c, d, a, ulIn[ 9], S44, 3951481745); /* 64 */
	
	ulBuff[0] += a;
	ulBuff[1] += b;
	ulBuff[2] += c;
	ulBuff[3] += d;
}

//static unsigned char g_byPadding[64] = {
static GUInt8 g_byPadding[64] = {
 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

GVoid MD5Init (MD5_CTX *mdContext)
{
//  mdContext->i[0] = mdContext->i[1] = (UINT4)0;

  /* Load magic initialization constants.   */
//   mdContext->buf[0] = (UINT4)0x67452301;
//   mdContext->buf[1] = (UINT4)0xefcdab89;
//   mdContext->buf[2] = (UINT4)0x98badcfe;
//   mdContext->buf[3] = (UINT4)0x10325476;

  mdContext->i[0] = mdContext->i[1] = (GUInt32)0;
  /* Load magic initialization constants.   */
  mdContext->buf[0] = (GUInt32)0x67452301;
  mdContext->buf[1] = (GUInt32)0xefcdab89;
  mdContext->buf[2] = (GUInt32)0x98badcfe;
  mdContext->buf[3] = (GUInt32)0x10325476;

}

//GVoid MD5Update ( MD5_CTX *stMDContext, unsigned char *pbyBuff, unsigned int lLength)
GVoid MD5Update ( MD5_CTX *stMDContext, GUInt8 *pbyBuff, GUInt32 lLength )
{
// 	UINT4 ulIn[16];
// 	int lMdi;
// 	unsigned int i, ii;
	GUInt32 ulIn[16];
	GInt32 lMdi;
	GUInt32 i, ii;

	/* compute number of bytes mod 64 */
//	lMdi = (int)((stMDContext->i[0] >> 3) & 0x3F);
	lMdi = (GInt32)((stMDContext->i[0] >> 3) & 0x3F);

	/* update number of bits */
// 	if ((stMDContext->i[0] + ((UINT4)lLength << 3)) < stMDContext->i[0])
// 		stMDContext->i[1]++;
// 	stMDContext->i[0] += ((UINT4)lLength << 3);
// 	stMDContext->i[1] += ((UINT4)lLength >> 29);
	if ((stMDContext->i[0] + ((GUInt32)lLength << 3)) < stMDContext->i[0])
		stMDContext->i[1]++;
	stMDContext->i[0] += ((GUInt32)lLength << 3);
	stMDContext->i[1] += ((GUInt32)lLength >> 29);
	
	while (lLength--) {
		/* add new character to buffer, increment lMdi */
		stMDContext->ulIn[lMdi++] = *pbyBuff++;
		
		/* transform if necessary */
		if (lMdi == 0x40) 
		{
			for (i = 0, ii = 0; i < 16; i++, ii += 4)
// 				ulIn[i] = (((UINT4)stMDContext->ulIn[ii+3]) << 24) |
// 						(((UINT4)stMDContext->ulIn[ii+2]) << 16) |
// 						(((UINT4)stMDContext->ulIn[ii+1]) << 8) |
// 						((UINT4)stMDContext->ulIn[ii]);
				ulIn[i] =	(((GUInt32)stMDContext->ulIn[ii+3]) << 24) |
							(((GUInt32)stMDContext->ulIn[ii+2]) << 16) |
							(((GUInt32)stMDContext->ulIn[ii+1]) << 8) |
							((GUInt32)stMDContext->ulIn[ii]);
			Transform (stMDContext->buf, ulIn);
			lMdi = 0;
		}
	}
}

GVoid MD5Final (MD5_CTX *mdContext)
{
// 	UINT4 ulIn[16];
// 	int lMdi;
// 	unsigned int i, ii;
// 	unsigned int lPadLen;
	GUInt32 ulIn[16];
	GInt32 lMdi;
	GUInt32 i, ii, lPadLen;
	
	/* save number of bits */
	ulIn[14] = mdContext->i[0];
	ulIn[15] = mdContext->i[1];
	
	/* compute number of bytes mod 64 */
//	lMdi = (int)((mdContext->i[0] >> 3) & 0x3F);
	lMdi = (GInt32)((mdContext->i[0] >> 3) & 0x3F);
	
	/* pad out to 56 mod 64 */
	lPadLen = (lMdi < 56) ? (56 - lMdi) : (120 - lMdi);
	MD5Update (mdContext, g_byPadding, lPadLen);
	
	/* append length ulIn bits and transform */
	for (i = 0, ii = 0; i < 14; i++, ii += 4)
// 		ulIn[i] = (((UINT4)mdContext->ulIn[ii+3]) << 24) |
// 		(((UINT4)mdContext->ulIn[ii+2]) << 16) |
// 		(((UINT4)mdContext->ulIn[ii+1]) << 8) |
// 		((UINT4)mdContext->ulIn[ii]);
		ulIn[i] = (((GUInt32)mdContext->ulIn[ii+3]) << 24) |
				(((GUInt32)mdContext->ulIn[ii+2]) << 16) |
				(((GUInt32)mdContext->ulIn[ii+1]) << 8) |
				((GUInt32)mdContext->ulIn[ii]);
	Transform (mdContext->buf, ulIn);
	
	/* store buffer ulIn digest */
	for (i = 0, ii = 0; i < 4; i++, ii += 4) {
		mdContext->digest[ii] = (GUInt8)(mdContext->buf[i] & 0xFF);
		mdContext->digest[ii+1] =
			(GUInt8)((mdContext->buf[i] >> 8) & 0xFF);
		mdContext->digest[ii+2] =
			(GUInt8)((mdContext->buf[i] >> 16) & 0xFF);
		mdContext->digest[ii+3] =
			(GUInt8)((mdContext->buf[i] >> 24) & 0xFF);
	}
}

static GVoid MDString ( MD5_CTX *mdContext, GByte *inString, GUInt32 len )
{

	MD5Init( mdContext );
	MD5Update( mdContext, inString, len );
	MD5Final( mdContext );
		
}

// GRESULT pw_MD5(GByte *pInputString, GInt32 lInputLen, GByte *pOutputString, GInt32 *plOutputLen )
// {
// 	GRESULT res=GOK;
// 	MD5_CTX mdContext={0};
// 	GInt32 i;
// 	if(pOutputString == GNull)
// 		return GERR_INVALID_PARAM;
// 
// 	MDString ( &mdContext, pInputString, lInputLen );
// 
// 	for (i=0; i<16; i++)
// 	{
// 		pOutputString[i] = mdContext.digest[i];
// 	}
// 	*plOutputLen = 16;
// 	return res;
// }

GInt32 pw_MD5(GByte *pInputString, GInt32 lInputLen, GByte *pOutputString )
{
	MD5_CTX mdContext={0};
	GInt32 i;

	MDString ( &mdContext, pInputString, lInputLen );

	for (i=0; i<16; i++)
	{
		pOutputString[i] = mdContext.digest[i];
	}
	return 16;
}

GInt32 pw_seEncryption(GChar *pstrSrc, GChar *pstrSeed, GChar *pstrDst, GInt32 lDstBufflen )
{
	GInt32 res=0;
	GByte strDst_1[20]={0}, TempStr2[64]={0}, strDst_2[20]={0};
	GByte Map[20]={0, 1, 2, 3, 5, 7, 11, 13, 17, 19, 24, 29, 31, 37, 41, 43, 47, 53, 57, 59};
	GInt32 lSrcLen, lSeedLen, lSrcTo, lDstLen1, i, lDstLen2;
	if( GNull == pstrSrc || GNull == pstrSeed || GNull == pstrDst || lDstBufflen <= 20 )
		return 1;

	pstrDst[0] = '\0';// '/0'
	i=0;	
	while( i<256 ){
		if( 0 == pstrSrc[i] )	break;
		i++;
	}
	if( i >= 256 )	return 2;
	lSrcLen=i;
	i=0;	
	while( i<256 ){
		if( 0 == pstrSeed[i] )	break;
		i++;
	}
	if( i >= 256 )	return 3;
	lSeedLen=i;

	lDstLen1 = pw_MD5( (GByte*)pstrSrc, lSrcLen, strDst_1 );

	for ( i=0; i<20; i+=2 )
	{
		GInt32 tt = strDst_1[i>>1];
		tt %= 32;
		pstrDst[i] = tt < 10 ? '0' + tt : 'A' + tt - 10;
	}

	lSrcTo = PW_MIN( lSeedLen, 24 );

	for (i=0; i<lSrcTo; i++)	TempStr2[i] = pstrSeed[i];

	TempStr2[i] = '\0';// '/0'

	for (i=0; i<lDstLen1; i++)
	{
		GByte* pt = TempStr2 + lSrcTo + i * 2, vt;
		vt = strDst_1[i]>>4;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;	pt++;
		vt = strDst_1[i]&0x0f;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;
	}
	lSrcTo += lDstLen1;
	lDstLen2 = pw_MD5( (GByte*)TempStr2, lSrcTo, strDst_2 );

	for ( i=0; i<20; i+=2 )
	{
		GInt32 tt = strDst_2[i>>1];
		tt %= 32;
		pstrDst[i+1] = tt < 10 ? '0' + tt : 'A' + tt - 10;
	}
	pstrDst[20] = '\0';

EXT:
	return res;
}



// long pw_seEncryption(GString *pSrcString, GString *pSeedString, GString *pDstString)
// {
// 	GRESULT res=GOK;
// 	GByte TempStr1[64]={0}, TempStr2[64]={0}, TempStr3[64]={0};
// 	GByte Map[20]={0, 1, 2, 3, 5, 7, 11, 13, 17, 19, 24, 29, 31, 37, 41, 43, 47, 53, 57, 59};
// 	GLong Len, i, Len1;
// 	if( GNull==pSrcString || GNull==pSeedString || GNull==pDstString )
// 		return GERR_INVALID_PARAM;
// 	if( GNull==pSrcString->StringP.bpStr || GNull==pSeedString->StringP.bpStr )
// 		return GERR_INVALID_PARAM;
// 	if (pSrcString->StrType==wcharpoint || pSeedString->StrType==wcharpoint)
// 		return GERR_INVALID_PARAM;
// 	
// //	memset(pDstString->StringP.bpStr, 0, 40);
// 	for (i=0; i<40; i++)
// 	{
// 		pSeedString->StringP.bpStr[i] = 0;
// 	}
// 	//MD5(pSrcString, TempStr);
// 	pw_MD5(pSrcString->StringP.bpStr, pSrcString->StrLen, TempStr1, &Len);
// 
// 	Len1 = PW_MIN(pSeedString->StrLen, 24);
// //	stack_memcpy(TempStr2, pSeedString->StringP.bpStr, Len1);
// 	for (i=0; i<Len1; i++)
// 	{
// 		TempStr2[i] = pSeedString->StringP.bpStr[i];
// 	}
// // 	for (i=0; i<Len; i++)
// // 	{
// // 		sprintf(pDstString->StringP.cpStr+i*2, "%02x", TempStr1[i]);
// //	}
// 
// 	for (i=0; i<Len; i++)
// 	{
// //		sprintf((GChar*)TempStr2+Len1+i*2, "%02x", TempStr1[i]);
// 		GByte* pt = TempStr2+Len1+i*2, vt;
// 		vt = TempStr1[i]>>4;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;	pt++;
// 		vt = TempStr1[i]&0x0f;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;
// 	}
// 	pw_MD5(TempStr2, pSrcString->StrLen, TempStr3, &Len);
// 	for (i=0; i<Len; i++)
// 	{
// //		sprintf((GChar*)TempStr2+i*2, "%02x", TempStr3[i]);
// 		GByte* pt = TempStr2+i*2, vt;
// 		vt = TempStr3[i]>>4;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;	pt++;
// 		vt = TempStr3[i]&0x0f;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;
// 	}
// 	for (i=0; i<Len; i++)
// 	{
// //		sprintf((GChar*)TempStr2+(Len+i)*2, "%02x", TempStr1[i]);
// 		GByte* pt = TempStr2+(Len+i)*2, vt;
// 		vt = TempStr2[i]>>4;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;	pt++;
// 		vt = TempStr2[i]&0x0f;	if(vt<10)	*pt = '0'+vt;	else *pt = 'a'+vt-10;
// 	}	
// 	for (i=0; i<20; i++)
// 	{
// 		long tt = Map[i];
// 		pDstString->StringP.bpStr[i] = TempStr2[tt];
// 	}
// 
// 	pDstString->StrLen = 20;
// 	pDstString->StringP.bpStr[20] = 0;
// 
// EXT:
// 	return res;
// }
