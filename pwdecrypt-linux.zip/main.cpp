#include "media/Video.h"
#include "media/pw_split_video.h"
#include "pw_desecu/pw_desecu.h"
#include "codec/pw_base_api.h"
#include "codec/ffmpeg_codec.h"
#include "record/mp4_recorder.h"
#include "record/g711a_decoder.h"
#include <getopt.h>
#include <memory>

struct Param
{
    char src[256];
    char user[6];
    int dev;
    int clip[3];
    bool check;
};

// 将长参数转换成短参数
// "AB:C::"表示：A后面没有参数；B后面有参数；C后面可以有参数，也可以没有，有的话必须紧跟选项
const char *optstring_from_long_options(const struct option *opt)
{
    static char optstring[256] = {0};
    char *osp = optstring;

    for(; opt->name != NULL; opt++) {
        if(opt->flag == 0 && opt->val >= 'A' && opt->val <= 'z') {
            *osp++ = opt->val;
            switch (opt->has_arg){
            case optional_argument:
                *osp++ = ':';
                *osp++ = ':';
                break;
            case required_argument:
                *osp++ = ':';
                break;
            default:
                break;
            }
        }
    }

    return optstring;
}

Param parseParas(int argc, char *argv[])
{
    char opt;
    int option_index = 0;
    Param param;
    memset(&param, 0, sizeof(param));
    memset(param.clip, -1, sizeof(param.clip));

    struct option long_options[] = {
        {"src", required_argument, NULL, 's'},
        {"user", required_argument, NULL, 'u'},
        {"dev", required_argument, NULL, 'd'},
        {"clip", required_argument, NULL, 'c'},
        {"check", no_argument, NULL, 'k'},
        {NULL, 0, 0, 0}
    };

    const char *optstring = optstring_from_long_options(long_options);
	while((opt = getopt_long(argc, argv, optstring, long_options, &option_index)) != -1) {
		switch(opt) {
        case 's':
            strcpy(param.src, optarg);
            break;

        case 'u':
            strncpy(param.user, optarg, 6);
            break;

        case 'd':
            param.dev = atoi(optarg);
            break;

        case 'c':
            optind--;
            for(int i = 0; optind < argc && *argv[optind] != '-'; optind++, i++)
                param.clip[i] = atoi(argv[optind]);
            break;

        case 'k':
            param.check = true;
            break;

        default:
            printf("Parameters error!\n");
            break;
		}
	}

    return param;
}

bool checkGreen(GVM_SCREEN *yuv)
{
    int width = yuv->lWidth;
    int height = yuv->lHeight;

    int total_y = 0;
    int w_samples = width / 20;
    int h_samples = height / 20;
    for (int i = width - 1; i >= width - w_samples; --i) {
        for (int j = height - 1; j >= height - h_samples; --j)
            total_y += ((uint8_t *)yuv->PixelArray.planar.pPixelArray[0])[i + j * width];
    }
    int total_u = 0;
    for (int i = width / 2 - 1; i >= (width - w_samples) / 2; --i) {
        for (int j = height / 2 - 1; j >= (height - h_samples) / 2; --j)
            total_u += ((uint8_t *)yuv->PixelArray.planar.pPixelArray[1])[i + j * width / 2];
    }
    int total_v = 0;
    for (int i = width / 2 - 1; i >= (width - w_samples) / 2; --i) {
        for (int j = height / 2 - 1; j >= (height - h_samples) / 2; --j)
            total_v += ((uint8_t *)yuv->PixelArray.planar.pPixelArray[2])[i + j * width / 2];
    }
    int total_sample = w_samples * h_samples;

    if (total_y / total_sample < 5 && total_u / (total_sample / 4) < 5 && total_v / (total_sample / 4) < 5) {
        printf("[checkGreen]: y=%d u=%d v=%d\n", total_y / total_sample,
               total_u / (total_sample / 4), total_v / (total_sample / 4));
        return false;
    }
    return true;
}

GVM_SCREEN *decode(uint8_t *data, int len, PSV_VIDEO_NAL &nalu_info, PSV_SPS_INFO &sps_info)
{
    GVM_SCREEN *yuv = nullptr;

    PwFrameVideo frameVideo;
    frameVideo.encType = nalu_info.lEncType;
    frameVideo.isIFrame = nalu_info.bIFrame;
    frameVideo.width = sps_info.lWidth;
    frameVideo.height = sps_info.lHeight;

    int offset = len - nalu_info.lLen_IPNal;
    frameVideo.setData(nalu_info.pbyVPS, nalu_info.lLen_VPS,
                       nalu_info.pbySPS, nalu_info.lLen_SPS,
                       nalu_info.pbyPPS, nalu_info.lLen_PPS,
                       data + offset, len - offset);

    std::unique_ptr<PwFFmpegCodec> decoder(new PwFFmpegCodec());

    if (frameVideo.isIFrame && !decoder->isConfiged()) {
        decoder->config(frameVideo.encType, frameVideo.width, frameVideo.height);
    }

    if (decoder->isConfiged()) {
        int result = decoder->inputData(&frameVideo, &yuv);
        // decoder->flush();
    }

    decoder->stop();

    return yuv;
}

int main(int argc, char **argv)
{
    Param param = parseParas(argc, argv);
    int clip_chn = param.clip[0];
    int clip_start = param.clip[1];
    int clip_end = param.clip[2];
    // if (clip_chn == -1)
    //     printf("clip all\n");
    // else
    //     printf("clip channel:%d start:%d end:%d\n", clip_chn, clip_start, clip_end);

    const char *output_dir = "./";
    FILE *files[3] = {nullptr};
    FILE *yuv_file = nullptr;

    PWMP4Recorder recorder;
    recorder.init();
    // recorder.start("save.mp4", 0);

    G711aDecoder audioDecoder;

    int frame_count[3] = {0};

    PwCloudFileParse fileParse;
    fileParse.CreateParse(0);

    if (fileParse.StartParseNewFile(param.src) < 0)
    {
        printf("file not find %s\n", param.src);
        exit(0);
    }

    GChar szPwd[64] = { 0 };
    PDS_DESECU pstPassSec;
    memset(szPwd, 0, sizeof(szPwd));
    snprintf(szPwd, sizeof(szPwd), "%s%u", param.user, param.dev);
	pstPassSec.ResetPswd(szPwd, "default");
	printf("%s\n", szPwd);

    PWH_FRAME_INFO *pstPwhInfo = NULL;
    GUInt64 ullSecurityFlag = 0;

    while(fileParse.IsStartParse())
    {
        pstPwhInfo = fileParse.GetOneFrame();

        /* The frame has been got over */
        if(!pstPwhInfo)
        {
            fileParse.SetStopParse();
            // printf("finished!\n");
            break;
        }

        PSV_VIDEO_NAL stNalInfo = { 0 };
        PSV_SEI_INFO stSeiInfo = { 0 };
        PSV_SPS_INFO stSPSInfo = { 0 };

        if(pstPwhInfo->ullBeVideo)
        {
            if(!psvSplitVideo(pstPwhInfo->pbyData, pstPwhInfo->ulDataLength, &stNalInfo))
                continue;

            if(stNalInfo.lLen_IPNal <= 0)
                continue;

            psvParseSEI(stNalInfo.pbyPWSEI, stNalInfo.lLen_PWSEI, &stSeiInfo);
            psvParseSPS(stNalInfo.pbySPS, stNalInfo.lLen_SPS, &stSPSInfo);

            /* 新增用于判断枪球 */
            int streamChlType = stSeiInfo.ulStreamChl;
            if(pstPwhInfo->ullBeIFrame)
                ullSecurityFlag = stSeiInfo.ullSecurityFlag;

            if(ullSecurityFlag)
            {
                PDS_RES eRes = pstPassSec.DeSecurity(pstPwhInfo->pbyData, pstPwhInfo->ulDataLength);
                if (eRes != PDS_RES_VAL_OK) {
                   printf("desecurity failed %d %d %d\n", eRes, stNalInfo.lLen_PWSEI, stNalInfo.lLen_IPNal);
                }
            }

            if (!files[streamChlType] && (clip_chn == -1 || clip_chn == streamChlType)) {
                char path[256] = {0};
                sprintf(path, "%ssave%d.%s", output_dir, streamChlType, s_enc_type == PSV_ENC_H265 ? "265" : "264");
                files[streamChlType] = fopen(path, "wb");
                if (!files[streamChlType])
                    printf("open file failed %s\n", path);
            }

            if (files[streamChlType] && frame_count[streamChlType] >= clip_start
                && (clip_end == -1 || frame_count[streamChlType] <= clip_end)) {
                fwrite(pstPwhInfo->pbyData, 1, pstPwhInfo->ulDataLength, files[streamChlType]);
                printf("%d %d %d\n", stSeiInfo.ulBeIFrame, pstPwhInfo->ulDataLength, frame_count[streamChlType]);

                PwFrameVideo frameVideo;
                uint8_t *data = pstPwhInfo->pbyData + stNalInfo.lLen_PWSEI;
                int len = pstPwhInfo->ulDataLength - stNalInfo.lLen_PWSEI;
                int offset = len - stNalInfo.lLen_IPNal;
                frameVideo.setData(stNalInfo.pbyVPS, stNalInfo.lLen_VPS,
                                   stNalInfo.pbySPS, stNalInfo.lLen_SPS,
                                   stNalInfo.pbyPPS, stNalInfo.lLen_PPS,
                                   data + offset, len - offset);
                if (recorder.isRecording()) {
                    MP4_MUX_STREAM_INFO streamInfo = {0};
                    streamInfo.frameWidth = stSPSInfo.lWidth;
                    streamInfo.frameHeight = stSPSInfo.lHeight;
                    streamInfo.fps = 15;
                    streamInfo.encType = stNalInfo.lEncType;
                    recorder.inputData(
                        (char*) frameVideo.data,
                        frameVideo.dataLength,
                        stNalInfo.bIFrame ? MP4_MUX_FRAME_TYPE_I : MP4_MUX_FRAME_TYPE_P,
                        &streamInfo,
                        (char*) frameVideo.extraData,
                        frameVideo.extraDataLength
                        );
                }

                if (pstPwhInfo->ullBeIFrame && param.check) {
                    // printf("I %d\n", frame_count[streamChlType]);
                    auto *yuv = decode(pstPwhInfo->pbyData + stNalInfo.lLen_PWSEI,
                                       pstPwhInfo->ulDataLength - stNalInfo.lLen_PWSEI,
                                       stNalInfo, stSPSInfo);
                    if (yuv) {
                        auto *yuv_data = (uint8_t *)yuv + sizeof(GVM_SCREEN);
                        int yuv_size = yuv->lWidth * yuv->lHeight * 3 / 2;

                        if (!checkGreen(yuv)) {
                            printf("[E] green at chn=%d frame=%d time=%d/%d/%d-%02d:%02d:%02d\n",
                                   streamChlType, frame_count[streamChlType],
                                   stSeiInfo.ullYear, stSeiInfo.ullMonth, stSeiInfo.ullDay,
                                   stSeiInfo.ullHour, stSeiInfo.ullMinute, stSeiInfo.ullSecond);
                            // if (!yuv_file) {
                            //     yuv_file = fopen("save.yuv", "wb");
                            // }
                            // fwrite(yuv_data, 1, yuv_size, yuv_file);
                        }

                        pwbReleaseImage(yuv);
                    }
                }
            }

            frame_count[streamChlType]++;
        } else {
            audioDecoder.decode(pstPwhInfo->pbyData, pstPwhInfo->ulDataLength);

            if(recorder.isRecording()) {
                MP4_MUX_STREAM_INFO streamInfo = {0};
                recorder.inputData(
                    (char*) audioDecoder.getBuffer(),
                    audioDecoder.getBufferLength(),
                    MP4_MUX_FRAME_TYPE_G711A,
                    &streamInfo,
                    nullptr,
                    0
                    );
            }
        }
    }

    for (FILE *file : files) {
        if (file)
            fclose(file);
    }

    if (recorder.isRecording())
        recorder.stop();
    recorder.release();

    return 0;
}
