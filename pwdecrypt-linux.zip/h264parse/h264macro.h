
#ifndef _H264_MACRO_H_
#define _H264_MACRO_H_

#include "h264datatype.h"

#if defined(ALT_BITSTREAM_READER_LE) && !defined(ALT_BITSTREAM_READER)
#   define ALT_BITSTREAM_READER
#endif

#if !defined(LIBMPEG2_BITSTREAM_READER) && !defined(A32_BITSTREAM_READER) && !defined(ALT_BITSTREAM_READER)
#   if ARCH_ARM && !HAVE_FAST_UNALIGNED
#       define A32_BITSTREAM_READER
#   else
#       define ALT_BITSTREAM_READER
//#define LIBMPEG2_BITSTREAM_READER
//#define A32_BITSTREAM_READER
#   endif
#endif

#define MAX_SPS_COUNT			32
#define MAX_PPS_COUNT			256
#define MAX_PICTURE_COUNT		32

#define EXTENDED_SAR			255

#define QP_MAX_NUM				(51 + 4*6)           // The maximum supported qp

// #    define NEG_SSR32(a,s) ((( int32_t)(a))>>(32-(s)))
// #    define NEG_USR32(a,s) (((uint32_t)(a))>>(32-(s)))
#    define NEG_SSR32(a,s) ((( GInt32)(a))>>(32-(s)))
#    define NEG_USR32(a,s) (((GUInt32)(a))>>(32-(s)))


#   define AV_RB32(x)                           \
    ((((const GUInt8*)(x))[0] << 24) |         \
     (((const GUInt8*)(x))[1] << 16) |         \
     (((const GUInt8*)(x))[2] <<  8) |         \
      ((const GUInt8*)(x))[3])

#   define AV_WB32(p, d) do {                   \
        ((GUInt8*)(p))[3] = (d);               \
        ((GUInt8*)(p))[2] = (d)>>8;            \
        ((GUInt8*)(p))[1] = (d)>>16;           \
        ((GUInt8*)(p))[0] = (d)>>24;           \
    } while(0)

#   define AV_RL32(x)                           \
    ((((const GUInt8*)(x))[3] << 24) |         \
     (((const GUInt8*)(x))[2] << 16) |         \
     (((const GUInt8*)(x))[1] <<  8) |         \
      ((const GUInt8*)(x))[0])

#   define AV_WL32(p, d) do {                   \
        ((GUInt8*)(p))[0] = (d);               \
        ((GUInt8*)(p))[1] = (d)>>8;            \
        ((GUInt8*)(p))[2] = (d)>>16;           \
        ((GUInt8*)(p))[3] = (d)>>24;           \
    } while(0)

#   define AV_RB64(x)                                   \
    (((uint64_t)((const GUInt8*)(x))[0] << 56) |       \
     ((uint64_t)((const GUInt8*)(x))[1] << 48) |       \
     ((uint64_t)((const GUInt8*)(x))[2] << 40) |       \
     ((uint64_t)((const GUInt8*)(x))[3] << 32) |       \
     ((uint64_t)((const GUInt8*)(x))[4] << 24) |       \
     ((uint64_t)((const GUInt8*)(x))[5] << 16) |       \
     ((uint64_t)((const GUInt8*)(x))[6] <<  8) |       \
      (uint64_t)((const GUInt8*)(x))[7])

#   define AV_WB64(p, d) do {                   \
        ((GUInt8*)(p))[7] = (d);               \
        ((GUInt8*)(p))[6] = (d)>>8;            \
        ((GUInt8*)(p))[5] = (d)>>16;           \
        ((GUInt8*)(p))[4] = (d)>>24;           \
        ((GUInt8*)(p))[3] = (d)>>32;           \
        ((GUInt8*)(p))[2] = (d)>>40;           \
        ((GUInt8*)(p))[1] = (d)>>48;           \
        ((GUInt8*)(p))[0] = (d)>>56;           \
    } while(0)

#   define AV_RL64(x)                                   \
    (((uint64_t)((const GUInt8*)(x))[7] << 56) |       \
     ((uint64_t)((const GUInt8*)(x))[6] << 48) |       \
     ((uint64_t)((const GUInt8*)(x))[5] << 40) |       \
     ((uint64_t)((const GUInt8*)(x))[4] << 32) |       \
     ((uint64_t)((const GUInt8*)(x))[3] << 24) |       \
     ((uint64_t)((const GUInt8*)(x))[2] << 16) |       \
     ((uint64_t)((const GUInt8*)(x))[1] <<  8) |       \
      (uint64_t)((const GUInt8*)(x))[0])

#   define AV_WL64(p, d) do {                   \
        ((GUInt8*)(p))[0] = (d);               \
        ((GUInt8*)(p))[1] = (d)>>8;            \
        ((GUInt8*)(p))[2] = (d)>>16;           \
        ((GUInt8*)(p))[3] = (d)>>24;           \
        ((GUInt8*)(p))[4] = (d)>>32;           \
        ((GUInt8*)(p))[5] = (d)>>40;           \
        ((GUInt8*)(p))[6] = (d)>>48;           \
        ((GUInt8*)(p))[7] = (d)>>56;           \
    } while(0)


#endif