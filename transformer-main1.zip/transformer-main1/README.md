# transformer

运行：python main.py \
测试：python test.py

代码解释请查看链接 https://zhuanlan.zhihu.com/p/403433120
r
