#include "FileIo.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "pw_mem.h"

#define fileIO_Null		0
#define fileIO_False		0
#define fileIO_True		1

#define FILEIO_CHECK_PARAMETER( EXT, Src, IllegalValue )		{	if( (IllegalValue) == (Src) ) goto EXT;	}
#define FILEIO_CHECK_PARAMETER_NOT( EXT, Src, legalValue )		{	if( (legalValue) != (Src) ) goto EXT;	}
#define FILEIO_CHECK_PARA_VAL( EXT, Src, IllegalValue, Res, Val )	{	if( (IllegalValue) == (Src) ) {Res=Val;goto EXT;}	}
#define FILEIO_CHECK_PARA_VAL_NOT( EXT, Src, legalValue, Res, Val )	{	if( (legalValue) != (Src) ) {Res=Val;goto EXT;}	}

#define FILEIO_DELETE( pBuff ){			\
	if( pBuff ) delete( pBuff );	\
	pBuff = 0;						\
}

FILE* sdk_OpenFile(char* FileName, const char* OpenMode)
{
    if(FileName == NULL)
        return NULL;
    FILE* fpFile = NULL;
    fpFile = fopen(FileName, OpenMode);
    if(NULL != fpFile)
    {
        return fpFile;
    }
    else
    {
        printf("%s:open InputFile failed:%s", __FUNCTION__, FileName);
        return NULL;
    }
}

void sdk_CloseFile(FILE* pFile)
{
    fclose(pFile);
}

int sdk_ReadFile(FILE* pFile, unsigned char* Buffer, int BufferSize)
{
    return fread(Buffer, 1, BufferSize, pFile);
}

int sdk_WriteFile(FILE* pFile, char* Buffer, int BufferSize)
{
    int WriteSize = 0;
    WriteSize = fwrite(Buffer, 1, BufferSize, pFile);
    return WriteSize;
}

char* sdk_substring(char *ch, int pos, int length)
{
    char* pch = ch;
    pch = pch + pos;
    for(int i = 0; i < length; i++)
        ch[i] = pch[i];
    ch[length] = 0;
    return ch;
}

/*
 */
bool sdk_CheckEndStamp(time_t start, time_t end, time_t* targetend)
{
    if(start > end)                                                                                                         	{   
        *targetend = start;
        return 0;
    }   
    *targetend = end;
    struct tm tm, tm1;
    stack_memcpy(&tm, localtime(&end), sizeof(struct tm));
    stack_memcpy(&tm1, localtime(&start), sizeof(struct tm));
    if(tm.tm_year > tm1.tm_year || tm.tm_mon > tm1.tm_mon || tm.tm_mday > tm1.tm_mday)
    {   
        tm.tm_year = tm1.tm_year; tm.tm_mon = tm1.tm_mon; tm.tm_mday = tm1.tm_mday;
        tm.tm_hour = 23; tm.tm_min = 59; tm.tm_sec = 59; 
        *targetend = mktime(&tm);
    }   
    return 0;
}
//解析indexInfo
#define FIX_DST_OFFSET 7201
int sdk_ParseTFIndexInfo(vector<TF_AlarmFile_t> *tfAlarmFile, char *indexPath,time_t time){
    FILE* fp = NULL;
    //处理时间
    struct tm stm ;

    //IPC is sync
    //time is dst time ? [NO] +3600s 
    time += FIX_DST_OFFSET;
    stack_memcpy(&stm, localtime(&time), sizeof(struct tm));
    //解析头
	
	char buf[32] = {0};
    fp = fopen(indexPath, "r");
    if(fp == NULL)
        return -1;
    
    //printf("%s\n", indexPath);
    fread(buf, 1, 16, fp);
    char* token;
    int version;
    //    for(int i=0; i<16; i++)
    //        printf("%x ", (unsigned char)buf[i]);
    /*
     * 0 1 2 3 4 5 6 7 8 9 A B C D E F
     * V 1 6
     */
    if(buf[0] != 'V')//bad index
    {
        return -1;
    }
    int headIntervalLen = 60;
    
    
    //处理内容
    
    TF_AlarmFile_t tfalarmFile;
    int num_file = 0;
    int file_number = 0;
    while (!feof(fp)) {
        
        fread(buf, 1, 1, fp);
		if(feof(fp))
			break;
        int bits, type = 0;
        
        for(int i = 0; i < ALARM_NUMBERS; i++)
        {
            bits = (buf[0] >> i) & 0x01;
            if(bits > 0)
            {
                switch(i)
                {
                        // 0 0 0 0  0 0 0 0
                        //            4 2 1
                    case 0: type += 1; break;
                    case 1: type += 2; break;
                    case 2: type += 4; break;
                    case 7: type += 100; break;
                        
                }
            }
        }

        if(type >=100) //alarm
        {
            int h, m, s;
            h = file_number / 60;
            m = file_number % 60;
            s = 0;
            
            struct tm tm_target;
            tm_target.tm_year = stm.tm_year;
            tm_target.tm_mon = stm.tm_mon;
            tm_target.tm_mday = stm.tm_mday;
            tm_target.tm_hour = h;
            tm_target.tm_min = m;
            tm_target.tm_sec = s;
            //设置tm_isdst为-1，表示由系统判断当前时区是否处于夏令时
            tm_target.tm_isdst = -1;
        
            time_t target_stamp = mktime(&tm_target);
            
            tfalarmFile.alarm_type=type;
            tfalarmFile.startTime=(int)target_stamp;
//            printf("tfalarmFile.startTime:%d\n",tfalarmFile.startTime);
            tfalarmFile.endTime=(int)(target_stamp+headIntervalLen);
            
            (*tfAlarmFile).push_back(tfalarmFile);
            
            num_file++;
//            printf("file_number===========:%d\n",file_number);
        }
        file_number++;
    }

    fclose(fp);
    
    return num_file;
    
}
//解析indexInfo
//int sdk_ParseTFIndexInfo(vector<TF_AlarmFile_t> *tfAlarmFile, char *indexInfo,int len,time_t time){
//
//    //处理时间
//    struct tm stm ;
//    stack_memcpy(&stm, localtime(&time), sizeof(struct tm));
//
//    //解析头
//    char head[16] = {0};
//    memset(head, 0, 16);
//    stack_memcpy(head, indexInfo, sizeof(head));
//    if(head[0] != 'V')//bad index
//    {
//        return -1;
//    }
//    int headIntervalLen = 60;
//
//
//    //��������
//    char content[len-16];
//    memset(content, 0, len-16);
//    heap_memcpy(content, indexInfo+16, len-16);
//
//
//    TF_AlarmFile_t tfalarmFile;
//
//    int num_file = 0;
//
//    char buf[32] = {0};
//
//    int file_number = 0;
//
//    for (int i = 0; i<sizeof(content); i++) {
//
//        memset(buf, 0, sizeof(buf));
//        sprintf(buf, "%s", &content[i]);
//        int bits, type = 0;
//
//        for(int i = 0; i < ALARM_NUMBERS; i++)
//        {
//            bits = (buf[0] >> i) & 0x01;
//            if(bits > 0)
//            {
//                switch(i)
//                {
//                        // 0 0 0 0  0 0 0 0
//                        //            4 2 1
//                    case 0: type += 1; break;
//                    case 1: type += 2; break;
//                    case 2: type += 4; break;
//                    case 7: type += 100; break;
//
//                }
//            }
//        }
//        if(type >100) //alarm
//        {
//            int h, m, s;
//            h = file_number / 60;
//            m = file_number % 60;
//            s = 0;
//
//            struct tm tm_target;
//            tm_target.tm_year = stm.tm_year;
//            tm_target.tm_mon = stm.tm_mon;
//            tm_target.tm_mday = stm.tm_mday;
//            tm_target.tm_hour = h;
//            tm_target.tm_min = m;
//            tm_target.tm_sec = s;
//            time_t target_stamp = mktime(&tm_target);
//
//            tfalarmFile.alarm_type=type;
//            tfalarmFile.startTime=(int)target_stamp;
//            tfalarmFile.endTime=(int)(target_stamp+headIntervalLen);
//
//            (*tfAlarmFile).push_back(tfalarmFile);
//
//
//            num_file++;
//            printf("file_number===========:%d\n",file_number);
//        }
//        file_number++;
//    }
//    return num_file;
//
//}
int sdk_ParseTFIndexInfoEx(vector<TF_AlarmFile_t> *tfAlarmFile, char *indexInfo,int len,time_t time){

    //����ʱ��
    
	struct tm stm ;
    time += FIX_DST_OFFSET;
    stack_memcpy(&stm, localtime(&time), sizeof(struct tm));

    //����ͷ
    
	char head[16] = {0};
    memset(head, 0, 16);
    stack_memcpy(head, indexInfo, sizeof(head));
    if(head[0] != 'V')//bad index
    {
        return -1;
    }
    int headIntervalLen = 60;


    //��������

    char *content = pw_local_chars_new(len - 16);
	if (!content)
		return -1;
    pw_memset(content, len-16, 0, len-16);
    pw_memcpy(content, len-16, indexInfo+16, len-16);


    TF_AlarmFile_t tfalarmFile;

    int num_file = 0;

//    char buf[32] = {0};

    int file_number = 0;

    for (int i = 0; i<(len - 16)/*sizeof(content)*/; i++) 
	{
//        memset(buf, 0, sizeof(buf));
//        sprintf(buf, "%s", &content[i]);
        char buf = content[i];
        int bits, type = 0;

        for(int i = 0; i < ALARM_NUMBERS; i++)
        {
            bits = (buf >> i) & 0x01;
            if(bits > 0)
            {
                switch(i)
                {
                        // 0 0 0 0  0 0 0 0
                        //            4 2 1
                    case 0: type += 1; break;
                    case 1: type += 2; break;
                    case 2: type += 4; break;
                    case 7: type += 100; break;

                }
            }
        }
        if(type >=100) //alarm
        {
            int h, m, s;
            h = file_number / 60;
            m = file_number % 60;
            s = 0;

            struct tm tm_target;
            tm_target.tm_year = stm.tm_year;
            tm_target.tm_mon = stm.tm_mon;
            tm_target.tm_mday = stm.tm_mday;
            tm_target.tm_hour = h;
            tm_target.tm_min = m;
            tm_target.tm_sec = s;
            //����tm_isdstΪ-1����ʾ��ϵͳ�жϵ�ǰʱ���Ƿ�������ʱ
            
			tm_target.tm_isdst = -1;
            time_t target_stamp = mktime(&tm_target);

            tfalarmFile.alarm_type=type;
            tfalarmFile.startTime=(int)target_stamp;
            tfalarmFile.endTime=(int)(target_stamp+headIntervalLen);

            (*tfAlarmFile).push_back(tfalarmFile);


            num_file++;
//            printf("file_number===========:%d\n",file_number);
        }
        file_number++;
    }
	pw_local_delete(content);
    return num_file;

}

/**
 * ����index�ļ��ж�����ͨ�¼�����������6��������¼�����
 * return��
 * 1:6�����¼��洢
 * 0:��ͨ�¼��洢
 * -1:�ļ�����
 * */
int GuessMin6EventIdx(const char *szIndexPath)
{
    int bMin6Event = fileIO_True;
    FILE *pfR = fileIO_Null;
    int i, lLen, lLast = -6;
    unsigned char *pbyIdx = fileIO_Null, *pbyCur;

    FILEIO_CHECK_PARAMETER(ERREXT, szIndexPath, fileIO_Null );

    pfR = fopen( szIndexPath, "r" );
    FILEIO_CHECK_PARAMETER(ERREXT, pfR, fileIO_Null );

    fseek( pfR, 0, SEEK_END );
    lLen = ftell( pfR );
    if( lLen < 8656 )	goto ERREXT;
    rewind( pfR );
    lLen += 64;
    pbyIdx = pw_local_uchars_new(lLen);
    pw_memset(pbyIdx, lLen, 0, lLen);
    lLen = pw_fread(pbyIdx, lLen, 1, lLen, pfR);
    fclose(pfR);
    pbyCur = pbyIdx + 16;
    for ( i=0; i<8640; i++, pbyCur++ )
    {
        if( !( *pbyCur & 0x80 ) )
            continue;
        if( lLast < 0 )	lLast = i;
        else if( i - lLast >= 6 ){
            lLast = i;
        }
        else{
            bMin6Event = fileIO_False;
            break;
        }
    }
    pw_local_delete(pbyIdx); // FILEIO_DELETE(pbyIdx);
    return bMin6Event;
ERREXT:
    pw_local_delete(pbyIdx); // FILEIO_DELETE(pbyIdx);
    return -1;
}

/**
 * ����index�ļ�
 * */
int sdk_ParseCloudIndexFile(vector<Cloud_AlarmFile_t> *cloudFile, time_t start, time_t end, const char *path)
{
    FILE* fp = NULL;
    int one_min_filenumber = 6, interval = 0,fileInterval = 10; //10: 10s one file
    char indexfile[1024] = {0},indexfileName[256] = {0};
    time_t targetend;
    sdk_CheckEndStamp(start, end, &targetend);
    end = targetend;
    Cloud_AlarmFile_t alarmFile;
    struct tm stm , etm;
    stack_memcpy(&stm, localtime(&start), sizeof(struct tm));
    stack_memcpy(&etm, localtime(&end), sizeof(struct tm));
    
    int num_file = 0;
    char buf[32] = {0};
    char tempfile[1024] = {0};
    sprintf(indexfile, "%spuwell_day_%d%02d%02d.index", path, stm.tm_year+1900, stm.tm_mon+1, stm.tm_mday);
    sprintf(indexfileName, "puwell_day_%d%02d%02d.index", stm.tm_year+1900, stm.tm_mon+1, stm.tm_mday);

    //�ж��Ƿ���6��������¼��ƴ洢
    
	int is6minuteE = GuessMin6EventIdx(indexfile);

    fp = fopen(indexfile, "r");
    if(fp == NULL)
        return -1;
    
//    printf("%s\n", indexfile);
    fread(buf, 1, 16, fp);
    char* token;
    int version;
    //    for(int i=0; i<16; i++)
    //        printf("%x ", (unsigned char)buf[i]);
    /*
     * 0 1 2 3 4 5 6 7 8 9 A B C D E F
     * V 1 6
     */
    if(buf[0] != 'V')//bad index
    {
        return -1;
    }
    
    /*if((token = strstr(buf+6, "version")) != NULL)
     version = atoi(strstr(token, "=") + 1);
     else //version not match
     return -2;*/
    //one_min_filenumber = 60 / version;
    
    int file_number = 0;
    while(!feof(fp))
    {
        fread(buf, 1, 1, fp);
		if(feof(fp))
			break;
        int bits, type = 0;
        for(int i = 0; i < ALARM_NUMBERS; i++)
        {
            bits = (buf[0] >> i) & 0x01;
            if(bits > 0)
            {
                switch(i)
                {
                        // 0 0 0 0  0 0 0 0
                        //            4 2 1
                    case 0: type += 1; break;
                    case 1: type += 2; break;
                    case 2: type += 4; break;
                    case 7: type +=100;break;
                }
            }
        }

        if(type==100&&is6minuteE==1){
            //��������6���Ӵ洢�¼����ƴ洢����ô��¼��û�澯��Ĭ���޸�Ϊ���澯
            type += 1;
        }

        if(type > 0) //alarm
        {
            int h, m, s;
            h = file_number / 360;
            m = (file_number % 360) / 6;
            s = file_number % 6;
            if(type>=100)
                sprintf(tempfile, "%spuwell_%s_%02d_%02d_%02d.264",
                        path, sdk_substring(indexfileName, 11, 8),  h, m, s);
            else
                memset(tempfile, 0, sizeof(tempfile));
            struct tm tm_target;
            tm_target.tm_year = stm.tm_year;
            tm_target.tm_mon = stm.tm_mon;
            tm_target.tm_mday = stm.tm_mday;
            tm_target.tm_hour = h;
            tm_target.tm_min = m;
            tm_target.tm_sec = 10*s;
            //����tm_isdstΪ-1����ʾ��ϵͳ�жϵ�ǰʱ���Ƿ�������ʱ
            tm_target.tm_isdst = -1;
            time_t target_stamp = mktime(&tm_target);
            if(target_stamp >= start && target_stamp <= end)
            {
                strncpy(alarmFile.filename, tempfile, sizeof(tempfile));
                alarmFile.startTime=target_stamp;
                alarmFile.endTime= target_stamp+fileInterval;
                alarmFile.alarm_type = type;

                (*cloudFile).push_back(alarmFile);
                num_file++;
            }
        }
        file_number++;
    }
    fclose(fp);
    return num_file;
}
int sdk_GetStreamFile(vector<AlarmFile_t> *vfile_264, time_t start, time_t end, const char *path)
{
    FILE* fp = NULL;
    int one_min_filenumber = 6, interval = 0; //10: 10s one file
    char indexfile[1024] = {0},indexfileName[256] = {0};
    time_t targetend;
    sdk_CheckEndStamp(start, end, &targetend);
    end = targetend;
    AlarmFile_t alarmFile;
    struct tm stm , etm;
    stack_memcpy(&stm, localtime(&start), sizeof(struct tm));
    stack_memcpy(&etm, localtime(&end), sizeof(struct tm));
                     
    int num_file = 0;
    char buf[32] = {0};
    char tempfile[1024] = {0};
    sprintf(indexfile, "%spuwell_day_%d%02d%02d.index", path, stm.tm_year+1900, stm.tm_mon+1, stm.tm_mday);
    sprintf(indexfileName, "puwell_day_%d%02d%02d.index", stm.tm_year+1900, stm.tm_mon+1, stm.tm_mday);
    fp = fopen(indexfile, "r");
    if(fp == NULL)
        return -1; 
    
//    printf("%s\n", indexfile);
    fread(buf, 1, 16, fp);
    char* token;
    int version;
//    for(int i=0; i<16; i++)
//        printf("%x ", (unsigned char)buf[i]);
    /*
     * 0 1 2 3 4 5 6 7 8 9 A B C D E F 
     * V 1 6
     */
    if(buf[0] != 'V')//bad index 
    {
        return -1;
    }

    /*if((token = strstr(buf+6, "version")) != NULL)
        version = atoi(strstr(token, "=") + 1);
    else //version not match
        return -2;*/
    //one_min_filenumber = 60 / version; 
    
    int file_number = 0;
    while(!feof(fp))
    {                
        fread(buf, 1, 1, fp);
		if(feof(fp))
			break;
        int bits, type = 0;
        for(int i = 0; i < ALARM_NUMBERS; i++)
        {
            bits = (buf[0] >> i) & 0x01;
            if(bits > 0)
            {
                switch(i)
                {
                    // 0 0 0 0  0 0 0 0 
                    //            4 2 1
                    case 0: type += 1; break;
                    case 1: type += 2; break;
                    case 2: type += 4; break;
                    case 7: type +=100;break;
                }
            }
        }   
        if(type > 0) //alarm
        {
            int h, m, s;
            h = file_number / 360;
            m = (file_number % 360) / 6;
            s = file_number % 6;
            if(type>=100)
            sprintf(tempfile, "%spuwell_%s_%02d_%02d_%02d.264",
                    path, sdk_substring(indexfileName, 11, 8),  h, m, s);
            else
                memset(tempfile, 0, sizeof(tempfile));
            struct tm tm_target;
            tm_target.tm_year = stm.tm_year;
            tm_target.tm_mon = stm.tm_mon;
            tm_target.tm_mday = stm.tm_mday;
            tm_target.tm_hour = h;
            tm_target.tm_min = m;
            tm_target.tm_sec = 10*s;
            //设置tm_isdst为-1，表示由系统判断当前时区是否处于夏令时
            tm_target.tm_isdst = -1;
            time_t target_stamp = mktime(&tm_target);
            if(target_stamp >= start && target_stamp <= end)
            {
                strncpy(alarmFile.filename, tempfile, sizeof(tempfile));
                alarmFile.alarm_type = type;
                (*vfile_264).push_back(alarmFile);
            	num_file++;
            }
        }
        file_number++;
    }                
    fclose(fp);   
    return num_file;
}    

/*
功能: 归零index文件对应起始和结束时间的记录
输入起始时间 结束时间  路径  文件所处当天的00:00:00的unix时间
输出 bool 成功或失败
1:得到index header定义的分片信息
2:换算start end 时间到对应分片的start索引和end索引
3:计算出区间起始位置以及长度后 移动文件指针到指定位置, fwrite即可
4:返回成功或者失败
注意:
文件不存在返回false
文件操作失败(fseek fwrite) 返回false
start>= end 超过一天 或者2者不在同一天 会返回false
*/
bool sdk_ResetIndexFile(time_t start, time_t end, const char *path, time_t zero_t)
{
	#define GET_SAVETIME(head)  ((head[3]-'0')*10+(head[4]-'0'))
	#define GET_HEADLEN(head)   ((head[1]-'0')*10+(head[2]-'0'))
	FILE* fp = NULL;
	int save_time = 10;//分片时间 默认10s
	int header_len = 16;//头长 默认16
	char buf[32] = {0};
	
	int start_mill = start-zero_t;
	int end_mill   = end-zero_t;
	int diff       = end_mill-start_mill;
//printf("%d %d %d\n", start_mill, end_mill, diff);
	
	if(start_mill >= 24*3600 || start_mill < 0) {
		return false;
	}
	if(end_mill > 24*3600 || end_mill <= 0) {
		return false;
	}
	if(diff <= 0) {
		return false;
	}
	
    fp = fopen(path, "r+");
    if(fp == NULL)
        return false; 
    fread(buf, 1, 16, fp);
	save_time 	= GET_SAVETIME(buf);
	header_len 	= GET_HEADLEN(buf);
	
	//compute index
	int start_index = start_mill/save_time;
	int end_index 	= end_mill/save_time;
	if(end_mill % save_time != 0) {
		end_index++;
	}
//printf("%d %d\n", start_index, end_index);
	//start len  fwrite
	int start_pos = header_len+start_index;
	int len = end_index-start_index;
	if(fseek(fp, start_pos, SEEK_SET)  < 0) {
		fclose(fp);fp = NULL;
		return false;
	}
	int reset_num = 0;int tmp = 0;
	char zero = '\0';
	for(int i = 0; i < len; i++) {
		if((tmp=fwrite(&zero, sizeof(char), 1, fp)) != 1) {
// printf("%d %d\n", i, tmp);
// printf("%s\n", strerror(errno));
			break;
		}
		reset_num++;
	}
	
    if(fp != NULL) {
		fclose(fp);
	}
// printf("%d %d\n", reset_num, len);
	return (reset_num == len);
}

int sdk_tagFullDayIndex(const char *indexPath){
    
#define GET_SAVETIME(head)  ((head[3]-'0')*10+(head[4]-'0'))
#define GET_HEADLEN(head)   ((head[1]-'0')*10+(head[2]-'0'))
    FILE* fp = NULL;
    int save_time = 10;//分片时间 默认10s
    int header_len = 16;//头长 默认16
    char buf[32] = {0};
 
    fp = fopen(indexPath, "r+");
    if(fp == NULL)
        return -1;
    
    fread(buf, 1, 16, fp);
    save_time     = GET_SAVETIME(buf);
    header_len    = GET_HEADLEN(buf);
    

    
    if(fseek(fp, header_len-1, SEEK_SET)  < 0) {
        fclose(fp);fp = NULL;
        return -1;
    }
    
    char tag = '1';
    if((fwrite(&tag, sizeof(char), 1, fp)) != 1) {
        return -1;
    }
    
    if(fp != NULL) {
        fclose(fp);
    }
    return 1;
}
int sdk_isFullDay(const char *indexPath){
    
#define GET_SAVETIME(head)  ((head[3]-'0')*10+(head[4]-'0'))
#define GET_HEADLEN(head)   ((head[1]-'0')*10+(head[2]-'0'))
    int save_time = 10;//分片时间 默认10s
    int header_len = 16;//头长 默认16
    char buf[32] = {0};
    FILE* fp = NULL;

    fp = fopen(indexPath, "r+");
    if(fp == NULL)
        return -1;
    
    fread(buf, 1, 32, fp);
    save_time   = GET_SAVETIME(buf);
    header_len  = GET_HEADLEN(buf);
    
    if ( buf[header_len-1] == '1') {
        return 1;
    }

    return -1;
}
