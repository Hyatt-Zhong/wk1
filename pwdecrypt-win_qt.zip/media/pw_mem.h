/*
 * 使用规范：
 * 1. 对于固定大小的小内存尽量使用栈
 * 2. 所有栈上的 memcpy 使用 stack_memcpy 替代
 * 3. 所有临时的局部堆内存的操作使用 pw_xxx 全局方法替代
 * 4. 所有堆内存分配后立刻使用 pwmPT 进行保护，且之后任意对该堆内存和其偏移的操作使用 pwmPT 成员方法
 * 6. 类/结构体内会指向堆上内存的成员指针添加 pwmPT 成员对其进行保护
 * 7. 内存的释放要确保在 item_free 返回 0 的情况
 * 8. 函数内操作外部来的 pwmPT 对象要为其添加自动计数 autoRef
 */

#ifndef _PW_MEM_H_
#define _PW_MEM_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "free_list.h"
#include <mutex>

#define MAX_MEM_NODE_SIZE 1024

#define stack_memcpy(DEST, SRC, LEN) memcpy(DEST, SRC, LEN)
#define heap_memcpy(DEST, SRC, LEN) memcpy(DEST, SRC, LEN) // 标记未处理堆操作

class pwmPT;
typedef struct pwmem_pack_st
{
  struct list_head freelist;
  pwmPT  *pclass;
}pwmem_pack_t;

class pwmPT
{
public:
  pwmPT(unsigned char* inbuf,int buf_size){
    p_buf=inbuf;
    m_size=buf_size;
    m_ref=0;
  }

  pwmPT(void){
    p_buf=NULL;
    m_size=0;
    m_ref=0;
    m_type=0; //0:malloc 1:new
  }

  void assign(unsigned char* inbuf,int buf_size){
    p_buf=inbuf;
    m_size=buf_size;
  }

  int clean(){
    m_mutex.lock();
    if (m_ref>0){
        m_mutex.unlock();
       return -1;
    }

    p_buf=NULL;
    m_size=0;
    m_mutex.unlock();
    return 0;
  }

  ~pwmPT(){
    ;
  }

  int add_ref(void){
    int ret;
    m_mutex.lock();
    ret = ++m_ref;
    m_mutex.unlock();
    return ret;
  }
  
  int dec_ref(void){
    int ret;
    m_mutex.lock();
    ret = --m_ref;
    m_mutex.unlock();
    return ret;
  }

  int is_ref(void){
    int ret=0;
    m_mutex.lock();
    if (m_ref>0) ret=1;
    m_mutex.unlock();
    return ret;
  }
  
  void* pw_memcpy(unsigned char* pdst, unsigned char* psrc, int ilen){
    if (pdst>=p_buf && (pdst+ilen)<=(p_buf+m_size))
      return heap_memcpy(pdst,psrc,ilen);
    return NULL;
  }
  
  void* pw_memcpy(unsigned char* psrc, int ilen){
    if ( ilen<=m_size)
      return heap_memcpy(p_buf,psrc,ilen);
    return NULL;
  }

  void pw_set_byte(unsigned char *pdst, unsigned char value)
  {
	if (pdst>=p_buf && (pdst + sizeof(unsigned char)) <= (p_buf + m_size))
		*pdst = value;
  }

  void pw_set_2byte(unsigned char *pdst, short value)
  {
	if (pdst>=p_buf && (pdst + sizeof(short)) <= (p_buf + m_size))
		*((short *)pdst) = value;
  }

  int pw_check_size(unsigned char* pdst, int lenght)
  {
	if((pdst + lenght - p_buf) >  m_size)
	{
		return 0;
	}

	return 1;
  }
  
  unsigned char* getbuf(void){
    return p_buf;
  }

public:
  pwmem_pack_t m_list;
protected:
  unsigned char* p_buf;
  int m_size;
  int m_ref;
  int m_type;
  std::mutex m_mutex;
};


class autoRef
{
public:
  autoRef()
  {}

  void setAutoRef(pwmPT* pt)
  {
	pt->add_ref();
    m_pointer=pt;
  }

  autoRef(pwmPT* pt){
    pt->add_ref();
    m_pointer=pt;
  }

  ~autoRef(){
    m_pointer->dec_ref();
    m_pointer=NULL;
  }

private:
  pwmPT* m_pointer;
};


class pwmem_man
{
public:  
  pwmem_man(){
    int i;

    pwmPT* item;
    INIT_LIST_HEAD(&free_list);
    for(i=0;i<MAX_MEM_NODE_SIZE;i++)
    {
        item = &m_array[i];
        item->m_list.pclass = item;
        pwmem_pack_t *pack=&item->m_list;
        free_list_add(&pack->freelist,&free_list);
    }

  }

  ~pwmem_man(){
    ;
  }
  
  static pwmem_man* instance(){
    return pwmemManIns;
  }

  pwmPT* item_alloc(){
    struct list_head *list;

    m_mutex.lock();
    if ( free_list_empty(&free_list)==1 )
    {
        m_mutex.unlock();
        return NULL;
    }

    list = free_list_get(&free_list);
    m_mutex.unlock();
    pwmem_pack_t *pack=(pwmem_pack_t*)list;
    return pack->pclass;
  }

  int item_free(pwmPT* item){
    pwmem_pack_t *pack=&item->m_list;    
    
    int iret = item->clean();
    if (iret!=0) 
      return iret;

    m_mutex.lock();
    free_list_add(&pack->freelist,&free_list);
    m_mutex.unlock();
    
    return 0;
  }

private:
  pwmPT m_array[MAX_MEM_NODE_SIZE];
  struct list_head free_list;
  std::mutex m_mutex;

private:
    static pwmem_man *pwmemManIns;
};

inline void* pw_local_malloc(int ilen)
{
    void* ptr = malloc(ilen);
    return ptr;
}

inline void pw_local_free(void* ptr)
{
    free(ptr);
}

inline char* pw_local_chars_new(int ilen)
{
    char* ptr = new char[ilen];
    return ptr;
}

inline unsigned char* pw_local_uchars_new(int ilen)
{
    unsigned char* ptr = new unsigned char[ilen];
    return ptr;
}

inline void pw_local_delete(char* ptr)
{
    if(ptr) delete [] ptr;
}

inline void pw_local_delete(unsigned char* ptr)
{
    if(ptr) delete [] ptr;
}

inline void* pw_memset(void* pdst, int dst_len, int c, int n)
{
    if (dst_len < n || pdst == NULL)
        return NULL;
    return memset(pdst, c, n);
}

inline void* pw_memcpy(void* pdst, int dst_len, const void* psrc, int ilen)
{
    if (dst_len < ilen || pdst == NULL || psrc == NULL)
        return NULL;
    return heap_memcpy(pdst, psrc, ilen);
}

inline int pw_fread(void* buf, int buf_len, int size, int n, FILE* fp)
{
    if (buf_len < size * n || buf == NULL || fp == NULL)
        return -1;
    return fread(buf, size, n, fp);
}

inline int pw_set(char* buf, int buf_len, int index, char c)
{
    if (buf_len <= index || buf == NULL)
        return -1;
    buf[index] = c;
    return 0;
}

#endif
