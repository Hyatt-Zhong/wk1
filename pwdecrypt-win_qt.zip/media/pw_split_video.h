﻿#ifndef _PW_SPLIT_VIDEO_H_
#define _PW_SPLIT_VIDEO_H_

#include "pw_datatype.h"
#include "pw_typedef.h"
#include "pwmacro.h"


enum PSV_ENC_TYPE{
	PSV_ENC_UNKNOWN	=0,
	PSV_ENC_H264,
	PSV_ENC_H265,
};

typedef struct _psv_video_nal_
{
	GBool	bIFrame;
	GInt32	lEncType;	//	as PSV_ENC_TYPE
	GUInt8	*pbyPWSEI;
	GUInt32	lLen_PWSEI;
	GUInt8	*pbyRemoPWS;
	GUInt32	lLen_RemoPWS;
	GUInt8	*pbySEI;
	GUInt32	lLen_SEI;
	GUInt8	*pbyVPS;
	GUInt32	lLen_VPS;
	GUInt8	*pbySPS;
	GUInt32	lLen_SPS;
	GUInt8	*pbyPPS;
	GUInt32	lLen_PPS;
	GUInt8	*pbyIPNal;
	GUInt32	lLen_IPNal;
}PSV_VIDEO_NAL;

typedef struct _psv_sps_info_
{
	GInt32	lWidth;
	GInt32	lHeight;
	GInt32	lFPS;
}PSV_SPS_INFO;

typedef struct _psv_sei_info_
{
	GUInt64	ullSecurityFlag;
	GUInt64	ullPanoTypeEx;
	GBool	bUnEncryption;
	GUInt32	ulLensDir	:9;	//	[0~359] : 0/90/180/270
	GUInt32	ulBeVerLens	:1;
	GUInt32	ulBeRotated	:1;
	GUInt32	ulBeIFrame	:1;
	GUInt32 ulStreamChl :3;
	GUInt32	ulExtern	:17;
	GFloat	fViewAngle;
	GFloat	fViewVirAngle;
	GUInt16	ulDefWid;
	GUInt16	ulDefHei;
	GFloat	fFPS;

	/*-- Stream security --*/
	GUInt64	ullINalStart	:24;
	GUInt64	ullPNalStart	:20;
	GUInt64	ullAudioStart	:20;

	GUInt16	usVideoInterSize;
	GUInt16	usAudioInterSize;
	GUInt32	ulSecuDataMaxLen;

	/*-- Absolute time --*/
	GUInt64	ullYear		:38;
	GUInt64	ullMonth	:4;//	1~12
	GUInt64	ullDay		:5;//	1~31
	GUInt64	ullHour		:5;//	0~23
	GUInt64	ullMinute	:6;//	0~59
	GUInt64	ullSecond	:6;//	0~59

	/*-- Current attitude --*/
	GInt16	sPan_10;	//	Pan * 10
	GInt16	sTilt_10;	//	Tilt * 10
	GInt16	sZoom_10;	//	Zoom * 10
	GInt16	sRotate_10;	//	Rotate * 10

	GFloat		fCenterX;
	GFloat		fCenterY;
	GFloat		fRadius;
	GFloat		fPanoPan;
	GFloat		fPanoTilt;
	GFloat		fPanoRotate;
	GFloat		fPTZPan;
	GFloat		fPTZTilt;
	GFloat		fPTZRotate;
	GFloat		fPTZZoom;

	union{
		struct{
			GUInt16		slTimeOsdWid;
			GUInt16		slTimeOsdHei;
			GUInt16		slTimeOsdPosiX;
			GUInt16		slTimeOsdPosiY;
		}stOsd;
		PW_TIME		stTime;
		GUInt32		ulTimeValue;
	}uTime;

	/*-- 拼接用 --*/
	GUInt32		ulBeUnitArray	:1;         //0:老版本, 1:新版本
	GUInt32		ulUnitExtern	:31;
	union{
		struct{
			GUInt64	ullPan10		:11;	// 镜头水平视场角10倍取整<2000
			GUInt64	ullTilt10		:11;	// 镜头俯仰视场角10倍取整<2000
			GUInt64	ullRgtOffX		:15;	// 右图相对左图偏移量，结果图宽等于sRgtOffX + usArcWid，必>0
			GUInt64	ullRgtOffY		:13;	// 右图相对左图偏移量，结果图高等于usArcHei - |sRgtOffY| * 2
			GUInt64	ullRgtOffYMi	:1;		// 1: RgtOffY < 0, = -ulRgtOffY
			GUInt64	ullb4DirMean	:1;
			GUInt64	ulDefZ10		:7;		// PWPL_DEF_Z [1.0f, 10.0f]最高精确到小数点一位
			GUInt64	ullBe2ndCrt		:1;
			GUInt64 ulFrmDirect		:1;		//左右流标志 0:枪机流左 球机流右 1:球机流左 枪机流右
			GUInt64	ulExtern2		:3;
			GFloat	fMtrX0;
			GFloat	fMtrY0;			// 未做Y轴矫正时为0
			GFloat	fMtrX1Y2;
			GFloat	fMtrX3Y4;
			GFloat	fMtrX5;	
			GFloat	fMtrY5;			// 未做Y轴矫正时为0
			GFloat	af2ndMtrLft[9];
			GFloat	af2ndMtrRgt[9];
		}stOld;
		GUInt8	abyUnitData[128];
	}uUnitCfg;

    /* 直接转发给app的参数 */
    union{
        struct{
        	GUInt32 ulFrmDirect	:1;		//左右流标志 0:枪机流左 球机流右 1:球机流左 枪机流右
            GUInt32 ulExtern    :31;
            GUInt32 reserve;
        }stForward;
        GUInt32 ulForward[2];
    }uForward;
    union{
        struct{
            GUInt32 ullCurZoom_10 : 8; /*当前变焦倍数 * 10*/
            GUInt32 ullZoomCurSensor : 3; /*当前sensor*/
            GUInt32 ullZoomSensorSum : 3; /*sensor总数*/
            GUInt32 ullZoomExtern : 11;
            GUInt32 ulExtern : 7;
            GUInt8 byLensZoom[2]; /*各sensor切换时的倍数*/
            GInt16 reserve;
        }stForward;
        GUInt32 ulForward[2];
    }uForward2;

}PSV_SEI_INFO;

typedef struct _psv_jpg_info_
{
	GUInt16	usTopTilt_10;
	GUInt16	usBtmTilt_10;
}PSV_JPG_INFO;


GBool psvSplitVideo( GUInt8 *pbyData, GInt32 lDataLen, PSV_VIDEO_NAL *pstOut );

GBool psvParseSPS( GUInt8 *pbySPS, GInt32 lLen_SPS, PSV_SPS_INFO *pstOut );

GBool psvParseSEI( GUInt8 *pbyPWSEI, GInt32 lLen_PWSEI, PSV_SEI_INFO *pstOut );

GBool psvParseJpgTail( GUInt8 *pbyJpgData, GInt32 lLen, PSV_JPG_INFO *pstOut );

PSV_ENC_TYPE _CheckEnc( GUInt8 *pbyData, GInt32 lDataLen );

#endif	//	_PW_SPLIT_VIDEO_H_



