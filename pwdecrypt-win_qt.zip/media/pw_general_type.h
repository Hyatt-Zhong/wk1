/*
 * pw_general_type.h
 *
 *  Created on:
 *      Author:
 */

#ifndef SDK_PW_GENERAL_TYPE_H_
#define SDK_PW_GENERAL_TYPE_H_

#include <stdio.h>
#include <time.h>

typedef unsigned char uint8;

typedef unsigned int uint32;

typedef unsigned short uint16;

typedef	unsigned long long	uint64;


struct SDK_TIME
{
	uint32 nYear;
	uint32 nMonth;
	uint32 nDay;
	uint32 nHour;
	uint32 nMinute;
	uint32 nSecond;
};

struct server_publish_app_temporary_credential
{
	uint32 device_id;
	uint32 user_id;
	uint32 cloud_provider_id;
	char  aws_file_path[64];
	char  access_key_id[32];
	char  secret_access_key[64];
	char  session_token[2048];
	uint32 effective_video_start_time;
	uint32 effective_video_end_time;
	uint32 credential_lose_time;
	char  host[64];
	char  region[32];
	char  server[16];
};

//struct client_3_login_req
//{
//    char user_name[64];
//    char pass[64];
//    uint16 lang;
//    uint16 user_type;  // 0:ipc365 1:showmo 2:IPC360
//    uint32 os_type;     // add 0:Android  1:IOS  2:IOS_dev
//    char token[192];
//    uint32 token_type;
//};

typedef struct Read264Info
{
    unsigned char *frame_buf;
    int frame_type;  /* 0:I frame  1:P frame */
    time_t stimestamp;
    time_t etimestamp;
    char file_264[1024];
    int  file_sequence;
    int  max_264file;
    bool read_start;
	unsigned int read_mode;
    unsigned int decode_video_done;
    int read_frame_index;
    Read264Info()
    {
        frame_buf = NULL;
        frame_type = -1;
        max_264file = 0;
        file_sequence = 0;
        stimestamp = 0;
        etimestamp = 0;
        decode_video_done = 0;
		read_mode = 0;
        read_start = false;
        read_frame_index = -1;
    }
}Read264Info_t;

typedef struct AlarmFile
{
    char filename[1024];
    int alarm_type;
}AlarmFile_t;


typedef bool (*CSDataCallBack)(unsigned char *pBuffer,  int streamType,int framnum,long len, void *pUseData);

#endif /* SDK_PW_GENERAL_TYPE_H_ */
