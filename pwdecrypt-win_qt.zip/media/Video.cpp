#include "Mybs.h"
#include "Video.h"
#include "FileIo.h"
#include <stdlib.h>
#include <string.h>
#include "pw_mem.h"
#include "pw_split_video.h"

#define PWH_PARSE_BUFF_SIZE		( 512 * 1024 )
#define GET_MAX(x,y) 	(((x)>=(y))?(x):(y))

#define H264_START_CODE3  0x03  //start 0x 00 00 01
#define H264_START_CODE4  0x04  //start 0x 00 00 01
#define SIZE_1M  (1024*1024)

FILE* sdk_pVideo_H264_File;
int s_enc_type = PSV_ENC_UNKNOWN;

int PwCloudFileParse::FindFrameStartCode(uint8* Buf, int len)
{
	if (len < 3) return -2;
	
    if(Buf[0] == 0 && Buf[1] == 0 && Buf[2] == 1 )
    {
		return H264_START_CODE3;
    }

	if (len < 4) return -3;
	
    if(Buf[0] == 0 && Buf[1] == 0 && Buf[2] == 0 && Buf[3] == 1)
    {
		return H264_START_CODE4;
    }
	
	return -1;
}

int PwCloudFileParse::GetFrameType(NALU_t* nal)
{
    switch (nal->nal_unit_type) {
    case 19:
        nal->Frametype = FRAME_I; break;
    case 1:
        nal->Frametype = FRAME_P; break;
    case 32:
    case 33:
    case 34:
    case 39:
        nal->Frametype = FRAME_OTHER; break;
    default:
        nal->Frametype = FRAME_OTHER;
        // printf("unknown type: %d\n", nal->nal_unit_type);
    }

    return 0;
}

int PwCloudFileParse::GetFrameType264(NALU_t* nal)
{
    bs_t s;
    int frame_type = 0;
    unsigned char* OneFrameBuf_H264 = nal->buf;
    bs_init(&s, OneFrameBuf_H264 + nal->startcodeprefix_len + 1, nal->len);

    if(nal->nal_unit_type == NAL_SLICE || nal->nal_unit_type == NAL_SLICE_IDR)
    {
        bs_read_ue(&s);
        frame_type = bs_read_ue(&s);
        switch(frame_type)
        {
            case 0:case 5: /* P */
                nal->Frametype = FRAME_P;
				nal->private_head_len = 8;
                break;
            case 1:case 6: /* B */
                nal->Frametype = FRAME_B;
                break;
            case 3:case 8:  /* SP */
                nal->Frametype = FRAME_P;
				nal->private_head_len = 8;
                break;
            case 2:case 7:  /* I */
                nal->Frametype = FRAME_I;
				nal->private_head_len = 16;
                break;
            case 4:case 9:  /* SI */
                nal->Frametype = FRAME_I;
				nal->private_head_len = 16;
                break;
            case 0x1C: /*puwell*/
                nal->Frametype = FRAME_I;
				nal->private_head_len = 16;
                break;
            case 0x1D: /*puwell*/
                nal->Frametype = FRAME_P;
				nal->private_head_len = 8;
                break;
            case 0x1A: /*puwell*/
                nal->Frametype = FRAME_A;
				nal->private_head_len = 8;
        }
    }
    else if(nal->nal_unit_type == NAL_SEI ||
            nal->nal_unit_type == NAL_SPS ||
            nal->nal_unit_type == NAL_PPS) {
        nal->Frametype = FRAME_OTHER;
    } else if(nal->nal_unit_type == NAL_I) {
        nal->Frametype = FRAME_I;
		nal->private_head_len = 16;
    } else if(nal->nal_unit_type == NAL_P) {
        nal->Frametype = FRAME_P;
		nal->private_head_len = 8;
    }
    else if(nal->nal_unit_type == NAL_A) {
        nal->Frametype = FRAME_A;
		nal->private_head_len = 8;
    }

    return 0;
}

int PwCloudFileParse::GetFrameParamByType(uint8 fcode, uint8* chead, uint32* frame_type, uint32* frame_len)
{
	int head_len = 0;
	if(fcode == 0xFA)
	{
        //---Audio----
        head_len = 8;
        fread(chead, 1, head_len - 4, m_CloudFileHandler);
		Audio_Head_PW_t *audio_head = (Audio_Head_PW_t*)(chead);
//        printf("Audio len: %d\n", audio_head->usDatalen);
		*frame_len = audio_head->usDatalen;
		*frame_type = FRAME_A;
	}
	else if(fcode == 0xFC)
	{
        //---I frame---
        head_len = 16;
        fread(chead, 1, head_len - 4, m_CloudFileHandler);
		IFrame_Head_PW_t *iframe_head = (IFrame_Head_PW_t*)(chead);
//        printf("IFrame len: %d\n", iframe_head->ulDatalen);
		*frame_len = iframe_head->ulDatalen;
		*frame_type = FRAME_I;
	}
	else if(fcode == 0xFD)
	{
        //---P frame---
        head_len = 8;
        fread(chead, 1, head_len - 4, m_CloudFileHandler);
		PFrame_Head_PW_t *pframe_head = (PFrame_Head_PW_t*)(chead);
//        printf("PFrame len: %d\n", pframe_head->ulDatalen);
		*frame_len = pframe_head->ulDatalen;
		*frame_type = FRAME_P;
	}
	
	return head_len;
}


PwCloudFileParse::PwCloudFileParse()
{
	m_CloudFileHandler = NULL;
	m_FrameBuff = NULL;

	memset(m_CloudFilepath, 0, sizeof(m_CloudFilepath));
}

PwCloudFileParse::~PwCloudFileParse()
{
	ReleaseParse();
}

void PwCloudFileParse::ReleaseParse()
{
	if(m_FrameBuff)
	{
		free(m_FrameBuff);
		m_FrameBuff = NULL;
	}
}

int PwCloudFileParse::CreateParse(uint32 uMaxBuffSize)
{
	m_MaxBuffSize = GET_MAX( uMaxBuffSize, PWH_PARSE_BUFF_SIZE );
	m_FrameBuff = (unsigned char *)malloc(m_MaxBuffSize);

	if(!m_FrameBuff)
	{
		return -1;
	}

	m_startParse = false;

	return 0;
}

int PwCloudFileParse::StartParseNewFile(const char *fileName)
{
	/* when start new file other file is in processing */
	if(m_CloudFileHandler)
	{
		fclose(m_CloudFileHandler);
		m_CloudFileHandler = NULL;
	}

	if(!m_FrameBuff)
	{
		return -1;
	}

	memset(m_CloudFilepath, 0, sizeof(m_CloudFilepath));
	snprintf(m_CloudFilepath, sizeof(m_CloudFilepath), "%s", fileName);
	memset(m_FrameBuff, 0, m_MaxBuffSize);

	m_CloudFileHandler = fopen(m_CloudFilepath, "rb");
	if(!m_CloudFileHandler)
	{
		m_startParse = false;
		return -1;
	}

    unsigned char buf[16] = {0};
    if (fread(buf, 1, 16, m_CloudFileHandler) < 0)
        return -1;

    if (!(buf[0] == 0x78 && buf[1] == 0x56 && buf[2] == 0x34)) {
        fseek(m_CloudFileHandler, -16, SEEK_CUR);
        parse_type_ = PARSE_TYPE_CLOUD;
    }

	m_startParse = true;
	return 0;
}

int PwCloudFileParse::_GetH264HeadFromFile()
{
	unsigned char Buf[16]={0};
	int len, ret;
	int startof = 0;

	len = fread(Buf, 1, 4, m_CloudFileHandler);
    if(len < 4 )
    {
        return -1;
    }
	
    startof = FindFrameStartCode(Buf, 4);    //buf is 0x 00 00 01?
    while(startof <= 0)
    {
    	Buf[0] = Buf[1]; Buf[1] = Buf[2]; Buf[2] = Buf[3];
        //If Buf is not 0x00 00 01, then read one more byte
        if(1 != fread(Buf + 3, 1, 1, m_CloudFileHandler))
        {
            return -2;
        }
		startof = FindFrameStartCode(Buf,4);
    }
    if (startof == 3)
        fseek(m_CloudFileHandler, -1, SEEK_CUR);

	return startof;
}

int PwCloudFileParse::_GetAnnexH264(NALU_t* nalu, int has_startof, unsigned char* pre_buf, int pre_buflen)
{
    int pos = 0;
    int rewind = 0;
    unsigned int ret = -1, frame_len = -1, head_len = 0;
	int startof = 0;
	unsigned char c4;

    if(NULL == nalu || NULL == m_CloudFileHandler)
    {
		return -1;
    }

    if(nalu->buf == NULL)
    {
		printf("GetAnnexNALU Error: Could not allocate Buf memory..\n");
        return -1;
    }
    
	if(has_startof <= 0)
	{
		startof = _GetH264HeadFromFile();
		if(startof == H264_START_CODE3)
		{
			nalu->buf[0] = 0; nalu->buf[1]=0; nalu->buf[2]=1;
		}
		else if(startof == H264_START_CODE4)
		{
			nalu->buf[0] = 0; nalu->buf[1] = 0; nalu->buf[2] = 0; nalu->buf[3] = 1;
		}

		pos = startof;
		nalu->startcodeprefix_len = startof;
	}
	else
	{
		heap_memcpy(nalu->buf, pre_buf, pre_buflen);
		pos = pre_buflen;
		nalu->startcodeprefix_len = has_startof;
	}

    int i = 0;
	startof = 0;

	//将h264帧内容读取到buf中，直到读取到下一个start_code
    while(startof <= 0)
    {
        if(feof(m_CloudFileHandler))
        {
            nalu->len = (pos - 1) - nalu->startcodeprefix_len;
            return nalu->len;
        }

        nalu->buf[pos++] = fgetc(m_CloudFileHandler);
        startof = FindFrameStartCode(nalu->buf + pos - 4, 4);  //check whether Buf is 0x0000 0001
        if (startof > 0 && (pos - 4 < 2))
            startof = -1;
    }
	
    rewind = -4;
    if(0 != fseek(m_CloudFileHandler, rewind, SEEK_CUR))
    {
        printf("GetAnnexNALU Error: Cannot fseek in the bit stream file");
        return -1;
    }
    
    nalu->len = pos + rewind;
    if (s_enc_type == PSV_ENC_UNKNOWN) {
        s_enc_type = _CheckEnc(nalu->buf, nalu->len);
        switch (s_enc_type) {
        case PSV_ENC_UNKNOWN: printf("enc type unknown\n"); break;
        case PSV_ENC_H264: printf("enc type 264\n"); break;
        case PSV_ENC_H265: printf("enc type 265\n"); break;
        }
    }

	startof=nalu->startcodeprefix_len;
    if (s_enc_type == PSV_ENC_H264) {
        nalu->forbidden_bit = nalu->buf[startof] & 0x80;        //1 bit--1000 0000
        nalu->nal_reference_idc = nalu->buf[startof] & 0x60;    //2 bit--0110 0000
        nalu->nal_unit_type = nalu->buf[startof] & 0x1F;        //5 bit--0001 1111
        GetFrameType264(nalu);
    } else if (s_enc_type == PSV_ENC_H265) {
        nalu->nal_unit_type = (nalu->buf[startof] & 0x7E) >> 1; //6 bit--0111 1110
        GetFrameType(nalu);
    } else {
        nalu->Frametype = FRAME_OTHER;
        printf("unknown enc type\n");
    }

    return nalu->len;
}

int PwCloudFileParse::_GetAnnexNALU(NALU_t* nalu)
{
	if(NULL == nalu ||  m_CloudFileHandler == NULL)
	{
		return -1;
	}
		
	unsigned int pre_read_len = 4;
	unsigned char pre_buf[16] = { 0 };
	unsigned int ret = -1, frame_len = -1, head_len = 0,frame_type = 0;
	static int frame_startof=0, info2 = 0, info3 = 0;

   	/* first read 16 byte (puwell private head) */
	ret = fread(pre_buf, 1, pre_read_len, m_CloudFileHandler);
	if(ret < pre_read_len) // file is EOF
	{
		return 0;
	}
	
	frame_startof = FindFrameStartCode(pre_buf, pre_read_len);
	if(frame_startof < 0)
	{ //read private head error  --> read char by char
		nalu->read_mode = 1;
		return _GetAnnexH264(nalu, 0, pre_buf, 0);
	}

	if (frame_startof == H264_START_CODE4)
	{
		nalu->read_mode = 1;
		return _GetAnnexH264(nalu, H264_START_CODE4, pre_buf, pre_read_len);
		//routine for no private_frame_head
	}
	
	nalu->startcodeprefix_len = frame_startof;
	nalu->read_mode = 0;
	//私有头的起始位0x000001+0xFA/0xFC/0xFD,若未找到私有头，则当作普通264处理
	head_len = GetFrameParamByType(pre_buf[frame_startof], pre_buf + frame_startof + 1, &frame_type, &frame_len);
//	  printf("-----head_len:%d frame_type:%d frame_len:%d startof:%d\n", head_len, frame_type, frame_len, frame_startof);
	if(head_len <= 0 || frame_len <= 16 || frame_len >= m_MaxBuffSize)
	{
		//routine for no private_frame_head
		nalu->read_mode = 1;
		return _GetAnnexH264(nalu, H264_START_CODE3, pre_buf, pre_read_len);
	}
	nalu->private_head_len = head_len;
	nalu->Frametype = frame_type;

	//have private_frame_head;
	unsigned char* Buf = nalu->buf;
	if(!Buf)
	{
		printf("GetAnnexNALU Error: Could not allocate Buf memory..\n");
		return -1;
	}

    // unsigned int datalen_inbuf = (pre_read_len - head_len);
	// heap_memcpy(Buf, pre_buf + head_len, datalen_inbuf);
	ret = fread(Buf, 1, frame_len, m_CloudFileHandler);
	if(ret != frame_len)
	{
		return -4;
	}
	
	nalu->len = frame_len;
	nalu->buf = Buf;

	return frame_len;
}

int PwCloudFileParse::_GetAnnexNALUTF(NALU_t* nalu)
{
	if(NULL == nalu ||  m_CloudFileHandler == NULL)
	{
		return -1;
	}

	unsigned int pre_read_len = 12;
	unsigned char pre_buf[12] = { 0 };
	unsigned int ret = -1, frame_len = -1, head_len = 0,frame_type = 0;
	static int frame_startof=0, info2 = 0, info3 = 0;

   	/* first read 16 byte (puwell private head) */
	ret = fread(pre_buf, 1, pre_read_len, m_CloudFileHandler);
	if(ret < pre_read_len) // file is EOF
	{
		return 0;
	}

    FRAME_INFO *frame_info = (FRAME_INFO*)pre_buf;
	nalu->Frametype = frame_info->frm_type;
    frame_len = frame_info->buf_size;

	//have private_frame_head;
	unsigned char* Buf = nalu->buf;
	if(!Buf)
	{
		printf("GetAnnexNALU Error: Could not allocate Buf memory..\n");
		return -1;
	}

    // unsigned int datalen_inbuf = (pre_read_len - head_len);
	// heap_memcpy(Buf, pre_buf + head_len, datalen_inbuf);
	ret = fread(Buf, 1, frame_len, m_CloudFileHandler);
	if(ret != frame_len)
	{ 
		return -4;
	}
	
	nalu->len = frame_len;
	nalu->buf = Buf;

	return frame_len;
}

PWH_FRAME_INFO* PwCloudFileParse::GetOneFrame()
{
    int video_buf_size = 0;
    int ret = -1;
    NALU_t nal;

    memset(m_FrameBuff, 0, m_MaxBuffSize);
    memset(&nal, 0, sizeof(NALU_t));
    nal.buf = m_FrameBuff;

    if (parse_type_ == PARSE_TYPE_TF)
        video_buf_size = _GetAnnexNALUTF(&nal);
    else
        video_buf_size = _GetAnnexNALU(&nal);

    if(video_buf_size <= 0) /*file is EOF or is not h264 file*/
        return NULL;

    memset(&m_StCurOut, 0, sizeof(PWH_FRAME_INFO));
    if(nal.Frametype == FRAME_A)
    {
		m_StCurOut.ullBeVideo = 0;
		m_StCurOut.ullBeIFrame = 0;
    }
    else if(nal.Frametype == FRAME_I || nal.Frametype == FRAME_P)
    {
		m_StCurOut.ullBeVideo = 1;

		if(nal.Frametype == FRAME_I)
			m_StCurOut.ullBeIFrame = 1;
		else
			m_StCurOut.ullBeIFrame = 0;
    }

    m_StCurOut.pbyData = nal.buf;
    m_StCurOut.ulDataLength = nal.len;

    return &m_StCurOut;
}
