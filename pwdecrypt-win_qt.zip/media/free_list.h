/**************************
* implemention of free list ;
*
**************************/
#ifndef __FREE_LIST_H__
#define __FREE_LIST_H__

#include "newlist.h"
#ifdef WIN32
#define _INLINE_ static __inline
#else
#define _INLINE_ static __inline__
#endif

namespace sdk
{

_INLINE_ void free_list_add(struct list_head* elem,struct list_head* free_head)
{
	list_add_tail(elem,free_head);
}

_INLINE_ struct list_head* free_list_get(struct list_head* free_head)
{
	struct list_head* elem;
	if (free_head->next==free_head){
		return NULL;
	}
	elem = free_head->next;
	list_del(elem);
	return elem;
}

_INLINE_ int free_list_empty(struct list_head* free_head)
{
	if (free_head->next==free_head){
		return 1;
	}
	return 0;
}

}
using namespace sdk;
#endif

