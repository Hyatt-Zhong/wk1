#ifndef PW_BASE_API_H
#define PW_BASE_API_H

#include "pw_datatype.h"
#include "pw_typedef.h"
#include "pwmacro.h"

GVM_SCREEN *pwbCreateImage( GInt32 lWidth, GInt32 lHeight, GInt32 lColorSpace );
GVoid pwbReleaseImage( GVM_SCREEN *pstImage );

#endif
