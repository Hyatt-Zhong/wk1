#ifndef ANDROIDSDK_PWFRAMEVIDEO_H
#define ANDROIDSDK_PWFRAMEVIDEO_H

#include <cstdint>
#include <cstring>

class PwFrameVideo {
public:
    bool isIFrame;

    int32_t encType;

    uint8_t *sps;
    int64_t spsLength;

    uint8_t *pps;
    int64_t ppsLength;

    uint8_t *extraData;
    int64_t extraDataLength;

    uint32_t width;
    uint32_t height;
    int64_t dataLength;
    uint8_t *data;

    uint32_t synID;

    uint64_t frameTime;

public:
    ~PwFrameVideo() {
        if (data) {
            delete[] data;
            data = nullptr;
            extraData = nullptr;
            sps = nullptr;
            pps = nullptr;
        }
    }

    bool setData(uint8_t *vpsData, int vpsLen, uint8_t *spsData, int spsLen,
                 uint8_t *ppsData, int ppsLen, uint8_t *inData, int inDataLen) {
        extraDataLength = vpsLen + spsLen + ppsLen;
        dataLength = extraDataLength + inDataLen;
        data = new uint8_t[dataLength];
        if (data) {
            int offset = 0;
            if (extraDataLength > 0) {
                extraData = data;
                memcpy(extraData, vpsData, vpsLen);
                offset += vpsLen;

                memcpy(extraData + offset, spsData, spsLen);
                spsLength = spsLen;
                sps = extraData + offset;
                offset += spsLen;

                memcpy(extraData + offset, ppsData, ppsLen);
                ppsLength = ppsLen;
                pps = extraData + offset;
                offset += ppsLen;
            }
            memcpy(data + offset, inData, inDataLen);
            return true;
        }
        return false;
    }
};

#endif //ANDROIDSDK_PWFRAMEVIDEO_H
