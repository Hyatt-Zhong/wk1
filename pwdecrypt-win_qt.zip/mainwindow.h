#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSettings>
#include <QThread>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class WorkerThread;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void on_btnFileSelector_clicked();
    void on_btnRun_clicked();
    void onStateChanged(int state);

private:
    void append(const QString &info = QString());
    void decrypt();

    Ui::MainWindow *ui;
    QSettings *settings;
    int count;
    QThread *current_thread;
};

class WorkerThread : public QThread
{
    Q_OBJECT

signals:
    void message(const QString& info);

public:
    WorkerThread(QObject* par, Ui::MainWindow *_ui, QSettings *_settings);
    void run() override;

private:
    Ui::MainWindow *ui;
    QSettings *settings;
};

#endif // MAINWINDOW_H
