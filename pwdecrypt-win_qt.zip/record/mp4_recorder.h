#ifndef PWMP4Recorder_hpp
#define PWMP4Recorder_hpp

#include <stdio.h>
#include <mutex>
#include "ffmpeg_mp4_mux.h"

typedef void (*MP4RecorderCallback) (char *Msg, long lUserData);

class PWMP4Recorder {
public:
	PWMP4Recorder ();

	~PWMP4Recorder ();

	void setEventCallback (MP4RecorderCallback cb, long userData);

    void init();

    void release();

	bool start(const char *filePath, int rotation);

	bool inputData (
			char *data, int dataLen, MP4_MUX_FRAME_TYPE frameType,
			MP4_MUX_STREAM_INFO *streamInfo, char *extraData, int extraDataLen
	);

	long stop();

	bool isRecording() { return recording_; };

private:
	FFMPEGMP4Mux *m_ffmpegMp4Mux = nullptr;
	MP4RecorderCallback mEvCb;
	long mEvCbUserData;
	std::recursive_mutex mCtrlMutex;
	long mFrameCount;
	bool recording_ = false;

	friend void MP4MsgCallback (char *msg, long lUserData);
};

#endif /* PWMP4Recorder_hpp */
