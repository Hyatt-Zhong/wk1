#ifndef FFMPEG_MP4Mux_hpp
#define FFMPEG_MP4Mux_hpp

extern "C" {
#include "libavutil/avassert.h"
#include "libavutil/channel_layout.h"
#include "libavutil/opt.h"
#include "libavutil/mathematics.h"
#include "libavutil/imgutils.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavcodec/avcodec.h"
#include "libavcodec/bsf.h"
};

#include <string.h>
#include <math.h>
#include <mutex>
#include "faac.h"
#include "mp4global.h"
#include <inc/pw_datatype.h>

#define SAMPLE_RATE 8000
#define CHANAELS_NUM 1

#define MAX_EXTRA_DATA_LEN 200
#define MAX_FILE_NAME_LEN 512

typedef void (*mp4MsgCallBack)(char *Msg, long lUserData);

typedef enum {
    MP4_MUX_FRAME_TYPE_I,
    MP4_MUX_FRAME_TYPE_P,
    MP4_MUX_FRAME_TYPE_G711A,
} MP4_MUX_FRAME_TYPE;

struct MP4_MUX_STREAM_INFO {
    int frameWidth;
    int frameHeight;
    int fps;
    int encType;
    int format;
};

class FFMPEGMP4Mux {
public:
    bool FFMPEG_StartWrite(const char *filename,const char *rotate);
    /*
     MP4_MUX_STREAM_INFO 用来初始化videoStream
     spsppsData 为 sps + pps 长度一般为：25+48=73
     */
    bool FFMPEG_InputData(const char *data, int nLen, MP4_MUX_FRAME_TYPE type, MP4_MUX_STREAM_INFO *info, const char* extraData, int extraDataLen);
    bool FFMPEG_StopWrite();

    bool FFMPEG_SetEvent(mp4MsgCallBack cb, uint64_t cbUserData) {
        m_ffmpegMp4WriteEventCallback = cb;
        m_ffmpegMp4WriteEventUserData = cbUserData;
        return true;
    }

private:
    void setVideoRotate();
    void setvideoExtraData();
    bool createVideoStream(int encType);
    bool createAudioStream();
    bool initFaacEncoder();
    void closeFAACEncoder();
    bool initFormatContext();
    bool opneFileAndWriteHeader();
    void initStream(int encType);
    bool writeVideoFrame(const char*  data, int nLen,bool keyFrame);
    bool writeAudioFrame(const char*  data, int nLen);
    bool encodePCMToAAC(char* buff,long len);

private:
    char m_extraData[MAX_EXTRA_DATA_LEN];
    int  m_extraDataLen;

    int m_vdts;
    int m_vpts;
    int m_adts;
    int m_apts;


    int m_videoHeight;
    int m_videoWidth;
    int m_fps;

    int m_lastVideoHei;
    int m_lastVideowid;
    int m_lastfps;

    char  m_filename[MAX_FILE_NAME_LEN];
    char  m_rotate[32];

    bool m_initStream;
    bool m_isGetExtra;
    bool m_bSetExtra;
    bool m_bStop = true;
    AVFormatContext * m_formatCxt;
    const AVOutputFormat  * m_outfmt;
    AVStream        * m_video_stream;
    AVStream        * m_audio_stream;
    AVRational        m_video_baseTime;
    AVRational        m_audio_baseTime;
    //AVBitStreamFilterContext* m_aacbsfc;
    AVBSFContext *m_bsfCtx;

    faacEncHandle   m_hAACEncoder;
    faacEncConfigurationPtr m_pAACConfiguration;
    unsigned long    m_nAACMaxOutputBytes;
    unsigned long    m_nAACInputSamples;

    //
    GUInt8* m_pbPCMBuffer;
    GUInt8* m_pbAACBuffer;
    unsigned long      m_nPCMBufferSize;
    int     m_nRecordPos = 0;

    mp4MsgCallBack m_ffmpegMp4WriteEventCallback = NULL;
    uint64_t m_ffmpegMp4WriteEventUserData = 0;

    std::recursive_mutex mutexStopWrite;  //保证异步写数据时写的正确性
};



#endif /* FFMPEG_MP4Mux_hpp */
