#include "mp4global.h"
#include <string>

static signed short A2l[256] =
	{
		-5504, -5248, -6016, -5760, -4480, -4224, -4992, -4736,
		-7552, -7296, -8064, -7808, -6528, -6272, -7040, -6784,
		-2752, -2624, -3008, -2880, -2240, -2112, -2496, -2368,
		-3776, -3648, -4032, -3904, -3264, -3136, -3520, -3392,
		-22016, -20992, -24064, -23040, -17920, -16896, -19968, -18944,
		-30208, -29184, -32256, -31232, -26112, -25088, -28160, -27136,
		-11008, -10496, -12032, -11520, -8960, -8448, -9984, -9472,
		-15104, -14592, -16128, -15616, -13056, -12544, -14080, -13568,
		-344, -328, -376, -360, -280, -264, -312, -296,
		-472, -456, -504, -488, -408, -392, -440, -424,
		-88, -72, -120, -104, -24, -8, -56, -40,
		-216, -200, -248, -232, -152, -136, -184, -168,
		-1376, -1312, -1504, -1440, -1120, -1056, -1248, -1184,
		-1888, -1824, -2016, -1952, -1632, -1568, -1760, -1696,
		-688, -656, -752, -720, -560, -528, -624, -592,
		-944, -912, -1008, -976, -816, -784, -880, -848,
		5504, 5248, 6016, 5760, 4480, 4224, 4992, 4736,
		7552, 7296, 8064, 7808, 6528, 6272, 7040, 6784,
		2752, 2624, 3008, 2880, 2240, 2112, 2496, 2368,
		3776, 3648, 4032, 3904, 3264, 3136, 3520, 3392,
		22016, 20992, 24064, 23040, 17920, 16896, 19968, 18944,
		30208, 29184, 32256, 31232, 26112, 25088, 28160, 27136,
		11008, 10496, 12032, 11520, 8960, 8448, 9984, 9472,
		15104, 14592, 16128, 15616, 13056, 12544, 14080, 13568,
		344, 328, 376, 360, 280, 264, 312, 296,
		472, 456, 504, 488, 408, 392, 440, 424,
		88, 72, 120, 104, 24, 8, 56, 40,
		216, 200, 248, 232, 152, 136, 184, 168,
		1376, 1312, 1504, 1440, 1120, 1056, 1248, 1184,
		1888, 1824, 2016, 1952, 1632, 1568, 1760, 1696,
		688, 656, 752, 720, 560, 528, 624, 592,
		944, 912, 1008, 976, 816, 784, 880, 848,
	};


int mp4_g711a_Decode (unsigned char *src, char *dest, int srclen, int *dstlen) {
	int i;
	unsigned short *pd = (unsigned short *) dest;

	for (i = 0; i < srclen; i++) {
		pd[i] = (unsigned short) A2l[src[i]];
	}

	*dstlen = srclen << 1;
	return 1;
}

int getH264IFrameIndex (char *pBuf, int nSize) {
	int nIFrameIndex = -1;
	int32_t i = 0, lCheckLen;

	lCheckLen = (nSize - 5) < 200 ? (nSize - 5) : 200;

	uint32_t lTemp, lVal, lTT;
	for (; i < lCheckLen; i++) {
		lTemp = pBuf[i];
		lVal = lTemp;
		lTemp = pBuf[i + 1];
		lVal += lTemp << 8;
		lTemp = pBuf[i + 2];
		lVal += lTemp << 16;
		lTemp = pBuf[i + 3];
		lVal += lTemp << 24;
		lTT = pBuf[i + 4];

		if((lVal == 0x01000000) && (CODEC_H264_NAL_I == (lTT & CODEC_H264_NAL_MASK))) {
			nIFrameIndex = i;
			break;
		}
	}
	return nIFrameIndex;
}

int getH264TypeFrameIndex (char *pBuf, int nSize, int typeFrame) {
	int nIFrameIndex = -1;
	int32_t i = 0, lCheckLen;

	lCheckLen = (nSize - 5) < 200 ? (nSize - 5) : 200;

	uint32_t lTemp, lVal, lTT;
	for (; i < lCheckLen; i++) {
		lTemp = pBuf[i];
		lVal = lTemp;
		lTemp = pBuf[i + 1];
		lVal += lTemp << 8;
		lTemp = pBuf[i + 2];
		lVal += lTemp << 16;
		lTemp = pBuf[i + 3];
		lVal += lTemp << 24;
		lTT = pBuf[i + 4];

		if((lVal == 0x01000000) && (typeFrame == (lTT & CODEC_H264_NAL_MASK))) {
			nIFrameIndex = i;
			break;
		}
	}
	return nIFrameIndex;
}
