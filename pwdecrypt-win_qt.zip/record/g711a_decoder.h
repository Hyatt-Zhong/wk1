#ifndef ANDROIDSDK_G711ADECODER_H
#define ANDROIDSDK_G711ADECODER_H

#include <cstdint>

class G711aDecoder {
private:
    static const int16_t A2l[256];

    private:
    uint8_t *buff;
    uint16_t srcLength = 0;

public:
    void release ();

    void decode (uint8_t *inData, uint32_t inDataLength);

    uint8_t *getBuffer ();

    uint16_t getBufferLength ();
};

#endif //ANDROIDSDK_G711ADECODER_H
