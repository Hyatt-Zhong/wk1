#include "mp4_recorder.h"

PWMP4Recorder::PWMP4Recorder () {
	mEvCb = NULL;
}

PWMP4Recorder::~PWMP4Recorder () {
}

void MP4MsgCallback (char *msg, long lUserData) {
	PWMP4Recorder *mp4Recorder = (PWMP4Recorder *) lUserData;
	if(!mp4Recorder) {
		return;
	}
	if(mp4Recorder->mEvCb != NULL && !strcmp("MP4_RECORDER_FRAME_SIZE_CHANGED", msg)) {
		mp4Recorder->mEvCb(msg, mp4Recorder->mEvCbUserData);
	}
}

void PWMP4Recorder::setEventCallback (MP4RecorderCallback cb, long userData) {
	mEvCb = cb;
	mEvCbUserData = userData;
}

void PWMP4Recorder::init() {
    mCtrlMutex.lock();
    if (!m_ffmpegMp4Mux) {
		m_ffmpegMp4Mux = new FFMPEGMP4Mux();
    }
    mCtrlMutex.unlock();
}

void PWMP4Recorder::release() {
    mCtrlMutex.lock();
    if (m_ffmpegMp4Mux) {
        delete m_ffmpegMp4Mux;
        m_ffmpegMp4Mux = nullptr;
    }
    mCtrlMutex.unlock();
}

bool PWMP4Recorder::inputData (
		char *data, int dataLen, MP4_MUX_FRAME_TYPE frameType,
		MP4_MUX_STREAM_INFO *streamInfo, char *extraData, int extraDataLen
) {
    std::lock_guard<std::recursive_mutex> lockGuard(mCtrlMutex);

    if (!m_ffmpegMp4Mux)
        return false;

	bool bres = m_ffmpegMp4Mux->FFMPEG_InputData(
			data, dataLen, frameType, streamInfo, extraData, extraDataLen
	);
	//统计一下帧数
	if(bres) {
		if(mFrameCount == 0) {
			if(frameType == MP4_MUX_FRAME_TYPE_I) {
                mFrameCount++;
			}
		} else {
			if(frameType == MP4_MUX_FRAME_TYPE_I || frameType == MP4_MUX_FRAME_TYPE_P) {
                mFrameCount++;
			}
		}
	}
	return bres;
}

bool PWMP4Recorder::start(const char *filePath, int rotation) {
	std::unique_lock<std::recursive_mutex> lck(mCtrlMutex);
    mFrameCount = 0;

	if (!m_ffmpegMp4Mux)
		return false;

	const char *str_rot = "";
	switch (rotation) {
		case 0:   str_rot = "0";   break;
		case 90:  str_rot = "270"; break;
		case 180: str_rot = "180"; break;
		case 270: str_rot = "90";  break;
		default:  str_rot = "0";   break;
	}

	bool bres = m_ffmpegMp4Mux->FFMPEG_StartWrite(filePath, str_rot);
	if(!bres) {
		return false;
	}
    m_ffmpegMp4Mux->FFMPEG_SetEvent(MP4MsgCallback, (uint64_t) this);
	recording_ = true;
	return true;
}

long PWMP4Recorder::stop() {
	std::unique_lock<std::recursive_mutex> lck(mCtrlMutex);
	recording_ = false;
	if (!m_ffmpegMp4Mux || !m_ffmpegMp4Mux->FFMPEG_StopWrite())
        return 0;
	return mFrameCount;
}
