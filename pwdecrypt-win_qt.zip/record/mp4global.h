#ifndef pwMp4Global_hpp
#define pwMp4Global_hpp

#include <stdio.h>

#define SET_BOX_TYPE(x,y)    sprintf((char *)x,y)
#define SET_OTH_TYPE(x,y)    sprintf((char *)x,y)

#define ENDIAN_LITTLE2BIG_32(x,y)  y=(x&0xff)<<24 | \
                                    (x>>8&0xff)<<16| \
                                    (x>>16&0xff)<<8| \
                                    (x>>24&0xff)

#define ENDIAN_BIG2LITTLE_32(x,y)  y=(x&0xff)<<24 | \
                                    (x>>8&0xff)<<16| \
                                    (x>>16&0xff)<<8| \
                                    (x>>24&0xff)

#define ENDIAN_BIG2LITTLE_16(x,y)  y=(x&0xff)<<8| \
                                    (x>>8&0xff)

#define ENDIAN_LITTLE2BIGEX_32(a,b,c,d,y)  y=((d)<<24|(c)<<16|(b)<<8|(a))
#define ENDIAN_LITTLE2BIGEX_16(a,b,y)  y=((b)<<8|(a))


#define CHECK_BOX_TYPE(x,a,b,c,d,section) {\
    if(x[0]!= a||x[1]!= b||x[2]!= c||x[3]!= d)  goto section; }

#define CHECK_BOX_TYPE_EX(x,a,b,c,d,action) {\
if(x[0]!= a||x[1]!= b||x[2]!= c||x[3]!= d)  action; }

#define JUDGE_BOX_TYPE(x,a,b,c,d)    (x[0]==a && x[1]==b && x[2]==c && x[3]== d)

#define CODEC_H264_NAL_MASK			0x1F
#define CODEC_H264_NAL_P            0x01
#define CODEC_H264_NAL_I			0x05
#define CODEC_H264_NAL_SPS			0x07
#define CODEC_H264_NAL_PPS			0x08
#define CODEC_H264_NAL_SEI			0x06

#define TP_SEI_FLAG_OFFSET      5


typedef struct TAG_ADTS_HEADER
{
    unsigned int syncword;  //The bit string ‘1111 1111 1111
    unsigned int id;        //MPEG identifier, set to ‘1
    unsigned int layer;     //Indicates which layer is used. Set to ‘00’
    unsigned int protection_absent;   //Indicates whether error_check() data is present or not
    unsigned int profile;   //profile used
    unsigned int sampling_frequency_index;  //indicates the sampling frequency
    unsigned int private_bit; //
    unsigned int channel_configuration;  //indicates the channel configuration used.
    unsigned int original_copy;
    unsigned int home;
    //adts_variable_header
    unsigned int copyright_identification_bit; //
    unsigned int copyright_identification_start; //
    unsigned int aac_frame_length;
    unsigned int adts_buffer_fullness;
    unsigned int number_of_raw_data_blocks_in_frame; //
}ADTS_HEADER;

int mp4_g711a_Decode(unsigned char *src, char *dest, int srclen, int *dstlen);
int getH264IFrameIndex(char *pBuf, int nSize);
int getH264TypeFrameIndex(char *pBuf, int nSize,int typeFrame);

#endif /* pwMp4Global_hpp */
