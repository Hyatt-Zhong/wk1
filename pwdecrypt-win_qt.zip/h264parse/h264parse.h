
#ifndef _H264_PARSE_H_
#define _H264_PARSE_H_

#include "pw_datatype.h"
#include "pw_typedef.h"
#include "pwerror.h"
#include "pwmacro.h"

#define H264_OK					0x00
#define H264_PARA_ERR			0x01
#define H264_NOT_COMPLETE		0x02

#define H264_NAL_NALL			0x00
#define H264_NAL_P				0x01
#define H264_NAL_I				0x05
#define H264_NAL_SPS			0x07
#define H264_NAL_PPS			0x08
#define H264_NAL_SEI			0x06
#define H264_NAL_SEI_SELF		0x80

typedef struct SLINCE_DATE_TIME_s					                        
{
	GUInt32	second	:6;		//	秒	0-59
	GUInt32	minute	:6;		//	分	0-59
	GUInt32	hour	:5;		//	时	0-23
	GUInt32	day		:5;		//	日	1-31
	GUInt32	month	:4;		//	月	1-12
	GUInt32	year	:6;		//	年	2000-2063	
}SLINCE_DATE_TIME_t;

typedef struct _i_framehead
{
	GUInt8 flags[4]; //0x00, 0x00, 0x01, 0xfc
	//CT-------
	//unsigned int codeType  :4;
	//unsigned int extWidth  :2;
	//unsigned int extHeight :2;
	//--------
	GUInt8 ct;
	GUInt8 fps;
	GUInt8 width;   
	GUInt8 heith;
	SLINCE_DATE_TIME_t clockTime;  
	GUInt32 frameLen;  //include  head
}T_I_PwFrameHead;

typedef struct _p_framehead
{
	GUInt8 flags[4];//0x00, 0x00, 0x01, 0xfd 
	GUInt32 frameLen; 
}T_P_PwFrameHead;

typedef struct JFA_SLICE_HEADERS_s
{
	GUInt32 SliceType;//帧类型 FA
	GUInt8 CodecType;
	GUInt8 SampRate;
	GUInt32 avSliceLength;//码流数据 
}T_S_PwFrameHead;

typedef struct _nal_info_ 
{
	GUInt32	ulNalType;
	GUInt8	*pNalStart;
	GUInt32	ulNalLength;
}GVM_H264NALINFO, *LPGVM_H264NALINFO;

int H264NalParse( GUInt8 *pbuff, GUInt32 ulBufflen, LPGVM_H264NALINFO pstNalInfoList, GInt32 lListLen, GInt32 *plNalNum);

typedef struct _sps_info_ 
{
	GUInt32	ulFrameWidth;
	GUInt32	ulFrameHeight;
	GFloat	fFrameRate;
}GVM_H264SPSINFO, *LPGVM_H264SPSINFO;

int H264ParseSps( GUInt8 *pbuff, GUInt32 ulBufflen, LPGVM_H264SPSINFO pstH264Info );

#endif