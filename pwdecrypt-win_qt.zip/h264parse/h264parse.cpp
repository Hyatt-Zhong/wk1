
#include "h264parse.h"
#include "h264def.h"

#ifndef HNull
#define HNull 0
#endif
int H264NalParse( GUInt8 *pbuff, GUInt32 ulBufflen, LPGVM_H264NALINFO pstNalInfoList, GInt32 lListLen, GInt32 *plNalNum )
{
	GUInt8 *pCur = pbuff, *pLast=HNull;
	GUInt32 ulLen = ulBufflen;
	GUInt32 ulNalHead1 = 0xffffffff, ulNalHead2 = 0xffffffff;
	GUInt32 ulLastType = H264_NAL_NALL, ulNalNum=0;

	while(ulLen)
	{
		GUInt8 byTemp = *pCur; pCur++;
		ulLen--;

		ulNalHead2 = ulNalHead1;
		ulNalHead1 = (ulNalHead1<<8) + byTemp;
		if( 0x00000001 == ulNalHead2 )
		{	
			if( H264_NAL_NALL != ulLastType )
			{
				if(ulNalNum<lListLen)
				{
					pstNalInfoList[ulNalNum].pNalStart = pLast;
					pstNalInfoList[ulNalNum].ulNalType = ulLastType;
					pstNalInfoList[ulNalNum].ulNalLength = pCur - pLast - 5;
					ulNalNum++;
				}
			}
			byTemp = ulNalHead2 & 0x31;
			switch (byTemp)
			{
			case H264_NAL_P:
			case H264_NAL_I:
			case H264_NAL_SPS:
			case H264_NAL_PPS:
				pLast = pCur;
				ulLastType = byTemp;
				break;
			case H264_NAL_SEI:
				pLast = pCur;
				ulLastType = byTemp;
				if(ulLen>0)
				{
					byTemp = *pCur; pCur++;
					ulLen--;
					if(byTemp>H264_NAL_SEI_SELF)
						ulLastType = H264_NAL_SEI_SELF;
				}
				break;
			}
		}

	}
	if( H264_NAL_NALL != ulLastType )
	{
		if(ulNalNum<lListLen)
		{
			pstNalInfoList[ulNalNum].pNalStart = pLast;
			pstNalInfoList[ulNalNum].ulNalType = ulLastType;
			pstNalInfoList[ulNalNum].ulNalLength = pCur - pLast - 5;
			ulNalNum++;
		}
	}
	*plNalNum = ulNalNum;

	return 0;
}


void de_emulation_prevention(GUInt8 * buf,GUInt32* buf_size)
{
    int i=0,j=0;
    GUInt8 * tmp_ptr=GNull;
    unsigned int tmp_buf_size=0;
    int val=0;

    tmp_ptr=buf;
    tmp_buf_size=*buf_size;
    for(i=0;i<(tmp_buf_size-2);i++)
    {
        //check for 0x00000300 0x00000301
        val=(tmp_ptr[i]^0x00) +(tmp_ptr[i+1]^0x00)+(tmp_ptr[i+2]^0x03);
        if(val==0)
        {
            //kick out 0x03
            for(j=i+2;j<tmp_buf_size-1;j++)
                tmp_ptr[j]=tmp_ptr[j+1];

            //and so we should devrease bufsize
            (*buf_size)--;
        }
    }
}
int H264ParseSps( GUInt8 *pbuff, GUInt32 ulBufflen, LPGVM_H264SPSINFO pstH264Info )
{
	de_emulation_prevention(pbuff,&ulBufflen);
	MpegEncContext test={0};
	GInt32 bit_size = 8 * ulBufflen;
	GVM_H264SPSINFO stDefault = { 0, 0, 0 };
	SPS stSPS = {0};
	GInt32 buffer_size = (bit_size+7)>>3;
	GInt32 iRes;

	if(!pstH264Info) return H264_PARA_ERR;

	*pstH264Info = stDefault;

    test.gb.buffer       = pbuff;
    test.gb.size_in_bits = bit_size;
    test.gb.size_in_bits_plus8 = bit_size + 8;
    test.gb.buffer_end   = pbuff + buffer_size;
    test.gb.index        = 0;

	iRes = ff_h264_decode_seq_parameter_set( &test, &stSPS );

	if(stSPS.mb_width>0) pstH264Info->ulFrameWidth = stSPS.mb_width * 16 - stSPS.crop_left * 2 - stSPS.crop_right * 2;
	if(stSPS.mb_height>0) pstH264Info->ulFrameHeight = stSPS.mb_height * 16 - stSPS.crop_top * 2 - stSPS.crop_bottom * 2;
	if( stSPS.num_units_in_tick>0 && stSPS.time_scale>0 )
		pstH264Info->fFrameRate = (GFloat)stSPS.time_scale / (stSPS.num_units_in_tick * 2);
	else
		pstH264Info->fFrameRate = 0;
	if(iRes)
		return H264_NOT_COMPLETE;

	return H264_OK;
}
