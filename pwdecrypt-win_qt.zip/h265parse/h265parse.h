
#ifndef _H265_PARSE_H_
#define _H265_PARSE_H_

#include "pw_datatype.h"
#include "pw_typedef.h"
#include "pwerror.h"
#include "pwmacro.h"

typedef struct _sps_info_265_
{
	GUInt32	ulFrameWidth;
	GUInt32	ulFrameHeight;
	GFloat	fFrameRate;
}GVM_H265SPSINFO, *LPGVM_H265SPSINFO;

int H265ParseSps( GUInt8 *pbuff, GUInt32 ulBufflen, LPGVM_H265SPSINFO pstH264Info );

#endif