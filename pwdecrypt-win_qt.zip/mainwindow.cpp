#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "media/Video.h"
#include "media/pw_split_video.h"
#include "pw_desecu/pw_desecu.h"
#include "codec/ffmpeg_codec.h"
#include "codec/pw_base_api.h"
#include "record/mp4_recorder.h"
#include "record/g711a_decoder.h"
#include <QFileDialog>

namespace {

bool checkGreen(GVM_SCREEN *yuv) 
{
    int width = yuv->lWidth;
    int height = yuv->lHeight;

    int total_y = 0;
    int w_samples = width / 20;
    int h_samples = height / 20;
    for (int i = width - 1; i >= width - w_samples; --i) {
        for (int j = height - 1; j >= height - h_samples; --j)
            total_y += ((uint8_t *)yuv->PixelArray.planar.pPixelArray[0])[i + j * width];
    }
    int total_u = 0;
    for (int i = width / 2 - 1; i >= (width - w_samples) / 2; --i) {
        for (int j = height / 2 - 1; j >= (height - h_samples) / 2; --j)
            total_u += ((uint8_t *)yuv->PixelArray.planar.pPixelArray[1])[i + j * width / 2];
    }
    int total_v = 0;
    for (int i = width / 2 - 1; i >= (width - w_samples) / 2; --i) {
        for (int j = height / 2 - 1; j >= (height - h_samples) / 2; --j)
            total_v += ((uint8_t *)yuv->PixelArray.planar.pPixelArray[2])[i + j * width / 2];
    }
    int total_sample = w_samples * h_samples;

    if (total_y / total_sample < 5 && total_u / (total_sample / 4) < 5 && total_v / (total_sample / 4) < 5) {
        qDebug("[checkGreen]: y=%d u=%d v=%d", total_y / total_sample,
               total_u / (total_sample / 4), total_v / (total_sample / 4));
        return false;
    }
    return true;
}

GVM_SCREEN *decode(uint8_t *data, int len, PSV_VIDEO_NAL &nalu_info, PSV_SPS_INFO &sps_info)
{
    GVM_SCREEN *yuv = nullptr;

    PwFrameVideo frameVideo;
    frameVideo.encType = nalu_info.lEncType;
    frameVideo.isIFrame = nalu_info.bIFrame;
    frameVideo.width = sps_info.lWidth;
    frameVideo.height = sps_info.lHeight;

    int offset = len - nalu_info.lLen_IPNal;
    frameVideo.setData(nalu_info.pbyVPS, nalu_info.lLen_VPS,
                       nalu_info.pbySPS, nalu_info.lLen_SPS,
                       nalu_info.pbyPPS, nalu_info.lLen_PPS,
                       data + offset, len - offset);

    std::unique_ptr<PwFFmpegCodec> decoder(new PwFFmpegCodec());

    if (frameVideo.isIFrame && !decoder->isConfiged()) {
        decoder->config(frameVideo.encType, frameVideo.width, frameVideo.height);
    }

    if (decoder->isConfiged()) {
        int result = decoder->inputData(&frameVideo, &yuv);
        // decoder->flush();
    }

    decoder->stop();

    return yuv;
}

}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , count(0)
    , current_thread(nullptr)
{
    ui->setupUi(this);

    settings = new QSettings("setting.ini", QSettings::IniFormat);
    ui->lineEditUser->setText(settings->value("decrypt/user").toString());
    ui->lineEditDevId->setText(settings->value("decrypt/device").toString());
    ui->lineEditFilePath->setText(settings->value("decrypt/file").toString());

    ui->textBrowser->setLineWrapMode(QTextEdit::LineWrapMode::NoWrap);

    connect(ui->checkBoxClip, SIGNAL(stateChanged(int)), this, SLOT(onStateChanged(int)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onStateChanged(int state)
{
    if (state == Qt::Checked) {
        ui->spinBoxChn->setEnabled(true);
        ui->spinBoxStart->setEnabled(true);
        ui->spinBoxEnd->setEnabled(true);
    } else if (state == Qt::Unchecked) {
        ui->spinBoxChn->setEnabled(false);
        ui->spinBoxStart->setEnabled(false);
        ui->spinBoxEnd->setEnabled(false);
    }
}

void MainWindow::append(const QString &flag)
{
    if (count >= 1000) {
        count = 0;
        ui->textBrowser->clear();
    }

    count++;
    ui->textBrowser->append(flag);
}

void MainWindow::on_btnFileSelector_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,
                                                    "Choose File",
                                                    settings->value("decrypt/file").toString(),
                                                    "*.264");

    if(!filename.isEmpty()) {
        ui->lineEditFilePath->setText(filename);
    }
}

void MainWindow::on_btnRun_clicked()
{
    if(current_thread) {
        return;
    }

    auto *thread = new WorkerThread(nullptr, ui, settings);
    connect(thread, &WorkerThread::message, this, &MainWindow::append);
    connect(thread, &QThread::finished, this, [this] () {
        append("------");
    });
    connect(thread, &QThread::finished, thread, &QObject::deleteLater);//线程结束后调用deleteLater来销毁分配的内存
    connect(thread, &QObject::destroyed, this, [this] (QObject *obj) {
        if(qobject_cast<QObject*>(current_thread) == obj) {
            current_thread = nullptr;
            ui->btnRun->setEnabled(true);
        }
    });
    thread->start();
    current_thread = thread;

    ui->btnRun->setEnabled(false);
}

WorkerThread::WorkerThread(QObject *par, Ui::MainWindow *_ui, QSettings *_settings)
    : QThread(par)
    , ui(_ui)
    , settings(_settings)
{

}

void WorkerThread::run()
{
    QString src_qstr = ui->lineEditFilePath->text();
    QDir dir(src_qstr);

    auto user = ui->lineEditUser->text().left(6).toStdString();
    auto dev_id = ui->lineEditDevId->text().toStdString();
    auto src = src_qstr.toStdString();
//    bool need_check = ui->checkBoxGreen->isChecked();
    bool need_check = false;
    bool mux = ui->checkBoxMux->isChecked();
    int clip_chn = -1;
    int clip_start = -1;
    int clip_end = -1;
    if (ui->checkBoxClip->isChecked()) {
        clip_chn = ui->spinBoxChn->value();
        clip_start = ui->spinBoxStart->value();
        clip_end = ui->spinBoxEnd->value();
    }

    settings->setValue("decrypt/user", user.c_str());
    settings->setValue("decrypt/device", dev_id.c_str());
    settings->setValue("decrypt/file", src.c_str());

    emit message("[I] Start");
//    if (clip_chn == -1)
//        emit message("[I] Clip all");
//    else
//        emit message(QString("[I] Clip channel:%1 start:%2 end:%3").arg(clip_chn).arg(clip_start).arg(clip_end));

    auto in_file_name = dir.dirName().split(".")[0].toStdString();
    dir.cdUp();
    auto output_dir = dir.path().toStdString();

    static const int MAX_CHN_COUNT = 3;

    FILE *files[MAX_CHN_COUNT] = {nullptr};
//    FILE *yuv_file = nullptr;
    PWMP4Recorder recorder[MAX_CHN_COUNT];
    G711aDecoder audioDecoder;

    int frame_count[MAX_CHN_COUNT] = {0};

    PwCloudFileParse fileParse;
    fileParse.CreateParse(0);

    if (fileParse.StartParseNewFile(src.c_str()) < 0)
    {
        emit message(QString("[E] File not find %1").arg(src.c_str()));
        return;
    }

    GChar szPwd[64] = { 0 };
    PDS_DESECU pstPassSec;
    memset(szPwd, 0, sizeof(szPwd));
    snprintf(szPwd, sizeof(szPwd), "%s%s", user.c_str(), dev_id.c_str());
    pstPassSec.ResetPswd(szPwd, "default");

    PWH_FRAME_INFO *pstPwhInfo = NULL;
    GUInt64 ullSecurityFlag = 0;

    while(fileParse.IsStartParse())
    {
        pstPwhInfo = fileParse.GetOneFrame();

        /* The frame has been got over */
        if(!pstPwhInfo)
        {
            fileParse.SetStopParse();
            emit message("[I] Finished");
            break;
        }

        PSV_VIDEO_NAL stNalInfo = { 0 };
        PSV_SEI_INFO stSeiInfo = { 0 };
        PSV_SPS_INFO stSPSInfo = { 0 };

        if(pstPwhInfo->ullBeVideo)
        {
            if(!psvSplitVideo(pstPwhInfo->pbyData, pstPwhInfo->ulDataLength, &stNalInfo))
                continue;

            if(stNalInfo.lLen_IPNal <= 0)
                continue;

            psvParseSEI(stNalInfo.pbyPWSEI, stNalInfo.lLen_PWSEI, &stSeiInfo);
            psvParseSPS(stNalInfo.pbySPS, stNalInfo.lLen_SPS, &stSPSInfo);

            /* 新增用于判断枪球 */
            int streamChlType = stSeiInfo.ulStreamChl;
            if(pstPwhInfo->ullBeIFrame)
                ullSecurityFlag = stSeiInfo.ullSecurityFlag;

            PDS_RES eRes = PDS_RES_VAL_OK;
            if(ullSecurityFlag)
            {
                eRes = pstPassSec.DeSecurity(pstPwhInfo->pbyData, pstPwhInfo->ulDataLength);
                if (eRes != PDS_RES_VAL_OK && eRes != 9) {
                    emit message(QString("[E] Desecurity failed, errno=%3 chn=%1 frame=%2")
                                 .arg(streamChlType).arg(frame_count[streamChlType]).arg(eRes));
                }
            }

            if ((clip_chn == -1 || clip_chn == streamChlType)) {
                if (mux) {
                    if (!recorder[streamChlType].isRecording()) {
                        recorder[streamChlType].init();
                        char path[1024] = {0};
                        sprintf(path, "%s/%s-decrypted%d.mp4", output_dir.c_str(), in_file_name.c_str(), streamChlType);
                        recorder[streamChlType].start(path, 0);
                    }
                } else if (!files[streamChlType]) {
                    char path[1024] = {0};
                    sprintf(path, "%s/%s-decrypted%d.%s", output_dir.c_str(), in_file_name.c_str(), streamChlType, s_enc_type == PSV_ENC_H265 ? "265" : "264");
                    files[streamChlType] = fopen(path, "wb");
                    if (!files[streamChlType])
                        emit message(QString("[E] Open file failed %1").arg(path));
                }
            }

            if (frame_count[streamChlType] >= clip_start && (clip_end == -1 || frame_count[streamChlType] <= clip_end)) {
                if (recorder[streamChlType].isRecording()) {
                    PwFrameVideo frameVideo;
                    uint8_t *data = pstPwhInfo->pbyData + stNalInfo.lLen_PWSEI;
                    int len = pstPwhInfo->ulDataLength - stNalInfo.lLen_PWSEI;
                    int offset = len - stNalInfo.lLen_IPNal;
                    frameVideo.setData(stNalInfo.pbyVPS, stNalInfo.lLen_VPS,
                                       stNalInfo.pbySPS, stNalInfo.lLen_SPS,
                                       stNalInfo.pbyPPS, stNalInfo.lLen_PPS,
                                       data + offset, len - offset);

                    MP4_MUX_STREAM_INFO streamInfo = {0};
                    streamInfo.frameWidth = stSPSInfo.lWidth;
                    streamInfo.frameHeight = stSPSInfo.lHeight;
                    streamInfo.fps = stSeiInfo.fFPS == 0 ? stSPSInfo.lFPS : stSeiInfo.fFPS;
                    streamInfo.encType = stNalInfo.lEncType;
                    recorder[streamChlType].inputData(
                                (char*) frameVideo.data,
                                frameVideo.dataLength,
                                stNalInfo.bIFrame ? MP4_MUX_FRAME_TYPE_I : MP4_MUX_FRAME_TYPE_P,
                                &streamInfo,
                                (char*) frameVideo.extraData,
                                frameVideo.extraDataLength
                                );
                }

                if (files[streamChlType])
                    fwrite(pstPwhInfo->pbyData, 1, pstPwhInfo->ulDataLength, files[streamChlType]);

                if (pstPwhInfo->ullBeIFrame && need_check && eRes == PDS_RES_VAL_OK) {
                    // printf("I %d\n", frame_count[streamChlType]);
                    auto *yuv = decode(pstPwhInfo->pbyData + stNalInfo.lLen_PWSEI,
                                       pstPwhInfo->ulDataLength - stNalInfo.lLen_PWSEI,
                                       stNalInfo, stSPSInfo);
                    if (yuv) {
                        auto *yuv_data = (uint8_t *)yuv + sizeof(GVM_SCREEN);
                        int yuv_size = yuv->lWidth * yuv->lHeight * 3 / 2;

                        if (!checkGreen(yuv)) {
                            emit message(QString("[W] Green at chn=%1 frame=%2 time=%3/%4/%5-%6:%7:%8")
                                   .arg(streamChlType).arg(frame_count[streamChlType])
                                   .arg(stSeiInfo.ullYear).arg(stSeiInfo.ullMonth).arg(stSeiInfo.ullDay)
                                   .arg(stSeiInfo.ullHour, 2, 10, QLatin1Char('0'))
                                   .arg(stSeiInfo.ullMinute, 2, 10, QLatin1Char('0'))
                                   .arg(stSeiInfo.ullSecond, 2, 10, QLatin1Char('0')));
                            // if (!yuv_file) {
                            //     yuv_file = fopen("save.yuv", "wb");
                            // }
                            // fwrite(yuv_data, 1, yuv_size, yuv_file);
                        }

                        pwbReleaseImage(yuv);
                    }
                }
            }

            frame_count[streamChlType]++;
        } else if (mux) {
            audioDecoder.decode(pstPwhInfo->pbyData, pstPwhInfo->ulDataLength);
            for (int i = 0; i < MAX_CHN_COUNT; ++i) {
                if(recorder[i].isRecording()) {
                    MP4_MUX_STREAM_INFO streamInfo = {0};
                    recorder[i].inputData(
                                (char*) audioDecoder.getBuffer(),
                                audioDecoder.getBufferLength(),
                                MP4_MUX_FRAME_TYPE_G711A,
                                &streamInfo,
                                nullptr,
                                0
                                );
                }
            }
        }
    }

    for (int i = 0; i < MAX_CHN_COUNT; ++i) {
        bool is_write = false;

        if (files[i]) {
            fclose(files[i]);
            is_write = true;
        }

        if (recorder[i].isRecording()) {
            recorder[i].stop();
            recorder[i].release();
            is_write = true;
        }

        if (!is_write)
            continue;

        char path[1024] = {0};
        const char *suffix = mux ? "mp4" : (s_enc_type == PSV_ENC_H265 ? "265" : "264");
        sprintf(path, "%s/%s-decrypted%d.%s", output_dir.c_str(), in_file_name.c_str(), i, suffix);

        auto str = QString("[I] chn:%1 frame_count:%2").arg(i).arg(frame_count[i]);
        if (clip_chn == i) {
        str += QString(" clip %1-%2")
            .arg(clip_start)
            .arg(clip_end > frame_count[i] ? frame_count[i] : clip_end);
        }
        str += QString(" saveto:%1").arg(path);

        emit message(str);
    }
}
