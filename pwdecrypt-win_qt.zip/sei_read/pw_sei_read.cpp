

#include "pw_sei_read.h"
#include "pw_mem.h"
#include <string.h>

#define	PSR_TAG_VER_2	0xF0
#define	PSR_TAG_VER_A	0xF1
#define	PSR_LEN_VER_2	0x34
#define	PSR_LEN_VER_3	0x40
#define	PSR_LEN_VER_4	0x8
#define	PSR_LEN_VER_5	0x2C
#define	PSR_LEN_VER_R	0x10
#define	PSR_LEN_VER_MI	0x40
#define	PSR_LEN_VER_MP	0x18
#define	PSR_LEN_VER_U	0xA8
#define	PSR_LEN_VER_U2	0xC0

#define PSR_SEI_OFF		2

/*-- pH264Content Start with 0xf0 --*/
GInt32	psrCheckLegal( GUInt8* pH264Content )
{
	GInt32 lVersion = -1;
	GByte byLen, byTag, byTail;

	byTag = pH264Content[0];
	byLen = pH264Content[1];
	byTail = pH264Content[PSR_SEI_OFF+byLen];

	if( 0x80 != byTail )				goto ERREXT;

	switch( byTag )
	{
	case PSR_TAG_VER_2:	
		if( 'P' == pH264Content[PSR_SEI_OFF] && 'W' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_2 )
			lVersion = 2;
		else if( 'P' == pH264Content[PSR_SEI_OFF] && '3' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_3 )
			lVersion = 3;
		else if( 'P' == pH264Content[PSR_SEI_OFF] && 'T' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_3 )
			lVersion = 4;
		//一定排在GPW_SMR_INPUT_VER_P前面,根据长度先判断是否为GPW_SMR_INPUT_VER_RLP
		else if( 'P' == pH264Content[PSR_SEI_OFF] && 'P' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_R )
			lVersion = 7;
		else if( 'P' == pH264Content[PSR_SEI_OFF] && 'P' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_4 )//GPW_SMR_INPUT_VER_P
			lVersion = 5;
		else if( 'D' == pH264Content[PSR_SEI_OFF] && 'P' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_5 )
			lVersion = 6;
		else if( 'M' == pH264Content[PSR_SEI_OFF] && 'I' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_MI )
			lVersion = 8;
		else if( 'M' == pH264Content[PSR_SEI_OFF] && 'P' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_MP )
			lVersion = 9;
		else if( 'M' == pH264Content[PSR_SEI_OFF] && 'S' == pH264Content[PSR_SEI_OFF+1] )
			lVersion = 10;
		else if( 'P' == pH264Content[PSR_SEI_OFF] && 'U' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_U )
			lVersion = 11;
		else if( 'U' == pH264Content[PSR_SEI_OFF] && '2' == pH264Content[PSR_SEI_OFF+1] && byLen >= PSR_LEN_VER_U2 )
			lVersion = 12;
		else
			goto ERREXT;

		break;
	case PSR_TAG_VER_A:
		lVersion = 0x0A;
		break;
	default:	goto ERREXT;
	}

ERREXT:
	return lVersion;
}

typedef struct _psr_ser_ver_2
{
	GChar cHead[2];			//	'PW'
	GUInt8 strExt_0[2];		
	GInt16 sSeedLen;
	GUInt8 strExt_1[2];		
	GInt32 lSeedOffset;
	GUInt32 ulCode;			
	GUInt8 byTimeOsdWid;	//	OSD width / 8
	GUInt8 byTimeOsdHei;	//	OSD height / 8
	GUInt8 byTimeOsdPosiX;	//	OSD position--x / 4
	GUInt8 byTimeOsdPosiY;	//	OSD position--y / 4
	GUInt32 ulSecurityFLag;	
	GInt32 lCenterX_1024;
	GInt32 lCenterY_1024;
	GInt32 lRadius_1024;
	GUInt32 ulPanoType;
	GInt32 lPanoTilt;
	GUInt16 lPanoPan_100;	//	0~36000 = fPan * 100
	GInt8 cDefFPS;			//	<0 second / frame; > 0 frame / second; =0 illegal
	GUInt8 byCurFPS;		//	<=30 frame / second; ; > 30 (byCurFPS-30)second / frame; =0 illegal
	GUInt8 byExt_2[4];
}PSR_SEI_VER_2;		//	len = 52 / 0x34

GBool psrCheckVersion_2( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_2 stSeiVersion_2={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GUInt32 ulDefWid, ulDefHei;
	union{
		GVM_PANO_TYPE_00 stType0;
		GUInt32	ulValue;
	}uPanoType32;
	union{
		GVM_PANO_TYPE_01 stType01;
		GUInt64	ullValue;
	}uPanoType64;

	stack_memcpy( &stSeiVersion_2, pbySEIInfo, sizeof(PSR_SEI_VER_3E) );

	uPanoType32.ulValue = stSeiVersion_2.ulPanoType;
	uPanoType64.ullValue = 0;
	if( 1 == uPanoType32.stType0.ulDefNo ){
		ulDefWid = uPanoType32.stType0.ulWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType32.stType0.ulResRateH / uPanoType32.stType0.ulResRateW;
	}else{
		ulDefWid = stSeiVersion_2.ulPanoType & 0x0f000;
		switch(ulDefWid)
		{
		case 0x01000:	ulDefWid	= 768;	ulDefHei	= 576;	break;
		case 0x02000:	ulDefWid	= 1280;	ulDefHei	= 1024;	break;
		case 0x03000:	ulDefWid	= 2048;	ulDefHei	= 1536;	break;
		case 0x04000:	ulDefWid	= 1280;	ulDefHei	= 960;	break;
		case 0x05000:	ulDefWid	= 2448;	ulDefHei	= 2048;	break;
		case 0x06000:	ulDefWid	= 1920;	ulDefHei	= 1080;	break;
		}
	}
	uPanoType64.stType01.ullDefNo		= 0x02;
	uPanoType64.stType01.ullResRateW	= uPanoType32.stType0.ulResRateW;
	uPanoType64.stType01.ullResRateH	= uPanoType32.stType0.ulResRateH;
	uPanoType64.stType01.ullWidth_8		= uPanoType32.stType0.ulWidth_8;
	uPanoType64.stType01.ullRadius_4	= ulDefHei >> 5;
	uPanoType64.stType01.ullLensType	= PW_LENS_TYPE_FISH;
	uPanoType64.stType01.ullLensNo		= 0;	


	pstMsgReturn->pullSecurityFlagPosi = GNull;

	pstMsgReturn->ullPanoTypeEx = uPanoType64.ullValue;
	pstMsgReturn->fCenterX = (GUInt16)(stSeiVersion_2.lCenterX_1024 / 1024.0f + 0.5f);
	pstMsgReturn->fCenterY = (GUInt16)(stSeiVersion_2.lCenterY_1024 / 1024.0f + 0.5f);
	pstMsgReturn->fRadius = (GUInt16)(stSeiVersion_2.lRadius_1024 / 1024.0f + 0.5f);

	pstMsgReturn->fPanoTilt = stSeiVersion_2.lPanoTilt;
	pstMsgReturn->fPanoTilt = PW_MIN( pstMsgReturn->fPanoTilt, 90 );
	pstMsgReturn->fPanoTilt = PW_MAX( pstMsgReturn->fPanoTilt, -90 );

	pstMsgReturn->fPanoRotate = stSeiVersion_2.lPanoPan_100 * 0.01f;

	pstMsgReturn->ulTimeType = 0;
	pstMsgReturn->uTime.stOsd.slTimeOsdWid = stSeiVersion_2.byTimeOsdWid * 8;
	pstMsgReturn->uTime.stOsd.slTimeOsdHei = stSeiVersion_2.byTimeOsdHei * 8;
	pstMsgReturn->uTime.stOsd.slTimeOsdPosiX = stSeiVersion_2.byTimeOsdPosiX * 4;
	pstMsgReturn->uTime.stOsd.slTimeOsdPosiY = stSeiVersion_2.byTimeOsdPosiY * 4;

	pstMsgReturn->fDefaultFPS = stSeiVersion_2.cDefFPS >= 0 ? 
		stSeiVersion_2.cDefFPS : 1.0f / stSeiVersion_2.cDefFPS;
	pstMsgReturn->fCurrentFPS = stSeiVersion_2.byCurFPS <= 128 ? 
		stSeiVersion_2.byCurFPS : 1.0f / ( stSeiVersion_2.cDefFPS - 128 );
	pstMsgReturn->ullSecurityFlag = 0;

	return GTrue;
}

GBool psrCheckVersion_3( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_3E stSeiVersion_3={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GUInt32 ulDefWid, ulDefHei;
	union{
		GVM_PANO_TYPE_01	stType01;
		GVM_PANO_TYPE_PTV	stTypePTV;
		GVM_PANO_TYPE_PT	stTypePT;
		GUInt64	ullValue;
	}uPanoType64;
	
	stack_memcpy( &stSeiVersion_3, pbySEIInfo, sizeof(PSR_SEI_VER_3E) );

	uPanoType64.ullValue = stSeiVersion_3.ullPanoTypeEx;
	
	if( 0x02 == uPanoType64.stType01.ullDefNo )
	{
		ulDefWid = uPanoType64.stType01.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stType01.ullResRateH / uPanoType64.stType01.ullResRateW;
	}
	else if( 0x03 == uPanoType64.stTypePTV.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTV.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePTV.ullResRateH / uPanoType64.stTypePTV.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTV.ullViewRange_X10 * 10;
	}
	else if( 0x04 == uPanoType64.stTypePT.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePT.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePT.ullResRateH / uPanoType64.stTypePT.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePT.ullViewRange_X10 * 10;
	}
	else goto ERREXT;

	// add by wushao for dome box linkage, 0: box camera, 1: dome camera
	pstMsgReturn->ulStreamChl = stSeiVersion_3.ulStreamChl;

	pstMsgReturn->ulDefWid = ulDefWid;
	pstMsgReturn->ulDefHei = ulDefHei;

	pstMsgReturn->ullPanoTypeEx = stSeiVersion_3.ullPanoTypeEx;

 	pstMsgReturn->fCenterX = ( (GInt32)stSeiVersion_3.ulCenterOffX_2 - 255 ) * 2  + ulDefWid / 2;
 	pstMsgReturn->fCenterY = ( (GInt32)stSeiVersion_3.ulCenterOffY_2 - 255 ) * 2  + ulDefHei / 2;
 	pstMsgReturn->fRadius = stSeiVersion_3.ulRadius_2 * 2;

	pstMsgReturn->fPanoTilt = (GInt32)stSeiVersion_3.ulPanoTilt_90_2 * 2 - 90;
	pstMsgReturn->fPanoTilt =  PW_MIN( pstMsgReturn->fPanoTilt , 90 );
	pstMsgReturn->fPanoTilt =  PW_MAX( pstMsgReturn->fPanoTilt , -90 );
	
	pstMsgReturn->fPanoRotate = stSeiVersion_3.ulPanoRotate_360;

	if( 0 == stSeiVersion_3.ulTimeType )
	{
		pstMsgReturn->ulTimeType = stSeiVersion_3.ulTimeType;
		pstMsgReturn->uTime.stOsd.slTimeOsdWid = PW_GET1_4( stSeiVersion_3.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdHei = PW_GET2_4( stSeiVersion_3.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiX = PW_GET3_4( stSeiVersion_3.ulTimeData ) * 8;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiY = PW_GET4_4( stSeiVersion_3.ulTimeData ) * 8;
	}
	else
	{
		pstMsgReturn->ulTimeType = stSeiVersion_3.ulTimeType;
		pstMsgReturn->uTime.ulTimeValue = stSeiVersion_3.ulTimeData;
	}

	pstMsgReturn->ullSecurityFlag = stSeiVersion_3.ullSecurityFlag;
	pstMsgReturn->pullSecurityFlagPosi = &( ( PSR_SEI_VER_3E*)pbySEIInfo )->ullSecurityFlag;

	pstMsgReturn->fDefaultFPS = stSeiVersion_3.ulDefFPS <= 128 ? 
								stSeiVersion_3.ulDefFPS : 1.0f / ( stSeiVersion_3.ulDefFPS - 128 );
	pstMsgReturn->fCurrentFPS = stSeiVersion_3.ulCurFPS <= 128 ? 
								stSeiVersion_3.ulCurFPS : 1.0f / ( stSeiVersion_3.ulCurFPS - 128 );

	pstMsgReturn->ulINalStart = stSeiVersion_3.byINalStart_8 << 3;
	pstMsgReturn->ulPNalStart = stSeiVersion_3.ulPNalStart_8 << 3;
	pstMsgReturn->usVideoInterSize = stSeiVersion_3.ulVideoInterSize_8 << 3;
	pstMsgReturn->ulSecuDataMaxLen = stSeiVersion_3.bySecuDataMaxLen_64 << 6;
	pstMsgReturn->ulSecurityVer = stSeiVersion_3.ullSecurityVer;
	pstMsgReturn->ulBeUnEncrypt = stSeiVersion_3.ulBeRTSP;
	return GTrue;
ERREXT:
	return GFalse;
}

GBool psrCheckVersion_PT( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_3E stSeiVersion_3={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GBool bVer = GFalse;
	GUInt32 ulDefWid, ulDefHei;
	union{
		GVM_PANO_TYPE_01	stType01;
		GVM_PANO_TYPE_PTV	stTypePTV;
		GVM_PANO_TYPE_PT	stTypePT;
		GVM_PANO_TYPE_ROLLENS stTypePTR;
		GUInt64	ullValue;
	}uPanoType64;
	
	stack_memcpy( &stSeiVersion_3, pbySEIInfo, sizeof(PSR_SEI_VER_3E) );

	uPanoType64.ullValue = stSeiVersion_3.ullPanoTypeEx;

	if( 0x02 == uPanoType64.stType01.ullDefNo )
	{
		ulDefWid = uPanoType64.stType01.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stType01.ullResRateH / uPanoType64.stType01.ullResRateW;
	}
	else if( 0x03 == uPanoType64.stTypePTV.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTV.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePTV.ullResRateH / uPanoType64.stTypePTV.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTV.ullViewRange_X10 * 10;
		bVer = uPanoType64.stTypePTV.ullBeVerSensor;
	}
	else if( 0x04 == uPanoType64.stTypePT.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePT.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePT.ullResRateH / uPanoType64.stTypePT.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePT.ullViewRange_X10  * 10;
		bVer = uPanoType64.stTypePT.ullBeVerSensor;
	}
	else if( 0x05 == uPanoType64.stTypePTR.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTR.ullDefWidth_8 << 3;
		ulDefHei = uPanoType64.stTypePTR.ullDefHeight_8 << 3;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTR.ullViewRange_X10 * 10;
	}
	else goto ERREXT;

	// add by wushao for dome box linkage, 0: box camera, 1: dome camera
	pstMsgReturn->ulStreamChl = stSeiVersion_3.ulStreamChl;

	pstMsgReturn->ulBeVerLens = bVer;
	pstMsgReturn->ulDefWid	= ulDefWid;
	pstMsgReturn->ulDefHei	= ulDefHei;
	pstMsgReturn->ullPanoTypeEx = stSeiVersion_3.ullPanoTypeEx;

 	pstMsgReturn->fCenterX	= ( (GInt32)stSeiVersion_3.ulCenterOffX_2 - 255 ) * 2  + ulDefWid / 2;
 	pstMsgReturn->fCenterY	= ( (GInt32)stSeiVersion_3.ulCenterOffY_2 - 255 ) * 2  + ulDefHei / 2;
 	pstMsgReturn->fRadius	= stSeiVersion_3.ulRadius_2 * 2;

	pstMsgReturn->fPTZPan	= stSeiVersion_3.ullPan_10 * 0.1f;
	pstMsgReturn->fPTZTilt	= stSeiVersion_3.ullTilt_10 * 0.1f - 180;
	pstMsgReturn->fPTZRotate= bVer ? 270 : stSeiVersion_3.ullRotate_10 * 0.1f;
	// if( 0 == stSeiVersion_3.ullZoom_10 ){
	// 	pstMsgReturn->fPTZZoom = 1;
	// 	pstMsgReturn->ulBeMaxZoom = GTrue;
	// }
	// else{
	// 	pstMsgReturn->fPTZZoom = stSeiVersion_3.ullZoom_10 * 0.1f;
	// 	pstMsgReturn->ulBeMaxZoom = stSeiVersion_3.ullZoomStep == stSeiVersion_3.ullZoomMaxStep ? GTrue : GFalse;
	// }
	pstMsgReturn->uForward2.stForward.ullCurZoom_10 = stSeiVersion_3.ullCurZoom_10;
	pstMsgReturn->uForward2.stForward.ullZoomCurSensor = stSeiVersion_3.ullZoomCurSensor;
	pstMsgReturn->uForward2.stForward.ullZoomSensorSum = stSeiVersion_3.ullZoomSensorSum;
	pstMsgReturn->uForward2.stForward.ullZoomExtern = stSeiVersion_3.ullZoomExtern;
	pstMsgReturn->uForward2.stForward.byLensZoom[0] = stSeiVersion_3.byLensZoom[0];
	pstMsgReturn->uForward2.stForward.byLensZoom[1] = stSeiVersion_3.byLensZoom[1];


	pstMsgReturn->fPanoRotate = 0;
	pstMsgReturn->fPanoTilt = (GInt32)stSeiVersion_3.ulPanoTilt_90_2 * 2 - 90;
	pstMsgReturn->fPanoTilt =  PW_MIN( pstMsgReturn->fPanoTilt , 90 );
	pstMsgReturn->fPanoTilt =  PW_MAX( pstMsgReturn->fPanoTilt , -90 );
	pstMsgReturn->ulBeRotated	= stSeiVersion_3.ulBeRotated;

	if( 0 == stSeiVersion_3.ulTimeType )
	{
		pstMsgReturn->ulTimeType = stSeiVersion_3.ulTimeType;
		pstMsgReturn->uTime.stOsd.slTimeOsdWid = PW_GET1_4( stSeiVersion_3.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdHei = PW_GET2_4( stSeiVersion_3.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiX = PW_GET3_4( stSeiVersion_3.ulTimeData ) * 8;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiY = PW_GET4_4( stSeiVersion_3.ulTimeData ) * 8;
	}
	else
	{
		pstMsgReturn->ulTimeType = stSeiVersion_3.ulTimeType;
		pstMsgReturn->uTime.ulTimeValue = stSeiVersion_3.ulTimeData;
	}

	pstMsgReturn->ullSecurityFlag = stSeiVersion_3.ullSecurityFlag;
	pstMsgReturn->pullSecurityFlagPosi = &( ( PSR_SEI_VER_3E*)pbySEIInfo )->ullSecurityFlag;

	pstMsgReturn->fDefaultFPS = stSeiVersion_3.ulDefFPS <= 128 ? 
								stSeiVersion_3.ulDefFPS : 1.0f / ( stSeiVersion_3.ulDefFPS - 128 );
	pstMsgReturn->fCurrentFPS = stSeiVersion_3.ulCurFPS <= 128 ? 
								stSeiVersion_3.ulCurFPS : 1.0f / ( stSeiVersion_3.ulCurFPS - 128 );

	pstMsgReturn->ulINalStart = stSeiVersion_3.byINalStart_8 << 3;
	pstMsgReturn->ulPNalStart = stSeiVersion_3.ulPNalStart_8 << 3;
	pstMsgReturn->usVideoInterSize = stSeiVersion_3.ulVideoInterSize_8 << 3;
	pstMsgReturn->ulSecuDataMaxLen = stSeiVersion_3.bySecuDataMaxLen_64 << 6;
	pstMsgReturn->ulSecurityVer = stSeiVersion_3.ullSecurityVer;
	pstMsgReturn->ulBeUnEncrypt = stSeiVersion_3.ulBeRTSP;
	return GTrue;
ERREXT:
	return GFalse;
}

GBool psrCheckVersion_PU( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_U stSeiVersion_U={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GBool bVer = GFalse;
	GUInt32 ulDefWid, ulDefHei;
	union{
		GVM_PANO_TYPE_01	stType01;
		GVM_PANO_TYPE_PTV	stTypePTV;
		GVM_PANO_TYPE_PT	stTypePT;
		GVM_PANO_TYPE_ROLLENS stTypePTR;
		GUInt64	ullValue;
	}uPanoType64;
	
	stack_memcpy( &stSeiVersion_U, pbySEIInfo, sizeof(PSR_SEI_VER_U) );

	uPanoType64.ullValue = stSeiVersion_U.ullPanoTypeEx;

	if( 0x02 == uPanoType64.stType01.ullDefNo )
	{
		ulDefWid = uPanoType64.stType01.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stType01.ullResRateH / uPanoType64.stType01.ullResRateW;
	}
	else if( 0x03 == uPanoType64.stTypePTV.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTV.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePTV.ullResRateH / uPanoType64.stTypePTV.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTV.ullViewRange_X10 * 10;
		bVer = uPanoType64.stTypePTV.ullBeVerSensor;
	}
	else if( 0x04 == uPanoType64.stTypePT.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePT.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePT.ullResRateH / uPanoType64.stTypePT.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePT.ullViewRange_X10  * 10;
		bVer = uPanoType64.stTypePT.ullBeVerSensor;
	}
	else if( 0x05 == uPanoType64.stTypePTR.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTR.ullDefWidth_8 << 3;
		ulDefHei = uPanoType64.stTypePTR.ullDefHeight_8 << 3;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTR.ullViewRange_X10 * 10;
	}
	else goto ERREXT;

	// add by wushao for dome box linkage, 0: box camera, 1: dome camera
	pstMsgReturn->ulStreamChl = stSeiVersion_U.ulStreamChl;

	pstMsgReturn->ulBeVerLens = bVer;
	pstMsgReturn->ulDefWid	= ulDefWid;
	pstMsgReturn->ulDefHei	= ulDefHei;
	pstMsgReturn->ullPanoTypeEx = stSeiVersion_U.ullPanoTypeEx;

 	pstMsgReturn->fCenterX	= ( (GInt32)stSeiVersion_U.ulCenterOffX_2 - 255 ) * 2  + ulDefWid / 2;
 	pstMsgReturn->fCenterY	= ( (GInt32)stSeiVersion_U.ulCenterOffY_2 - 255 ) * 2  + ulDefHei / 2;
 	pstMsgReturn->fRadius	= stSeiVersion_U.ulRadius_2 * 2;

	pstMsgReturn->fPTZPan	= stSeiVersion_U.ullPan_10 * 0.1f;
	pstMsgReturn->fPTZTilt	= stSeiVersion_U.ullTilt_10 * 0.1f - 180;
	pstMsgReturn->fPTZRotate= bVer ? 270 : stSeiVersion_U.ullRotate_10 * 0.1f;
	if( 0 == stSeiVersion_U.ullZoom_10 ){
		pstMsgReturn->fPTZZoom = 1;
		pstMsgReturn->ulBeMaxZoom = GTrue;
	}
	else{
		pstMsgReturn->fPTZZoom = stSeiVersion_U.ullZoom_10 * 0.1f;
		pstMsgReturn->ulBeMaxZoom = stSeiVersion_U.ullZoomStep == stSeiVersion_U.ullZoomMaxStep ? GTrue : GFalse;
	}

	pstMsgReturn->fPanoRotate = 0;
	pstMsgReturn->fPanoTilt = (GInt32)stSeiVersion_U.ulPanoTilt_90_2 * 2 - 90;
	pstMsgReturn->fPanoTilt =  PW_MIN( pstMsgReturn->fPanoTilt , 90 );
	pstMsgReturn->fPanoTilt =  PW_MAX( pstMsgReturn->fPanoTilt , -90 );
	pstMsgReturn->ulBeRotated	= stSeiVersion_U.ulBeRotated;

	if( 0 == stSeiVersion_U.ulTimeType )
	{
		pstMsgReturn->ulTimeType = stSeiVersion_U.ulTimeType;
		pstMsgReturn->uTime.stOsd.slTimeOsdWid = PW_GET1_4( stSeiVersion_U.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdHei = PW_GET2_4( stSeiVersion_U.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiX = PW_GET3_4( stSeiVersion_U.ulTimeData ) * 8;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiY = PW_GET4_4( stSeiVersion_U.ulTimeData ) * 8;
	}
	else
	{
		pstMsgReturn->ulTimeType = stSeiVersion_U.ulTimeType;
		pstMsgReturn->uTime.ulTimeValue = stSeiVersion_U.ulTimeData;
	}

	pstMsgReturn->ullSecurityFlag = stSeiVersion_U.ullSecurityFlag;
	pstMsgReturn->pullSecurityFlagPosi = &( ( PSR_SEI_VER_3E*)pbySEIInfo )->ullSecurityFlag;

	pstMsgReturn->fDefaultFPS = stSeiVersion_U.ulDefFPS <= 128 ? 
								stSeiVersion_U.ulDefFPS : 1.0f / ( stSeiVersion_U.ulDefFPS - 128 );
	pstMsgReturn->fCurrentFPS = stSeiVersion_U.ulCurFPS <= 128 ? 
								stSeiVersion_U.ulCurFPS : 1.0f / ( stSeiVersion_U.ulCurFPS - 128 );

	pstMsgReturn->ulINalStart = stSeiVersion_U.byINalStart_8 << 3;
	pstMsgReturn->ulPNalStart = stSeiVersion_U.ulPNalStart_8 << 3;
	pstMsgReturn->usVideoInterSize = stSeiVersion_U.ulVideoInterSize_8 << 3;
	pstMsgReturn->ulSecuDataMaxLen = stSeiVersion_U.bySecuDataMaxLen_64 << 6;
	pstMsgReturn->ulSecurityVer = stSeiVersion_U.ullSecurityVer;
	pstMsgReturn->ulBeUnEncrypt = stSeiVersion_U.ulBeRTSP;

	pstMsgReturn->uUnitCfg.stOld.ullPan10		= stSeiVersion_U.ullPan10;
	pstMsgReturn->uUnitCfg.stOld.ullTilt10		= stSeiVersion_U.ullTilt10;
	pstMsgReturn->uUnitCfg.stOld.ullRgtOffX		= stSeiVersion_U.ullRgtOffX;
	pstMsgReturn->uUnitCfg.stOld.ullRgtOffY		= stSeiVersion_U.ullRgtOffY;
	pstMsgReturn->uUnitCfg.stOld.ullRgtOffYMi	= stSeiVersion_U.ullRgtOffYMi;
	pstMsgReturn->uUnitCfg.stOld.ullb4DirMean	= stSeiVersion_U.ullb4DirMean;
	pstMsgReturn->uUnitCfg.stOld.ulDefZ10		= stSeiVersion_U.ulDefZ10;
	pstMsgReturn->uUnitCfg.stOld.fMtrX0			= stSeiVersion_U.fMtrX0;
	pstMsgReturn->uUnitCfg.stOld.fMtrY0			= stSeiVersion_U.fMtrY0;
	pstMsgReturn->uUnitCfg.stOld.fMtrX1Y2		= stSeiVersion_U.fMtrX1Y2;
	pstMsgReturn->uUnitCfg.stOld.fMtrX3Y4		= stSeiVersion_U.fMtrX3Y4;
	pstMsgReturn->uUnitCfg.stOld.fMtrX5			= stSeiVersion_U.fMtrX5;
	pstMsgReturn->uUnitCfg.stOld.fMtrY5			= stSeiVersion_U.fMtrY5;
	pstMsgReturn->uUnitCfg.stOld.ullBe2ndCrt	= stSeiVersion_U.ullBe2ndCrt;
	pstMsgReturn->uUnitCfg.stOld.ulFrmDirect	= stSeiVersion_U.ulFrmDirect;
	pstMsgReturn->uUnitCfg.stOld.ulExtern2		= stSeiVersion_U.ulExtern;

	for ( GInt32 i=0; i<9; i++ ){
		pstMsgReturn->uUnitCfg.stOld.af2ndMtrLft[i] = stSeiVersion_U.af2ndMtrLft[i];
		pstMsgReturn->uUnitCfg.stOld.af2ndMtrRgt[i] = stSeiVersion_U.af2ndMtrRgt[i];
	}
	pstMsgReturn->ulBeUnitArray = GFalse;

	return GTrue;
ERREXT:
	return GFalse;
}

GBool psrCheckVersion_PU2( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_U2 stSeiVersion_U={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GBool bVer = GFalse;
	GUInt32 ulDefWid, ulDefHei;
	union{
		GVM_PANO_TYPE_01	stType01;
		GVM_PANO_TYPE_PTV	stTypePTV;
		GVM_PANO_TYPE_PT	stTypePT;
		GVM_PANO_TYPE_ROLLENS stTypePTR;
		GUInt64	ullValue;
	}uPanoType64;
	
	stack_memcpy( &stSeiVersion_U, pbySEIInfo, sizeof(PSR_SEI_VER_U2) );

	uPanoType64.ullValue = stSeiVersion_U.ullPanoTypeEx;

	if( 0x02 == uPanoType64.stType01.ullDefNo )
	{
		ulDefWid = uPanoType64.stType01.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stType01.ullResRateH / uPanoType64.stType01.ullResRateW;
	}
	else if( 0x03 == uPanoType64.stTypePTV.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTV.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePTV.ullResRateH / uPanoType64.stTypePTV.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTV.ullViewRange_X10 * 10;
		bVer = uPanoType64.stTypePTV.ullBeVerSensor;
	}
	else if( 0x04 == uPanoType64.stTypePT.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePT.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePT.ullResRateH / uPanoType64.stTypePT.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePT.ullViewRange_X10  * 10;
		bVer = uPanoType64.stTypePT.ullBeVerSensor;
	}
	else if( 0x05 == uPanoType64.stTypePTR.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTR.ullDefWidth_8 << 3;
		ulDefHei = uPanoType64.stTypePTR.ullDefHeight_8 << 3;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTR.ullViewRange_X10 * 10;
	}
	else goto ERREXT;

	// add by wushao for dome box linkage, 0: box camera, 1: dome camera
	pstMsgReturn->ulStreamChl = stSeiVersion_U.ulStreamChl;
	pstMsgReturn->uForward.stForward.ulFrmDirect = stSeiVersion_U.ulFrmDirect;

	pstMsgReturn->ulBeVerLens = bVer;
	pstMsgReturn->ulDefWid	= ulDefWid;
	pstMsgReturn->ulDefHei	= ulDefHei;
	pstMsgReturn->ullPanoTypeEx = stSeiVersion_U.ullPanoTypeEx;

 	pstMsgReturn->fCenterX	= ( (GInt32)stSeiVersion_U.ulCenterOffX_2 - 255 ) * 2  + ulDefWid / 2;
 	pstMsgReturn->fCenterY	= ( (GInt32)stSeiVersion_U.ulCenterOffY_2 - 255 ) * 2  + ulDefHei / 2;
 	pstMsgReturn->fRadius	= stSeiVersion_U.ulRadius_2 * 2;

	pstMsgReturn->fPTZPan	= stSeiVersion_U.ullPan_10 * 0.1f;
	pstMsgReturn->fPTZTilt	= stSeiVersion_U.ullTilt_10 * 0.1f - 180;
	pstMsgReturn->fPTZRotate= bVer ? 270 : stSeiVersion_U.ullRotate_10 * 0.1f;
	if( 0 == stSeiVersion_U.ullZoom_10 ){
		pstMsgReturn->fPTZZoom = 1;
		pstMsgReturn->ulBeMaxZoom = GTrue;
	}
	else{
		pstMsgReturn->fPTZZoom = stSeiVersion_U.ullZoom_10 * 0.1f;
		pstMsgReturn->ulBeMaxZoom = stSeiVersion_U.ullZoomStep == stSeiVersion_U.ullZoomMaxStep ? GTrue : GFalse;
	}

	pstMsgReturn->fPanoRotate = 0;
	pstMsgReturn->fPanoTilt = (GInt32)stSeiVersion_U.ulPanoTilt_90_2 * 2 - 90;
	pstMsgReturn->fPanoTilt =  PW_MIN( pstMsgReturn->fPanoTilt , 90 );
	pstMsgReturn->fPanoTilt =  PW_MAX( pstMsgReturn->fPanoTilt , -90 );
	pstMsgReturn->ulBeRotated	= stSeiVersion_U.ulBeRotated;

	if( 0 == stSeiVersion_U.ulTimeType )
	{
		pstMsgReturn->ulTimeType = stSeiVersion_U.ulTimeType;
		pstMsgReturn->uTime.stOsd.slTimeOsdWid = PW_GET1_4( stSeiVersion_U.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdHei = PW_GET2_4( stSeiVersion_U.ulTimeData ) * 4;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiX = PW_GET3_4( stSeiVersion_U.ulTimeData ) * 8;
		pstMsgReturn->uTime.stOsd.slTimeOsdPosiY = PW_GET4_4( stSeiVersion_U.ulTimeData ) * 8;
	}
	else
	{
		pstMsgReturn->ulTimeType = stSeiVersion_U.ulTimeType;
		pstMsgReturn->uTime.ulTimeValue = stSeiVersion_U.ulTimeData;
	}

	pstMsgReturn->ullSecurityFlag = stSeiVersion_U.ullSecurityFlag;
	pstMsgReturn->pullSecurityFlagPosi = &( ( PSR_SEI_VER_3E*)pbySEIInfo )->ullSecurityFlag;

	pstMsgReturn->fDefaultFPS = stSeiVersion_U.ulDefFPS <= 128 ? 
								stSeiVersion_U.ulDefFPS : 1.0f / ( stSeiVersion_U.ulDefFPS - 128 );
	pstMsgReturn->fCurrentFPS = stSeiVersion_U.ulCurFPS <= 128 ? 
								stSeiVersion_U.ulCurFPS : 1.0f / ( stSeiVersion_U.ulCurFPS - 128 );

	pstMsgReturn->ulINalStart = stSeiVersion_U.byINalStart_8 << 3;
	pstMsgReturn->ulPNalStart = stSeiVersion_U.ulPNalStart_8 << 3;
	pstMsgReturn->usVideoInterSize = stSeiVersion_U.ulVideoInterSize_8 << 3;
	pstMsgReturn->ulSecuDataMaxLen = stSeiVersion_U.bySecuDataMaxLen_64 << 6;
	pstMsgReturn->ulSecurityVer = stSeiVersion_U.ullSecurityVer;
	pstMsgReturn->ulBeUnEncrypt = stSeiVersion_U.ulBeRTSP;

	stack_memcpy( pstMsgReturn->uUnitCfg.abyUnitData, stSeiVersion_U.uUnitData.abyUnitData, sizeof(pstMsgReturn->uUnitCfg.abyUnitData) );
	pstMsgReturn->ulBeUnitArray = GTrue;

	return GTrue;
ERREXT:
	return GFalse;
}

GBool psrCheckVersion_RLP( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_RLP stSeiVersion_RLP={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	union{
		PW_TIME		stTime;
		GUInt32		ulTimeValue;
	}uTime;

	stack_memcpy( &stSeiVersion_RLP, pbySEIInfo, sizeof(PSR_SEI_VER_RLP) );

	// add by wushao for dome box linkage, 0: box camera, 1: dome camera
	pstMsgReturn->ulStreamChl = stSeiVersion_RLP.ulStreamChl;

	pstMsgReturn->fPTZPan = stSeiVersion_RLP.ullPan_10 * 0.1f;
	pstMsgReturn->fPTZTilt = stSeiVersion_RLP.ullTilt_10 * 0.1f - 180;
	pstMsgReturn->fPTZRotate = stSeiVersion_RLP.ullRotate_10 * 0.1f;

	// if( 0 == stSeiVersion_RLP.ullZoom_10 ){
	// 	pstMsgReturn->fPTZZoom = 1;
	// 	pstMsgReturn->ulBeMaxZoom = GTrue;
	// }
	// else{
	// 	pstMsgReturn->fPTZZoom = stSeiVersion_RLP.ullZoom_10 * 0.1f;
	// 	pstMsgReturn->ulBeMaxZoom = stSeiVersion_RLP.ullZoomStep == stSeiVersion_RLP.ullZoomMaxStep ? GTrue : GFalse;
	// }
    pstMsgReturn->uForward2.stForward.ullCurZoom_10 = stSeiVersion_RLP.ullCurZoom_10;
	pstMsgReturn->uForward2.stForward.ullZoomCurSensor = stSeiVersion_RLP.ullZoomCurSensor;
	pstMsgReturn->uForward2.stForward.ullZoomExtern = stSeiVersion_RLP.ullZoomExtern;

	uTime.stTime.ulSecond = stSeiVersion_RLP.bySecond;	
	uTime.stTime.ulMinute = stSeiVersion_RLP.byMinute;	
	uTime.stTime.ulHour = 31;	//	0-23 
	uTime.stTime.ulDay = 0; 	//	1-31 
	uTime.stTime.ulMonth = 0; 	//	1-12 
	uTime.stTime.ulYear = 0; 	//	2000-2063
	pstMsgReturn->ulTimeType = 1;
	pstMsgReturn->uTime.ulTimeValue = uTime.ulTimeValue;

	return GTrue;
}
GBool psrCheckVersion_PP( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_P stSeiVersion_P={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	union{
		PW_TIME		stTime;
		GUInt32		ulTimeValue;
	}uTime;

	stack_memcpy( &stSeiVersion_P, pbySEIInfo, sizeof(PSR_SEI_VER_P) );

	pstMsgReturn->fPTZPan = stSeiVersion_P.ulPan_10 * 0.1f;
	pstMsgReturn->fPTZTilt = stSeiVersion_P.ulTilt_10 * 0.1f - 180;

	uTime.stTime.ulSecond = stSeiVersion_P.bySecond;	
	uTime.stTime.ulMinute = stSeiVersion_P.byMinute;	
	uTime.stTime.ulHour = 31;	//	0-23 
	uTime.stTime.ulDay = 0; 	//	1-31 
	uTime.stTime.ulMonth = 0; 	//	1-12 
	uTime.stTime.ulYear = 0; 	//	2000-2063 	

	pstMsgReturn->ulTimeType = 1;
	pstMsgReturn->uTime.ulTimeValue = uTime.ulTimeValue;

	return GTrue;
}

GBool psrCheckVersion_MI( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_MI stSeiVersion_MI={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GBool bVer = GFalse;
	GUInt32 ulDefWid, ulDefHei;
	union{
		GVM_PANO_TYPE_01	stType01;
		GVM_PANO_TYPE_PTV	stTypePTV;
		GVM_PANO_TYPE_PT	stTypePT;
		GVM_PANO_TYPE_ROLLENS stTypePTR;
		GUInt64	ullValue;
	}uPanoType64;

	stack_memcpy( &stSeiVersion_MI, pbySEIInfo, sizeof(PSR_SEI_VER_MI) );

	uPanoType64.ullValue = stSeiVersion_MI.ullPanoTypeEx;

	if( 0x02 == uPanoType64.stType01.ullDefNo )
	{
		ulDefWid = uPanoType64.stType01.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stType01.ullResRateH / uPanoType64.stType01.ullResRateW;
	}
	else if( 0x03 == uPanoType64.stTypePTV.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTV.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePTV.ullResRateH / uPanoType64.stTypePTV.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTV.ullViewRange_X10 * 10;
		bVer = uPanoType64.stTypePTV.ullBeVerSensor;
	}
	else if( 0x04 == uPanoType64.stTypePT.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePT.ullWidth_8 << 3;
		ulDefHei = ulDefWid * uPanoType64.stTypePT.ullResRateH / uPanoType64.stTypePT.ullResRateW;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePT.ullViewRange_X10  * 10;
		bVer = uPanoType64.stTypePT.ullBeVerSensor;
	}
	else if( 0x05 == uPanoType64.stTypePTR.ullDefNo )
	{
		ulDefWid = uPanoType64.stTypePTR.ullDefWidth_8 << 3;
		ulDefHei = uPanoType64.stTypePTR.ullDefHeight_8 << 3;
		pstMsgReturn->usPanRange_100 = uPanoType64.stTypePTR.ullViewRange_X10 * 10;
	}
	else goto ERREXT;

	pstMsgReturn->ulBeVerLens = bVer;
	pstMsgReturn->ulDefWid	= ulDefWid;
	pstMsgReturn->ulDefHei	= ulDefHei;
	pstMsgReturn->ullPanoTypeEx = stSeiVersion_MI.ullPanoTypeEx;

	pstMsgReturn->ulTimeType = 1;
	pstMsgReturn->ullSecurityFlag = stSeiVersion_MI.ullSecurityFlag;
	pstMsgReturn->pullSecurityFlagPosi = &( ( PSR_SEI_VER_MI*)pbySEIInfo )->ullSecurityFlag;

	pstMsgReturn->fCurrentFPS = stSeiVersion_MI.ulCurFPS <= 128 ? 
		stSeiVersion_MI.ulCurFPS : 1.0f / ( stSeiVersion_MI.ulCurFPS - 128 );
	pstMsgReturn->fDefaultFPS = pstMsgReturn->fCurrentFPS;
	pstMsgReturn->ulINalStart = stSeiVersion_MI.byINalStart_8 << 3;
	pstMsgReturn->ulPNalStart = stSeiVersion_MI.ulPNalStart_8 << 3;
	pstMsgReturn->usVideoInterSize = stSeiVersion_MI.ulVideoInterSize_8 << 3;
	pstMsgReturn->ulSecuDataMaxLen = stSeiVersion_MI.bySecuDataMaxLen_64 << 6;
	pstMsgReturn->ulSecurityVer = 1;

	pstMsgReturn->ulMaskWid = stSeiVersion_MI.ulMaskWid;
	pstMsgReturn->ulMaskHei = stSeiVersion_MI.ulMaskHei;
	pstMsgReturn->usVideoWid= stSeiVersion_MI.usVideoWid;
	pstMsgReturn->usVideoHei= stSeiVersion_MI.usVideoHei;
	pstMsgReturn->uTime.stTime.ulYear = stSeiVersion_MI.ulYear - 2000;
	pstMsgReturn->uTime.stTime.ulMonth = stSeiVersion_MI.ulMonth;
	pstMsgReturn->uTime.stTime.ulDay = stSeiVersion_MI.ulDay;
	pstMsgReturn->ulTarNum	= stSeiVersion_MI.ulTarNum;
	pstMsgReturn->usNewTarSec5 = stSeiVersion_MI.usNewTarSec5;
	for( GInt32 i=0; i<7; i++ )
		pstMsgReturn->ausTarSec5[i] = stSeiVersion_MI.ausTarSec5[i];
	pstMsgReturn->ulFrNo	= stSeiVersion_MI.ulFrNo;

	return GTrue;
ERREXT:
	return GFalse;
}

GBool psrCheckVersion_MP( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn )
{
	PSR_SEI_VER_MP stSeiVersion_MP={0};
	GByte *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GInt32 i;
	
	stack_memcpy( &stSeiVersion_MP, pbySEIInfo, sizeof( PSR_SEI_VER_MP ) );

	pstMsgReturn->ulTarNum	= stSeiVersion_MP.byTarNum;
	pstMsgReturn->usNewTarSec5 = stSeiVersion_MP.usNewTarSec5;
	for ( i=0; i<7; i++ )
		pstMsgReturn->ausTarSec5[i] = stSeiVersion_MP.ausTarMinute[i];
	pstMsgReturn->ulFrNo	= stSeiVersion_MP.ulFrNo;
	return GTrue;
}

GBool psrCheckVersion_MS( GUInt8* pbyH264Content, PSR_SEI_MSG* pstMsgReturn, GUInt8* pbyData )
{
	PSR_SEI_VER_MS stSeiVersion_MS={0};
	GUInt8 *pbyCur, *pbySEIInfo = pbyH264Content + PSR_SEI_OFF;
	GInt32 lSeiLen, lTemp;
	
	PW_CHK( ERREXT, pbyData, GNull );
	lSeiLen = pbyH264Content[1];
	lTemp = lSeiLen - sizeof( PSR_SEI_VER_MS );
	stack_memcpy( &stSeiVersion_MS, pbySEIInfo, sizeof( PSR_SEI_VER_MS ) );

	pstMsgReturn->ulPieceNum = stSeiVersion_MS.byPieceNum;
	pstMsgReturn->ulPieceNo = stSeiVersion_MS.byPieceNo;
	pstMsgReturn->ulDatalen = stSeiVersion_MS.byDataLen;
	pstMsgReturn->ulTotalDatalen = (GUInt32)pstMsgReturn->ulPieceNum * lTemp;
	pbyCur = pbySEIInfo +  sizeof( PSR_SEI_VER_MS );
	stack_memcpy( pbyData, pbyCur, stSeiVersion_MS.byDataLen );

	return GTrue;
ERREXT:
	return GFalse;
}

GBool	psrReadSEI( GUInt8* pbyH264Content, PSR_SEI_MSG* pstPwSeiMsg, GUInt8*pbyData )
{
	GBool bRes = GTrue;
	GInt32 lVersion = -1;
	PW_CHK( ERREXT, pbyH264Content, GNull );
	PW_CHK( ERREXT, pstPwSeiMsg, GNull );

//	memset( pstPwSeiMsg, 0, sizeof( GPW_SEI_MSG_V2 ) );
	lVersion = psrCheckLegal( pbyH264Content );
	if( lVersion < 0 )	goto ERREXT;

	pstPwSeiMsg->ulVersion = lVersion;
	
	switch(lVersion)
	{
	case 2:		bRes = psrCheckVersion_2( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GTrue;	break;
	case 3:		bRes = psrCheckVersion_3( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GTrue;	break; // fish eyes I Frame
	case 4:		bRes = psrCheckVersion_PT( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GTrue;	break; // general I Frame
	case 5:		bRes = psrCheckVersion_PP( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GFalse;	break;
	case 7:		bRes = psrCheckVersion_RLP( pbyH264Content, pstPwSeiMsg );pstPwSeiMsg->ulBeIFrame = GFalse;	break;	   // p Frame
	case 8:		bRes = psrCheckVersion_MI( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GTrue;	break;		
	case 9:		bRes = psrCheckVersion_MP( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GFalse;	break;		
	case 10:	bRes = psrCheckVersion_MS( pbyH264Content, pstPwSeiMsg, pbyData );	pstPwSeiMsg->ulBeIFrame = GFalse;	break;		
	case 11:	bRes = psrCheckVersion_PU( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GFalse;	break;
	case 12:	bRes = psrCheckVersion_PU2( pbyH264Content, pstPwSeiMsg );	pstPwSeiMsg->ulBeIFrame = GFalse;	break;
	default:	bRes = GFalse; goto ERREXT;	break;
	}
	if( 2 == pstPwSeiMsg->ulVersion )	pstPwSeiMsg->ulVersion = 3;
	pstPwSeiMsg->ulBePwStream = bRes ? GTrue : GFalse;

	return bRes;
ERREXT:
	return GFalse;
 }