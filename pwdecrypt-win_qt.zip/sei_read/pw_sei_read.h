#ifndef _PW_SEI_READ_H_
#define _PW_SEI_READ_H_

#include "pw_datatype.h"
#include "pw_typedef.h"
#include "pwmacro.h"
#include "pwerror.h"


typedef struct _psr_sei_ver_3e_
{
	/* Byte  0 -- Head & mark */
	GChar	cHead[2];				//	'P3' or 'PT'
	GChar	acExternc[10];
 	/* Byte 12 -- Head flag */
	GUInt32	ulTimeType		:1;
	GUInt32	ulCamRecType	:2;	//	No use
	GUInt32	ullSecurityVer	:3;
	/*-- time difference between IPC and Greenwich, account to minute
		0: Invalid; Real difference = ulTimeDiff - 2000
	--*/
	GUInt32	ulTimeDiff		:14;
	GUInt32	ulBeRTSP		:1;
	GUInt32	ulBeRotated		:1;		//	All ready rotate image by encode
	GUInt32 ulStreamChl		:3;
	GUInt32	ulFlagExtern	:7;
	/* Byte 16 -- Time OSD */
	/*--
		ulTimeType == 0
			ulTimeData -->	GUInt8 byTimeOsdWid_4;		//	OSD width / 4
							GUInt8 byTimeOsdHei_4;		//	OSD height / 4
							GUInt8 byTimeOsdPosiX_8;	//	OSD position--x / 8
							GUInt8 byTimeOsdPosiY_8;	//	OSD position--y / 8
		ulTimeType == 1
			ulTimeData -->	PW_TIME
	--*/
	GUInt32	ulTimeData;	
	/* Byte 20 -- Pano Circle */
	GUInt32 ulCenterOffX_2	:9;		//	0~511	255 + ( CenterX - DefWidth / 2 ) / 2
	GUInt32 ulCenterOffY_2	:9;		//	0~511	255 + ( CenterY - DefHeight / 2 ) / 2
	GUInt32	ulRadius_2		:14;	//	0~16383	Radius / 2
	/* Byte 24 -- Stream security flag */
	GUInt64 ullSecurityFlag;		//	//	Return by PW_STREAM_SECURITY.StreamSecurity
	/* Byte 32 -- PanotyeEx */
	GUInt64 ullPanoTypeEx;	
	/* Byte 40 -- Pano Posture */
	GUInt32	ulPanoTilt_90_2	:7;		//	0~90 : ( PanoTilt(-90~90) + 90 ) / 2
	GUInt32	ulPanoRotate_360:9;		//	0~360 
	GUInt32	ulDefFPS		:8;		//	<=30: frame per second; >30: (ulDefFPS-30)second per frame; =0: illegal
	GUInt32	ulCurFPS		:8;		//	<=30: frame per second; >30: (ulCurFPS-30)second per frame; =0: illegal
	/* Byte 44 -- No use */
	GUInt32 ulNoUsed;
	/* Byte 48 -- PTZ info */
	GUInt64	ullPan_10		:12;		//	0~360 * 10
	GUInt64	ullTilt_10		:12;		//	( -180~180 + 180 ) * 10
	GUInt64	ullRotate_10	:12;		//	0~360 * 10
	// GUInt64	ullZoom_10		:8;			//	fZoom * 10
    GUInt64 ullCurZoom_10 :8;                        /*当前变焦倍数 * 10*/

	GUInt64	ullBePanMoving	:1;	
	GUInt64	ullBeTiltMoving	:1;	
	GUInt64	ullBeRotMovieg	:1;		
	// GUInt64	ullZoomStep		:8;
	// GUInt64	ullZoomMaxStep	:8;
	// GUInt64	ullZooming		:1;
    GUInt64 ullZoomCurSensor : 3; /*当前sensor*/
    GUInt64 ullZoomSensorSum : 3; /*sensor总数*/
    GUInt64 ullZoomExtern : 11;
    /* Byte 56 -- stream block */
	GUInt32	ulPNalStart_8		:6;
	GUInt32	ulVideoInterSize_8	:13;
	GUInt32	ulAudioInterSize_8	:13;
	GUInt8	byINalStart_8;
	GUInt8	bySecuDataMaxLen_64;
	// GUInt8	byTailExtern[2];    
    GUInt8 byLensZoom[2];                                /*各sensor切换时的倍数*/
}PSR_SEI_VER_3E;	//	len = 64 / 0x40

typedef struct _psr_sei_ver_u_
{
	/* Byte  0 -- Head & mark */
	GChar	cHead[2];				//	'PU'
	GChar	acExternc[10];
 	/* Byte 12 -- Head flag */
	GUInt32	ulTimeType		:1;
	GUInt32	ulCamRecType	:2;	//	No use
	GUInt32	ullSecurityVer	:3;
	/*-- time difference between IPC and Greenwich, account to minute
		0: Invalid; Real difference = ulTimeDiff - 2000
	--*/
	GUInt32	ulTimeDiff		:14;
	GUInt32	ulBeRTSP		:1;
	GUInt32	ulBeRotated		:1;		//	All ready rotate image by encode
	GUInt32 ulStreamChl		:3;
	GUInt32	ulFlagExtern	:7;
	/* Byte 16 -- Time OSD */
	/*--
		ulTimeType == 0
			ulTimeData -->	GUInt8 byTimeOsdWid_4;		//	OSD width / 4
							GUInt8 byTimeOsdHei_4;		//	OSD height / 4
							GUInt8 byTimeOsdPosiX_8;	//	OSD position--x / 8
							GUInt8 byTimeOsdPosiY_8;	//	OSD position--y / 8
		ulTimeType == 1
			ulTimeData -->	PW_TIME
	--*/
	GUInt32	ulTimeData;	
	/* Byte 20 -- Pano Circle */
	GUInt32 ulCenterOffX_2	:9;		//	0~511	255 + ( CenterX - DefWidth / 2 ) / 2
	GUInt32 ulCenterOffY_2	:9;		//	0~511	255 + ( CenterY - DefHeight / 2 ) / 2
	GUInt32	ulRadius_2		:14;	//	0~16383	Radius / 2
	/* Byte 24 -- Stream security flag */
	GUInt64 ullSecurityFlag;		//	//	Return by PW_STREAM_SECURITY.StreamSecurity
	/* Byte 32 -- PanotyeEx */
	GUInt64 ullPanoTypeEx;	
	/* Byte 40 -- Pano Posture */
	GUInt32	ulPanoTilt_90_2	:7;		//	0~90 : ( PanoTilt(-90~90) + 90 ) / 2
	GUInt32	ulPanoRotate_360:9;		//	0~360 
	GUInt32	ulDefFPS		:8;		//	<=30: frame per second; >30: (ulDefFPS-30)second per frame; =0: illegal
	GUInt32	ulCurFPS		:8;		//	<=30: frame per second; >30: (ulCurFPS-30)second per frame; =0: illegal
	/* Byte 44 -- No use */
	GUInt32 ulNoUsed;
	/* Byte 48 -- PTZ info */
	GUInt64	ullPan_10		:12;		//	0~360 * 10
	GUInt64	ullTilt_10		:12;		//	( -180~180 + 180 ) * 10
	GUInt64	ullRotate_10	:12;		//	0~360 * 10
	GUInt64	ullZoom_10		:8;			//	fZoom * 10
	GUInt64	ullBePanMoving	:1;	
	GUInt64	ullBeTiltMoving	:1;	
	GUInt64	ullBeRotMovieg	:1;		
	GUInt64	ullZoomStep		:8;
	GUInt64	ullZoomMaxStep	:8;
	GUInt64	ullZooming		:1;
	/* Byte 56 -- stream block */
	GUInt32	ulPNalStart_8		:6;
	GUInt32	ulVideoInterSize_8	:13;
	GUInt32	ulAudioInterSize_8	:13;
	GUInt8	byINalStart_8;
	GUInt8	bySecuDataMaxLen_64;
	GUInt8	byTailExtern[2];
	/* Byte 64 -- stream block */
	GUInt64	ullPan10		:11;	// 镜头水平视场角10倍取整<2000
	GUInt64	ullTilt10		:11;	// 镜头俯仰视场角10倍取整<2000
	GUInt64	ullRgtOffX		:15;	// 右图相对左图偏移量，结果图宽等于sRgtOffX + usArcWid，必>0
	GUInt64	ullRgtOffY		:13;	// 右图相对左图偏移量，结果图高等于usArcHei - |sRgtOffY| * 2
	GUInt64	ullRgtOffYMi	:1;		// 1: RgtOffY < 0, = -ulRgtOffY
	GUInt64	ullb4DirMean	:1;
	GUInt64	ulDefZ10		:7;		// PWPL_DEF_Z [1.0f, 10.0f]最高精确到小数点一位
	GUInt64 ullBe2ndCrt		:1;
	GUInt64 ulFrmDirect		:1;		//左右流标志 0:枪机流左 球机流右 1:球机流左 枪机流右
	GUInt64	ulExtern		:3;
	GFloat	fMtrX0;
	GFloat	fMtrY0;			// 未做Y轴矫正时为0
	GFloat	fMtrX1Y2;
	GFloat	fMtrX3Y4;
	GFloat	fMtrX5;	
	GFloat	fMtrY5;			// 未做Y轴矫正时为0
	GFloat	af2ndMtrLft[9];
	GFloat	af2ndMtrRgt[9];
}PSR_SEI_VER_U;	//	len = 168 / 0xA8

typedef struct _psr_sei_ver_u2_
{
	/* Byte  0 -- Head & mark */
	GChar	cHead[2];				//	'U2'
	GChar	acExternc[10];
 	/* Byte 12 -- Head flag */
	GUInt32	ulTimeType		:1;
	GUInt32	ulCamRecType	:2;	//	No use
	GUInt32	ullSecurityVer	:3;
	/*-- time difference between IPC and Greenwich, account to minute
		0: Invalid; Real difference = ulTimeDiff - 2000
	--*/
	GUInt32	ulTimeDiff		:14;
	GUInt32	ulBeRTSP		:1;
	GUInt32	ulBeRotated		:1;		//	All ready rotate image by encode
	GUInt32 ulStreamChl		:3;
	GUInt32 ulFrmDirect		:1;		//左右流标志 0:枪机流左 球机流右 1:球机流左 枪机流右
	GUInt32	ulFlagExtern	:6;
	/* Byte 16 -- Time OSD */
	/*--
		ulTimeType == 0
			ulTimeData -->	GUInt8 byTimeOsdWid_4;		//	OSD width / 4
							GUInt8 byTimeOsdHei_4;		//	OSD height / 4
							GUInt8 byTimeOsdPosiX_8;	//	OSD position--x / 8
							GUInt8 byTimeOsdPosiY_8;	//	OSD position--y / 8
		ulTimeType == 1
			ulTimeData -->	PW_TIME
	--*/
	GUInt32	ulTimeData;	
	/* Byte 20 -- Pano Circle */
	GUInt32 ulCenterOffX_2	:9;		//	0~511	255 + ( CenterX - DefWidth / 2 ) / 2
	GUInt32 ulCenterOffY_2	:9;		//	0~511	255 + ( CenterY - DefHeight / 2 ) / 2
	GUInt32	ulRadius_2		:14;	//	0~16383	Radius / 2
	/* Byte 24 -- Stream security flag */
	GUInt64 ullSecurityFlag;		//	//	Return by PW_STREAM_SECURITY.StreamSecurity
	/* Byte 32 -- PanotyeEx */
	GUInt64 ullPanoTypeEx;	
	/* Byte 40 -- Pano Posture */
	GUInt32	ulPanoTilt_90_2	:7;		//	0~90 : ( PanoTilt(-90~90) + 90 ) / 2
	GUInt32	ulPanoRotate_360:9;		//	0~360 
	GUInt32	ulDefFPS		:8;		//	<=30: frame per second; >30: (ulDefFPS-30)second per frame; =0: illegal
	GUInt32	ulCurFPS		:8;		//	<=30: frame per second; >30: (ulCurFPS-30)second per frame; =0: illegal
	/* Byte 44 -- No use */
	GUInt32 ulNoUsed;
	/* Byte 48 -- PTZ info */
	GUInt64	ullPan_10		:12;		//	0~360 * 10
	GUInt64	ullTilt_10		:12;		//	( -180~180 + 180 ) * 10
	GUInt64	ullRotate_10	:12;		//	0~360 * 10
	GUInt64	ullZoom_10		:8;			//	fZoom * 10
	GUInt64	ullBePanMoving	:1;	
	GUInt64	ullBeTiltMoving	:1;	
	GUInt64	ullBeRotMovieg	:1;		
	GUInt64	ullZoomStep		:8;
	GUInt64	ullZoomMaxStep	:8;
	GUInt64	ullZooming		:1;
	/* Byte 56 -- stream block */
	GUInt32	ulPNalStart_8		:6;
	GUInt32	ulVideoInterSize_8	:13;
	GUInt32	ulAudioInterSize_8	:13;
	GUInt8	byINalStart_8;
	GUInt8	bySecuDataMaxLen_64;
	GUInt8	byTailExtern[2];
	/* Byte 64 -- stream block */
	union{
		/*-- stInfoV1用于调试，ulType=0 --*/
		struct{	
			GUInt64	ullPan10		:11;	// 镜头水平视场角10倍取整<2000
			GUInt64	ullTilt10		:11;	// 镜头俯仰视场角10倍取整<2000
			GUInt64	ullRgtOffX		:15;	// 右图相对左图偏移量，结果图宽等于sRgtOffX + usArcWid，必>0
			GUInt64	ullRgtOffY		:13;	// 右图相对左图偏移量，结果图高等于usArcHei - |sRgtOffY| * 2
			GUInt64	ullRgtOffYMi	:1;		// 1: RgtOffY < 0, = -ulRgtOffY
			GUInt64	ullb4DirMean	:1;
			GUInt64	ulDefZ10		:7;		// PWPL_DEF_Z [1.0f, 10.0f]最高精确到小数点一位
			GUInt64 ullBe2ndCrt		:1;
			GUInt64	ulType			:4;
			/*-- Byte 8 --*/
			GFloat	fMtrX0;
			GFloat	fMtrY0;			// 未做Y轴矫正时为0
			GFloat	fMtrX1Y2;
			GFloat	fMtrX3Y4;
			GFloat	fMtrX5;
			GFloat	fMtrY5;			// 未做Y轴矫正时为0
			/*-- Byte 32 --*/
			GFloat	af2ndMtrLft[9];
			GFloat	af2ndMtrRgt[9];
			/*-- Byte 104 --*/
			GUInt32	aulExtern[6];
			/*-- Byte 128 --*/
		}stInfoV1;
		/*-- aulData由固件从生产程序获得并写入，APP传给拼接库 --*/
		GUInt8 abyUnitData[128];
	}uUnitData;
}PSR_SEI_VER_U2;	//	len = 192 / 0xC0

typedef struct _psr_ver_p
{
	GChar	cHead[2];		// 	'PP' 
	GUInt8	byMinute;
	GUInt8	bySecond;
	GUInt32	ulPan_10		:12;	//	0~360 * 10
	GUInt32	ulTilt_10		:12;	//	( -180~180 + 180 ) * 10
	GUInt32	ulBePanMovieg	:1;
	GUInt32	ulBeTiltMovieg	:1;
	GUInt32	ulExtern		:6;
}PSR_SEI_VER_P;	//	len = 8 / 0x08

typedef struct _psr_vers_rlp	//	For rotatable lens
{
	GChar	cHead[2];		// 	'PP' 
	GUInt8	byMinute;
	GUInt8	bySecond;
	GUInt32 ulStreamChl		:3;		//	
	GUInt32	ulExtern		:29;
	GUInt64	ullPan_10		:12;	//	0~360 * 10
	GUInt64	ullTilt_10		:12;	//	( -180~180 + 180 ) * 10
	GUInt64	ullBePanMovieg	:1;
	GUInt64	ullBeTiltMovieg	:1;
	GUInt64	ullRotate_10	:12;	//	0~360 * 10
	GUInt64	ullBeRotMovieg	:1;
	// GUInt64	ullZoom_10		:8;		//	fZoom * 10
	// GUInt64	ullZoomStep		:8;
	// GUInt64	ullZoomMaxStep	:8;
	// GUInt64	ullZooming		:1;
    GUInt64        ullCurZoom_10        :8;                        /*当前变焦倍数 * 10*/
    GUInt64        ullZoomCurSensor:3;                        /*当前sensor*/
    GUInt64        ullZoomExtern        :14;
}PSR_SEI_VER_RLP;		//	len = 16 / 0x10

/*-- memento sei --*/
typedef struct _psr_ver_mi_
{
	/*-- Byte 0 --*/
	GChar	cHead[2];				//	'MI'
	GUInt16	usExt0;	
	/*-- Byte 4 --*/
	GUInt32	ulMaskWid		:8;
	GUInt32	ulMaskHei		:8;
	GUInt32	ulCurFPS		:8;		//	<=30: frame per second; >30: (ulDefFPS-30)second per frame; =0: illegal
	GUInt32	ulExt1			:8;
	/*-- Byte 8 --*/
	GUInt64 ullPanoTypeEx;	
	/*-- Byte 16 --*/
	GUInt64 ullSecurityFlag;		//	Return by PW_STREAM_SECURITY.StreamSecurity
	/*-- Byte 24 --*/
	GUInt32	ulPNalStart_8		:6;
	GUInt32	ulVideoInterSize_8	:13;
	GUInt32	ulAudioInterSize_8	:13;
	/*-- Byte 28 --*/
	GUInt8	byINalStart_8;
	GUInt8	bySecuDataMaxLen_64;
	GUInt8	byExt2[2];
	/*-- Byte 32 --*/
	GUInt32	ulYear			:12;
	GUInt32	ulMonth			:4;
	GUInt32	ulDay			:5;	
	GUInt32	ulTarNum		:4;	
	GUInt32	ulExt2			:7;
	/*-- Byte 36 --*/
	GUInt16	ausTarSec5[7];
	GUInt16	usNewTarSec5;
	/*-- Byte 52 --*/
	GUInt16	usVideoWid;
	GUInt16	usVideoHei;
	/*-- Byte 56 --*/
	GUInt32	ulFrNo;
}PSR_SEI_VER_MI;	//	len = 64

typedef struct _psr_ver_ms_
{
	/*-- Byte 0 --*/
	GChar	cHead[2];	//	'MS'
	GUInt8	byPieceNum;
	GUInt8	byPieceNo;
	GUInt8	byDataLen;
	GUInt8	byExt[3];
//	follow this sei head is GUInt8 abyMaskCode...;
}PSR_SEI_VER_MS;	//	len <= 208

typedef struct _psr_ver_mp_	//	For memento 
{
	/*-- Byte 0 --*/
	GChar	cHead[2];				// 	'MP' 
	GUInt8	byTarNum;	
	GUInt8	usExt;	
	/*-- Byte 4 --*/
	GUInt16	ausTarMinute[7];
	GUInt16	usNewTarSec5;
	/*-- Byte 20 --*/
	GUInt32	ulFrNo;
}PSR_SEI_VER_MP;	//	len = 20

/*-- Message return --*/

typedef struct _psr_sei_msg_
{
	GUInt32		ulBePwStream	:1;
	GUInt32		ulVersion		:7;
	GUInt32		ulTimeType		:2;
	GUInt32		ulSecurityVer	:3;
	GUInt32		ulBeUnEncrypt	:1;
	GUInt32		ulBeMaxZoom		:1;
	GUInt32		ulBeVerLens		:1;
	GUInt32		ulBeIFrame		:1;
	GUInt32		ulBeRotated		:1;
	GUInt32     ulStreamChl     :3;
	GUInt32		ulExtern		:11;

	GUInt32		ulINalStart;
	GUInt32		ulPNalStart;
	GUInt32		ulAudioStart;

	GUInt64		ullPanoTypeEx;
	GFloat		fCenterX;
	GFloat		fCenterY;
	GFloat		fRadius;
	GFloat		fPanoPan;
	GFloat		fPanoTilt;
	GFloat		fPanoRotate;
	GFloat		fPTZPan;
	GFloat		fPTZTilt;
	GFloat		fPTZRotate;
	GFloat		fPTZZoom;
	GFloat		fDefaultFPS;
	GFloat		fCurrentFPS;
	GUInt32		ulSeriCode;
	GUInt32		ulSeedOffset;	//	Code seed in I Frame 
	union{
		struct{
			GUInt16		slTimeOsdWid;	
			GUInt16		slTimeOsdHei;	
			GUInt16		slTimeOsdPosiX;	
			GUInt16		slTimeOsdPosiY;	
		}stOsd;
		PW_TIME		stTime;
		GUInt32		ulTimeValue;
	}uTime;

	GUInt64		ullSecurityFlag;
	GUInt64		*pullSecurityFlagPosi;
	GUInt16		usVideoInterSize;
	GUInt16		usAudioInterSize;

	GUInt16		usPanRange_100;		//	0~360 * 100
	GUInt16		usTiltRange_100;	//	( -180~180 + 180 ) * 100
	GUInt32		ulSecuDataMaxLen;
	GUInt8		*pbyDimenPlayerID;
	GUInt32		ulDefWid;
	GUInt32		ulDefHei;
	/*-- Memento SEI --*/
	GUInt16		usVideoWid;
	GUInt16		usVideoHei;

	GUInt32		ulTarNum		:4;
	GUInt32		ulMaskWid		:14;
	GUInt32		ulMaskHei		:14;

	GUInt32		ulPieceNum		:4;
	GUInt32		ulPieceNo		:4;
	GUInt32		ulDatalen		:8;
	GUInt32		ulTotalDatalen	:16;
	GUInt16		ausTarSec5[7];
	GUInt16		usNewTarSec5;
	GUInt32		ulFrNo;
	
	/*-- 拼接用 --*/
	GUInt32		ulBeUnitArray	:1;         //0:老版本, 1:新版本
	GUInt32		ulUnitExtern	:31;
	union{
		struct{
			GUInt64	ullPan10		:11;	// 镜头水平视场角10倍取整<2000
			GUInt64	ullTilt10		:11;	// 镜头俯仰视场角10倍取整<2000
			GUInt64	ullRgtOffX		:15;	// 右图相对左图偏移量，结果图宽等于sRgtOffX + usArcWid，必>0
			GUInt64	ullRgtOffY		:13;	// 右图相对左图偏移量，结果图高等于usArcHei - |sRgtOffY| * 2
			GUInt64	ullRgtOffYMi	:1;		// 1: RgtOffY < 0, = -ulRgtOffY
			GUInt64	ullb4DirMean	:1;
			GUInt64	ulDefZ10		:7;		// PWPL_DEF_Z [1.0f, 10.0f]最高精确到小数点一位
			GUInt64	ullBe2ndCrt		:1;
			GUInt64 ulFrmDirect		:1;		//左右流标志 0:枪机流左 球机流右 1:球机流左 枪机流右
			GUInt64	ulExtern2		:3;
			GFloat	fMtrX0;
			GFloat	fMtrY0;			// 未做Y轴矫正时为0
			GFloat	fMtrX1Y2;
			GFloat	fMtrX3Y4;
			GFloat	fMtrX5;	
			GFloat	fMtrY5;			// 未做Y轴矫正时为0
			GFloat	af2ndMtrLft[9];
			GFloat	af2ndMtrRgt[9];
		}stOld;
		GUInt8	abyUnitData[128];
	}uUnitCfg;

    /* 直接转发给app的参数 */
    union{
        struct{
        	GUInt32 ulFrmDirect	:1;		//左右流标志 0:枪机流左 球机流右 1:球机流左 枪机流右
            GUInt32 ulExtern    :31;
            GUInt32 reserve;
        }stForward;
        GUInt32 ulForward[2];
    }uForward;

    union{
        struct{
            GUInt32 ullCurZoom_10 : 8; /*当前变焦倍数 * 10*/
            GUInt32 ullZoomCurSensor : 3; /*当前sensor*/
            GUInt32 ullZoomSensorSum : 3; /*sensor总数*/
            GUInt32 ullZoomExtern : 11;
            GUInt32 ulExtern : 7;
            GUInt8 byLensZoom[2]; /*各sensor切换时的倍数*/
            GInt16 reserve;
        }stForward;
        GUInt32 ulForward[2];
    }uForward2;
}PSR_SEI_MSG;

/*-- pH264Content Start with 0xf0 , pbyData >= 255--*/
GBool	psrReadSEI( GUInt8* pH264Content, PSR_SEI_MSG* pstPwSeiMsg, GUInt8* pbyData = GNull );

#endif // _PW_SEI_READ_H_