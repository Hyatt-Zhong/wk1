#ifndef _PW_DESECU_H_
#define _PW_DESECU_H_

#include "pw_datatype.h"
#include "pwmacro.h"


enum PDS_RES
{
	PDS_RES_VAL_OK			=0,
	PDS_RES_IGNORE_BY_LV,
	PDS_RES_NEED_DEF_CODE,
	PDS_RES_NEED_CUS_CODE,
	PDS_RES_NEED_TMP_CODE,
	PDS_RES_CODE_DEF_ERR,
	PDS_RES_CODE_CUS_ERR,
	PDS_RES_CODE_TMP_ERR,
	PDS_RES_NOT_INIT,
	PDS_RES_NOT_DATA_ERR,
	PDS_RES_DEF_OLD_OK,
	PDS_RES_NO_CODE			=100,
	PDS_RES_NEED_I_FR,		// 尚未解析到I帧
	PDS_RES_PARSE_V_ERR,	// 解析视频错误
	PDS_RES_I_SEI_ERR,		// 解析I帧SEI错误

};

class PDS_DESECU
{
public:
	PDS_DESECU();
    ~PDS_DESECU();

/*-- 
	szType =		
	"default"		//	device_id默认加密密码
	"default_old"	//	旧mac默认加密密码
	"custom"		//	自定义加密密码
	"temp"			//	临时加密密码
--*/
	GBool	ResetPswd( GChar* szPswd, GChar* szType );
	const GChar*	GetProcCode( GChar* szType );
	PDS_RES	CheckCode( GUInt64 ullSecurityFlag );
	/*-- 解密完整视频帧(含SEI) --*/
	PDS_RES	DeSecurity( GUInt8 *pbyData, GInt32 lDataLen, GBool bReCkEncType = GFalse );
private:
	GHandle m_hEngHdl;
	GBool	m_bGotIFr;
	GUInt64 m_ullSecurityFlag;
	GUInt32 m_ulSecuDataMaxLen;
	GUInt32 m_ulINalStart;
	GUInt32 m_ulPNalStart;
	GUInt32 m_ulVideoInterSize;

	GVoid	_Zero();

};



#endif	//	_PW_DESECU_H_



