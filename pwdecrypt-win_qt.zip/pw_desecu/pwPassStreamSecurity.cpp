

#include "pwPassStreamSecurity_indef.h"
#include "pw_security_encryption.h"
#include "dedes.h"

#define PWSS_ERR_ID	(-1)
#define PWSS_ENG_COUNT	32

typedef struct _pwps_code_packet_
{
	GUInt32	bHaveCode	:1;
	GUInt32 lExtern		:31;
	GChar	strCodePro[24];
	GChar	strFinalCode[44];

	GUInt8	byCustomOffSet[40];	
	VIDEO_SEC_DEDES	cDesClass[8];
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;
}PWPS_CODE_PACKET;

typedef struct _pas_video_se_engine_
{
	GChar	strCurSecLv[16];
	GUInt8	byDefaultOffRate[8];	//	3 5 7 11 13 17 19 23 GUInt64 from 0 in <0 0 0 1>

	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uCurrentFlagInfo;

	PWPS_CODE_PACKET	stCodePackList[SECURITY_CODE_TYPE_COUNT];
}PAS_VIDEO_SE_ENGINE;

// static PAS_VIDEO_SE_ENGINE *g_ppstEngineList[PWSS_ENG_COUNT] = {0};

/*--   --*/
GVoid InitEng( PAS_VIDEO_SE_ENGINE *pstEngine )
{
	PW_STRCPY( pstEngine->strCurSecLv, 8, "no_code" );
	pstEngine->byDefaultOffRate[0] = 3;
	pstEngine->byDefaultOffRate[1] = 5;
	pstEngine->byDefaultOffRate[2] = 7;
	pstEngine->byDefaultOffRate[3] = 11;
	pstEngine->byDefaultOffRate[4] = 13;
	pstEngine->byDefaultOffRate[5] = 17;
	pstEngine->byDefaultOffRate[6] = 19;
	pstEngine->byDefaultOffRate[7] = 23;

	pstEngine->uCurrentFlagInfo.ullValue = 0;
	pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType = SECURITY_CODE_TYPE_NULL;
	pstEngine->uCurrentFlagInfo.stFlagInfo.ullSecurityLv = 0;

	memset( pstEngine->stCodePackList, 0, sizeof(pstEngine->stCodePackList) );	
}

// GInt32 pwss_FindFreeEngine()
// {
// 	GInt32 i, lEngineNo = PWSS_ERR_ID;
// 
// 	for ( i=0; i<PWSS_ENG_COUNT; i++ )
// 	{
// 		if( GNull == g_ppstEngineList[i] ){
// 			lEngineNo = i;
// 			break;
// 		}
// 	}
// 	return lEngineNo;
// }

// PAS_VIDEO_SE_ENGINE* pwss_CreateEngine( GInt32 lEngineNo )
// {
// 	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
// 	if( lEngineNo >= 0 && lEngineNo < PWSS_ENG_COUNT )
// 		pstEngine = g_ppstEngineList[lEngineNo];
// 
// 	if( GNull == pstEngine ){
// 		UNGO( pstEngine, ERREXT, new PAS_VIDEO_SE_ENGINE, GNull );
// 		InitEng( pstEngine );
// 		g_ppstEngineList[lEngineNo] = pstEngine;
// 	}
// 	else	goto ERREXT;
// 
// 	return pstEngine;
// ERREXT:
// 	return GNull;
// }
// 
// PAS_VIDEO_SE_ENGINE* pwss_FindEngine( GInt32 lEngineNo )
// {
// 	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
// 	if( lEngineNo >= 0 && lEngineNo < PWSS_ENG_COUNT )
// 		pstEngine = g_ppstEngineList[lEngineNo];
// 	return pstEngine;
// }
// 
// GBool pwss_DeleteEngine( GInt32 lEngineNo )
// {
// 	if( lEngineNo >= 0 && lEngineNo < PWSS_ENG_COUNT )
// 		PW_DELETE( g_ppstEngineList[lEngineNo] );
// 	return GTrue;
// }

/*--   --*/
PW_PASS_STREAM_SECURITY::PW_PASS_STREAM_SECURITY()
{
// 	m_lhEnineNo = PWSS_ERR_ID;
	m_hEnghdl = GNull;
}

/*--   --*/
PW_PASS_STREAM_SECURITY::~PW_PASS_STREAM_SECURITY()
{
// 	if( GNull != pwss_FindEngine( m_lhEnineNo ) )
// 		pwss_DeleteEngine( m_lhEnineNo );
// 	m_lhEnineNo = PWSS_ERR_ID;
	PAS_VIDEO_SE_ENGINE *pclEng = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_DELETE(pclEng);
	m_hEnghdl = GNull;
}

static GVoid pss_strupr( GChar *pstr )
{
	if( pstr ){
		GChar cVal = *pstr;
		while(cVal){
			if( cVal >= 'a' && cVal <= 'z' )
				cVal += 'A' - 'a';
			*pstr = cVal;
			pstr++;
			cVal = *pstr;
		}
	}
}

static GBool pss_CheckChara( GChar *pstr )
{
	if( pstr ){
		GChar cVal = *pstr;
		while(cVal)
		{
			if( !( cVal >= 'A' && cVal <= 'V' )
				&& 
				!( cVal >= '0' && cVal <= '9' ) )
				goto ERREXT;
			pstr++;
			cVal = *pstr;
		}
	}
	return GTrue;
ERREXT:
	return GFalse;
}

static GUInt32 pss_Code_2_CodePiece( GChar cVal )
{
	if( cVal >= 'A' && cVal <= 'Z' )			return (cVal - 'A' + 10);
	else if( cVal >= '0' && cVal <= '9' )		return (cVal - '0');
	else	return 0;
}
static GChar pss_CodePiece_2_Code( GUInt32 ulVal )
{
	if( ulVal <= 9 )	return (ulVal + '0');
	else				return (ulVal - 10 + 'A');
}

/*-
	第n个 512 块的(lCustomOffRate[n] + lDefaultOffRate[i] * 8) 进行加密 i=0~7
-*/

/*--   --*/
GVoid SeperateFinalCode( PWPS_CODE_PACKET *pstCodePack )
{
	GInt32 i/*, lPackNo = 0*/;

	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	for ( i=0; i<40; i++ )
	{
		GInt32 tt = pstCodePack->strFinalCode[i];
		if( tt >='0' && tt <='9' )		tt = tt - '0';
		else if( tt >='A' && tt <='Z' )	tt = 10 + tt - 'A';
		else							tt = 37;
		pstCodePack->byCustomOffSet[i] = tt;
	}
	for ( i=0; i<8; i++ )
	{
		pstCodePack->cDesClass[i].DES_SetKey( pstCodePack->strFinalCode + ( i << 2 ) );
	}

ERREXT:
	return;
}

/*--   --*/
const GChar* PW_PASS_STREAM_SECURITY::GetCodePro( const GChar *pstrCodeType )
{
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	GInt32 lPackNo = -1;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );

// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );

	if( !strcmp( pstrCodeType, "default" ) )	{
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_DEFAULT);
	}
	else if( !strcmp( pstrCodeType, "custom" ) )	{
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_CUSTOM);
	}
	else if( !strcmp( pstrCodeType, "temp" ) )	{
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_TEMP);
	}
	else{
		if( pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType != SECURITY_CODE_TYPE_NULL )
			lPackNo = PWPS_TYPE_2_PACKNO( pstEngine->uCurrentFlagInfo.stFlagInfo.ullSecurityLv );
	}
	if( lPackNo < 0 )		goto ERREXT;

	pstCodePack = pstEngine->stCodePackList + lPackNo;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	return (const GChar*)pstCodePack->strCodePro;
ERREXT:
	return GNull;
}

/*--   --*/
const GChar* PW_PASS_STREAM_SECURITY::GetCodeType()
{
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );

	if( SECURITY_CODE_TYPE_NULL == pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType )	{
		PW_STRCPY( pstEngine->strCurSecLv, 16, "no_security" );
	}
	else if( SECURITY_CODE_TYPE_DEFAULT == pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType )	{
		PW_STRCPY( pstEngine->strCurSecLv, 16, "default" );
	}
	else if( SECURITY_CODE_TYPE_CUSTOM == pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType )	{
		PW_STRCPY( pstEngine->strCurSecLv, 16, "custom" );
	}
	else if( SECURITY_CODE_TYPE_TEMP == pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType )	{
		PW_STRCPY( pstEngine->strCurSecLv, 16, "temp" );
	}
	else{
		PW_STRCPY( pstEngine->strCurSecLv, 16, "unknown" );
	}

	return (const GChar*)pstEngine->strCurSecLv;
ERREXT:
	return GNull;
}

/*--   --*/
GBool PW_PASS_STREAM_SECURITY::ResetCodeOri(
	const GChar *pstrCodeOri, 
	const GChar *pstrCodeType
	)
{
	GBool bRes = GFalse;
	GInt32 i, lRes = 0, lPackNo = 0;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	GChar strDst[24];
	GChar *pcKey = GNull;

	if( strcmp( pstrCodeType, "no_security" ) && GNull == pstrCodeOri )
		goto ERREXT;

	if( GNull == m_hEnghdl ){
		pstEngine = new PAS_VIDEO_SE_ENGINE;
		PW_CHK( ERREXT, pstEngine, GNull );
		InitEng( pstEngine );
		m_hEnghdl = pstEngine;
	}else
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;

	if( !strcmp( pstrCodeType, "no_security" ) ){
		pstEngine->uCurrentFlagInfo.ullValue = 0;
		pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType = SECURITY_CODE_TYPE_NULL;
		memset( pstEngine->stCodePackList, 0, sizeof(pstEngine->stCodePackList) );	
		bRes = GTrue;
		goto ERREXT;
	}
	else if( !strcmp( pstrCodeType, "default" ) )	{
		pcKey = "default_ori";
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_DEFAULT);
		pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType = SECURITY_CODE_TYPE_DEFAULT;
	}
	else if( !strcmp( pstrCodeType, "custom" ) )	{
		pcKey = "custom_ori";
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_CUSTOM);
		pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType = SECURITY_CODE_TYPE_CUSTOM;
	}
	else if( !strcmp( pstrCodeType, "temp" ) )	{
		pcKey = "temp_ori";
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_TEMP);
		pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType = SECURITY_CODE_TYPE_TEMP;
	}
	else if( !strcmp( pstrCodeType, "default_old" ) )	{
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_DEF_OLD);
		pcKey = (GChar*)"default_ori";
		pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType = SECURITY_CODE_TYPE_DEFAULT;
	}
	else	goto ERREXT;

	pstCodePack = pstEngine->stCodePackList + lPackNo;
	pstCodePack->uFlagInfo.stFlagInfo.ullCodeType = pstEngine->uCurrentFlagInfo.stFlagInfo.ullCodeType;

	GO( lRes, ERREXT, pw_seEncryption( (GChar*)pstrCodeOri, pcKey, pstCodePack->strCodePro, 32 ), 0 );

	GO( bRes, ERREXT, pss_CheckChara( pstCodePack->strCodePro ), GTrue );

	GO( lRes, ERREXT, pw_seEncryption( pstCodePack->strCodePro, "pro_final", pstCodePack->strFinalCode, 32 ), 0 );
	GO( lRes, ERREXT, pw_seEncryption(  pstCodePack->strFinalCode, "extention", strDst, 24 ), 0 );

	for ( i=0; i<20; i++ )
	{
		pstCodePack->strFinalCode[i+20] = strDst[i];
	}
	pstCodePack->strFinalCode[i+20] = 0;

	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_2 = pss_Code_2_CodePiece( pstCodePack->strCodePro[2] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_3 = pss_Code_2_CodePiece( pstCodePack->strCodePro[3] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_5 = pss_Code_2_CodePiece( pstCodePack->strCodePro[5] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_7 = pss_Code_2_CodePiece( pstCodePack->strCodePro[7] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_11 = pss_Code_2_CodePiece( pstCodePack->strCodePro[11] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_13 = pss_Code_2_CodePiece( pstCodePack->strCodePro[13] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_17 = pss_Code_2_CodePiece( pstCodePack->strCodePro[17] );
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePiece_19 = pss_Code_2_CodePiece( pstCodePack->strCodePro[19] );

	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC = 0;
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[0];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[1];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[4];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[6];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[8];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[9];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[10];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[12];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[14];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[15];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[16];
	pstCodePack->uFlagInfo.stFlagInfo.ullProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[18];

// 	pstCodePack->uFlagInfo.stFlagInfo.ulProCodePiece_0 = pss_Code_2_CodePiece( pstCodePack->strCodePro[0] );
// 	pstCodePack->uFlagInfo.stFlagInfo.ulProCodePiece_1 = pss_Code_2_CodePiece( pstCodePack->strCodePro[1] );
// 	pstCodePack->uFlagInfo.stFlagInfo.ulProCodePiece_2 = pss_Code_2_CodePiece( pstCodePack->strCodePro[2] );
// 	pstCodePack->uFlagInfo.stFlagInfo.ulProCodePiece_3 = pss_Code_2_CodePiece( pstCodePack->strCodePro[3] );
// 
// 	for ( i=0, pstCodePack->uFlagInfo.stFlagInfo.ulProCodePieceC=0; i<20; i++ )
// 	{
// 		pstCodePack->uFlagInfo.stFlagInfo.ulProCodePieceC ^= (GUInt8)pstCodePack->strCodePro[i];
// 	}

	pstCodePack->bHaveCode = GTrue;

	pstEngine->uCurrentFlagInfo.ullValue = pstCodePack->uFlagInfo.ullValue;
	SeperateFinalCode( pstCodePack );

	bRes = GTrue;

ERREXT:
	return bRes;
}

/*--   --*/
PWPS_RETURN_VALUE PW_PASS_STREAM_SECURITY::CheckCode( GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eRes = PWPS_RETURN_VAL_OK;
	GInt32 lPackNo = -1;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;

	uFlagInfo.ullValue = ullSecurityFlag;

	eRes = PWPS_RETURN_VAL_NOT_INIT;
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );
	eRes = PWPS_RETURN_VAL_OK;

	eRes = PWPS_RETURN_VAL_OK;
	PW_CHK( ERREXT, uFlagInfo.stFlagInfo.ullCodeType, SECURITY_CODE_TYPE_NULL );

	lPackNo = PWPS_TYPE_2_PACKNO( uFlagInfo.stFlagInfo.ullCodeType );
	pstCodePack = pstEngine->stCodePackList + lPackNo;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_DEF_CODE;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_CUS_CODE;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_TMP_CODE;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_DEF_ERR;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_CUS_ERR;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_TMP_ERR;

	if( ullSecurityFlag != pstCodePack->uFlagInfo.ullValue &&
		SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
	{
		lPackNo = PWPS_TYPE_2_PACKNO( SECURITY_CODE_TYPE_DEF_OLD );
		pstCodePack = pstEngine->stCodePackList + lPackNo;
		pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;
	}

	PW_CHK_N( ERREXT, ullSecurityFlag, pstCodePack->uFlagInfo.ullValue );

	eRes = PWPS_RETURN_VAL_OK;

ERREXT:
	return eRes;
}
/*--   --*/
PWPS_RETURN_VALUE PW_PASS_STREAM_SECURITY::PassStreamSecurity( GUInt8 *pbyStreamData, GInt32 lFrameLen, PWPS_DATA_TYPE eDataType, GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eRes = PWPS_RETURN_VAL_OK;
	GInt32 lBlock = 0, lNo, lPackNo = -1;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;

	uFlagInfo.ullValue = ullSecurityFlag;

	eRes = PWPS_RETURN_VAL_NOT_DATA_ERR;
	if( lFrameLen <= 32 ) goto ERREXT;

	eRes = PWPS_RETURN_VAL_NOT_INIT;
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );
	
	eRes = PWPS_RETURN_VAL_OK;
	PW_CHK( ERREXT, uFlagInfo.stFlagInfo.ullCodeType, SECURITY_CODE_TYPE_NULL );

	lPackNo = PWPS_TYPE_2_PACKNO( uFlagInfo.stFlagInfo.ullCodeType );
	pstCodePack = pstEngine->stCodePackList + lPackNo;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_DEF_CODE;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_CUS_CODE;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_TMP_CODE;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_DEF_ERR;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_CUS_ERR;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_TMP_ERR;

	if( ullSecurityFlag != pstCodePack->uFlagInfo.ullValue &&
		SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
	{
		lPackNo = PWPS_TYPE_2_PACKNO( SECURITY_CODE_TYPE_DEF_OLD );
		pstCodePack = pstEngine->stCodePackList + lPackNo;
		pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;
	}
	PW_CHK_N( ERREXT, ullSecurityFlag, pstCodePack->uFlagInfo.ullValue );

	eRes = PWPS_RETURN_VAL_OK;

	PW_CHK( ERREXT, ( uFlagInfo.stFlagInfo.ullSecurityLv & eDataType ), 0 );


	for( lBlock = 0; (lBlock<<9) < lFrameLen; lBlock++ )
	{
		GInt32 lBlockOff, lOffSet = 0;
		GUInt8 *pbyBlock = pbyStreamData + ( lBlock << 9 );
		lBlockOff = ( lBlock << 9 );
		for ( lNo=0; lNo<8; lNo++ )
		{
			GBool bRes;
			lOffSet = lBlock % 40;
			lOffSet = pstCodePack->byCustomOffSet[lOffSet] << 2;
			lOffSet += pstEngine->byDefaultOffRate[lNo] << 4;

			if( lBlockOff + lOffSet < lFrameLen - 16 )
				bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyBlock + lOffSet, pbyBlock + lOffSet );
		}
	}

	return PWPS_RETURN_VAL_OK;
ERREXT:
	return eRes;
}
PWPS_RETURN_VALUE PW_PASS_STREAM_SECURITY::PassStreamSecurityOneBlock(	PW_STRM_DEC_BLOCK_INFO *pstStreamBlock, 
													  PWPS_DATA_TYPE eDataType, 
													  GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eRes = PWPS_RETURN_VAL_OK;
	GInt32 /*lBlock=0, */lPack=0, lNo, lDataStart=0, lBlockLen=0, lBlockInter;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;
	GBool bRes, bOld=GFalse;

	uFlagInfo.ullValue = ullSecurityFlag;

	eRes = PWPS_RETURN_VAL_NOT_DATA_ERR;
	PW_CHK( ERREXT, pstStreamBlock, GNull );
	PW_CHK( ERREXT, pstStreamBlock->pbyFrameData, GNull );
	if( pstStreamBlock->ulFrameLen <= 32 ) goto ERREXT;

	eRes = PWPS_RETURN_VAL_NOT_INIT;
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );

	eRes = PWPS_RETURN_VAL_OK;
	PW_CHK( ERREXT, uFlagInfo.stFlagInfo.ullCodeType, SECURITY_CODE_TYPE_NULL );

	lPack = PWPS_TYPE_2_PACKNO( uFlagInfo.stFlagInfo.ullCodeType );
	pstCodePack = pstEngine->stCodePackList + lPack;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_DEF_CODE;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_CUS_CODE;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_TMP_CODE;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_DEF_ERR;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_CUS_ERR;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_TMP_ERR;

	if( ullSecurityFlag != pstCodePack->uFlagInfo.ullValue &&
		SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
	{
		lPack = PWPS_TYPE_2_PACKNO( SECURITY_CODE_TYPE_DEF_OLD );
		pstCodePack = pstEngine->stCodePackList + lPack;
		pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;
		bOld = GTrue;
	}

	PW_CHK_N( ERREXT, ullSecurityFlag, pstCodePack->uFlagInfo.ullValue );

	eRes = PWPS_RETURN_VAL_IGNORE_BY_LV;

	PW_CHK( ERREXT, ( uFlagInfo.stFlagInfo.ullSecurityLv & eDataType ), 0 );
	if( PWPS_DATA_TYPE_DATA == eDataType && !( uFlagInfo.stFlagInfo.ullSecurityLv & 0x01ULL ) ) goto ERREXT;
	if( PWPS_DATA_TYPE_I_NAL == eDataType && !( uFlagInfo.stFlagInfo.ullSecurityLv & 0x02ULL ) ) goto ERREXT;
	if( PWPS_DATA_TYPE_P_NAL == eDataType && !( uFlagInfo.stFlagInfo.ullSecurityLv & 0x04ULL ) ) goto ERREXT;
	if( PWPS_DATA_TYPE_AUDIO == eDataType && !( uFlagInfo.stFlagInfo.ullSecurityLv & 0x08ULL ) ) goto ERREXT;

	lDataStart = ( pstStreamBlock->ulDataSrcStart + 15 ) & 0xfffffff0;
	lBlockLen = pstStreamBlock->ulFrameLen - lDataStart;
	lBlockInter = pstStreamBlock->ulBlockInterSize;

	if( PWPS_DATA_TYPE_AUDIO == eDataType )
	{
		lBlockInter += 512;
		for( lPack = 0; lPack * lBlockInter + 64 < lBlockLen; lPack++ )
		{
			GInt32 lBlockOff=0/*, lOffSet=0*/;
			GUInt8 *pbyPack = GNull/*, byTemp*/;

			lBlockOff = lPack * lBlockInter + lDataStart;
			lNo = lPack % 8;
			pbyPack = pstStreamBlock->pbyFrameData + lBlockOff;
			bRes = pstCodePack->cDesClass[0].DES_Decrypt_16( pbyPack, pbyPack );
		}
	}
	else
	{
		lBlockInter += 512;
		for( lPack = 0; lPack * lBlockInter < lBlockLen; lPack++ )
		{
			GInt32 lBlockOff=0, lOffSet=0/*, lTemp*/;
			GUInt8 *pbyPack = GNull;

			lBlockOff = lPack * lBlockInter + lDataStart;
			pbyPack = pstStreamBlock->pbyFrameData + lBlockOff;
			for ( lNo=0; lNo<8; lNo++ )
			{
				lOffSet = pstEngine->byDefaultOffRate[lNo];
				lOffSet <<= 4;
//				lTemp = lPack % 40;
//				lTemp = pstCodePack->byCustomOffSet[lTemp];
//				lOffSet += lTemp << 2;

				if( lOffSet < 480 && lBlockOff + lOffSet < lBlockLen - 16 )
					bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyPack + lOffSet, pbyPack + lOffSet );
			}
		}
	}

	if( bOld )
		return PWPS_RETURN_VAL_DEF_OLD_OK;
	else
		return PWPS_RETURN_VAL_OK;
ERREXT:
	return eRes;
}
/*--   --*/
PWPS_RETURN_VALUE PW_PASS_STREAM_SECURITY::PassStreamSecurityBlock( PW_STRM_DEC_BLOCK_INFO *pstStreamBlock, PWPS_DATA_TYPE eDataType, GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eRes = PWPS_RETURN_VAL_OK;
	GInt32 lBlock = 0, lPack = 0, lNo, lBlockStart, lBlockLen, lDataStart=0, lBlock0Len=0;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	GUInt8 *pbyBlock = GNull;
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;
	GBool bRes;

	uFlagInfo.ullValue = ullSecurityFlag;

	eRes = PWPS_RETURN_VAL_NOT_DATA_ERR;
	PW_CHK( ERREXT, pstStreamBlock, GNull );
	PW_CHK( ERREXT, pstStreamBlock->pbyFrameData, GNull );
	if( pstStreamBlock->ulFrameLen <= 32 ) goto ERREXT;

	eRes = PWPS_RETURN_VAL_NOT_INIT;
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );

	eRes = PWPS_RETURN_VAL_OK;
	PW_CHK( ERREXT, uFlagInfo.stFlagInfo.ullCodeType, SECURITY_CODE_TYPE_NULL );

	lPack = PWPS_TYPE_2_PACKNO( uFlagInfo.stFlagInfo.ullCodeType );
	pstCodePack = pstEngine->stCodePackList + lPack;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_DEF_CODE;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_CUS_CODE;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_TMP_CODE;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_DEF_ERR;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_CUS_ERR;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_TMP_ERR;

	if( ullSecurityFlag != pstCodePack->uFlagInfo.ullValue &&
		SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
	{
		lPack = PWPS_TYPE_2_PACKNO( SECURITY_CODE_TYPE_DEF_OLD );
		pstCodePack = pstEngine->stCodePackList + lPack;
		pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;
	}

	PW_CHK_N( ERREXT, ullSecurityFlag, pstCodePack->uFlagInfo.ullValue );

	eRes = PWPS_RETURN_VAL_OK;

	PW_CHK( ERREXT, ( uFlagInfo.stFlagInfo.ullSecurityLv & eDataType ), 0 );

	lBlock0Len = PW_MIN( pstStreamBlock->ulFrameLen, pstStreamBlock->ulBlockInterSize );
	lDataStart = ( pstStreamBlock->ulDataSrcStart + 15 ) & 0xfffffff0;
	if( pstStreamBlock->ulBeOnlyData )
		lBlock0Len -= lDataStart;

	/*-- BLOCK 0 --*/
	pbyBlock = pstStreamBlock->pbyFrameData;

	for( lPack = 0; (lPack<<9) < lBlock0Len; lPack++ )
	{
		GInt32 lBlockOff = 0, lOffSet = 0;
		GUInt8 *pbyPack = GNull;

		lBlockOff = (lPack << 9) + lDataStart;
		pbyPack = pbyBlock + lBlockOff;
		for ( lNo=0; lNo<8; lNo++ )
		{
			lOffSet = lPack % 40;
			lOffSet = pstCodePack->byCustomOffSet[lOffSet] << 2;
			lOffSet += pstEngine->byDefaultOffRate[lNo] << 4;

			if( lBlockOff + lOffSet < lBlock0Len - 16 )
				bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyPack + lOffSet, pbyPack + lOffSet );
		}
	}
	/*-- BLOCK OTHER --*/

	for ( lBlock=1, lBlockStart=lBlock0Len; lBlockStart < pstStreamBlock->ulFrameLen; 
		lBlock++, lBlockStart += pstStreamBlock->ulBlockInterSize )
	{
		pbyBlock = pstStreamBlock->pbyFrameData + lBlockStart;

		lBlockLen = PW_MIN( pstStreamBlock->ulFrameLen - lBlockStart, pstStreamBlock->ulBlockInterSize );

		for( lPack = 0; (lPack<<9) < lBlockLen; lPack++ )
		{
			GInt32 lBlockOff=0, lOffSet = 0;
			GUInt8 *pbyPack = GNull;

			lBlockOff = lPack << 9;
			pbyPack = pbyBlock + lBlockOff;
			for ( lNo=0; lNo<8; lNo++ )
			{
				lOffSet = ( lPack + lBlock ) % 40;
				lOffSet = pstCodePack->byCustomOffSet[lOffSet] << 2;
				lOffSet += pstEngine->byDefaultOffRate[lNo] << 4;

				if( lBlockOff + lOffSet < lBlockLen - 16 )
					bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyPack + lOffSet, pbyPack + lOffSet );
			}
		}
	}

// 	for( lBlock = 0; (lBlock<<9) < lFrameLen; lBlock++ )
// 	{
// 		GInt32 lBlockOff, lOffSet = 0;
// 		GUInt8 *pbyBlock = pbyStreamData + ( lBlock << 9 );
// 		lBlockOff = ( lBlock << 9 );
// 		for ( lNo=0; lNo<8; lNo++ )
// 		{
// 			lOffSet = lBlock % 40;
// 			lOffSet = pstCodePack->byCustomOffSet[lOffSet] << 2;
// 			lOffSet += pstEngine->byDefaultOffRate[lNo] << 4;
// 
// 			if( lBlockOff + lOffSet < lFrameLen - 16 )
//			bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( (GChar*)(pbyBlock + lOffSet), (GChar*)(pbyBlock + lOffSet) );
// 		}
// 	}

	return PWPS_RETURN_VAL_OK;
ERREXT:
	return eRes;
}
/*--   --*/
PWPS_RETURN_VALUE PW_PASS_STREAM_SECURITY::PassJpgSecurity( GUInt8 *pbyJpgData, GInt32 lBuffLen, GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eRes = PWPS_RETURN_VAL_OK;
	GInt32 lBlock = 0, lNo, lDataLen, lPackNo;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
	GUInt8 *pbyJpgTail = GNull;	//	Point to the byte in front of 0xFFD9
	GUInt8 *pbyTail, byValF, byValB;
	PWPS_CODE_PACKET *pstCodePack = GNull;
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;

	uFlagInfo.ullValue = ullSecurityFlag;

	eRes = PWPS_RETURN_VAL_NOT_DATA_ERR;
	if( lBuffLen <= 128 ) goto ERREXT;

	eRes = PWPS_RETURN_VAL_NOT_INIT;
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );

	eRes = PWPS_RETURN_VAL_OK;
	PW_CHK( ERREXT, uFlagInfo.stFlagInfo.ullCodeType, SECURITY_CODE_TYPE_NULL );

	lPackNo = PWPS_TYPE_2_PACKNO( uFlagInfo.stFlagInfo.ullCodeType );
	pstCodePack = pstEngine->stCodePackList + lPackNo;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_DEF_CODE;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_CUS_CODE;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_TMP_CODE;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_DEF_ERR;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_CUS_ERR;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_TMP_ERR;

	if (ullSecurityFlag != pstCodePack->uFlagInfo.ullValue &&
		SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType) 
	{
		lPackNo = PWPS_TYPE_2_PACKNO(SECURITY_CODE_TYPE_DEF_OLD);
		pstCodePack = pstEngine->stCodePackList + lPackNo;
		pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;
	}

	PW_CHK_N( ERREXT, ullSecurityFlag, pstCodePack->uFlagInfo.ullValue );

	/*-- Find the first 0xffd9 in among the last 128 bytes of jpg-tail --*/
	pbyTail = pbyJpgData + lBuffLen - 1;

	byValB = *pbyTail;	pbyTail--;
	byValF = *pbyTail;	pbyTail--;
	for ( lNo=0; lNo<128; lNo++ )
	{
		if( 0xff == byValF && 0xd9 == byValB )
		{
			pbyJpgTail = pbyTail;
		}
		byValB = byValF;
		byValF = *pbyTail;	pbyTail--;
	}
	PW_CHK( ERREXT, pbyJpgTail, GNull );
	/*--   --*/
	lDataLen = pbyJpgTail - pbyJpgData - 256;

	for( lBlock = 0; (lBlock<<9) < lDataLen; lBlock++ )
	{
		GInt32 lBlockOff, lOffSet = 0;
		GUInt8 *pbyBlock;
		lBlockOff = ( lBlock << 9 ) + 256;
		pbyBlock = pbyJpgData + lBlockOff;
		for ( lNo=0; lNo<8; lNo++ )
		{
			GBool bRes = GFalse;
			lOffSet = lBlock % 40;
			lOffSet = pstCodePack->byCustomOffSet[lOffSet] << 2;
			lOffSet += pstEngine->byDefaultOffRate[lNo] << 4;

			if( lBlockOff + lOffSet < lDataLen - 16 )	//	160 is from 0xFFD8 to 0xFFC0
				bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyBlock - lOffSet, pbyBlock - lOffSet );
		}
	}

	return PWPS_RETURN_VAL_OK;
ERREXT:
	return eRes;
}

PWPS_RETURN_VALUE PW_PASS_STREAM_SECURITY::PassJpgSecurityBlock( PW_JPG_DEC_BLOCK_INFO *pstJpgBlock, GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eRes = PWPS_RETURN_VAL_OK;
	GInt32 /*lBlock=0, */lPack=0, lNo, lBlockLen, lDataStart=0, lJpgLen=0, lBlockInter=0;
	PAS_VIDEO_SE_ENGINE *pstEngine = GNull;
// 	GUInt8 *pbyJpgTail = GNull;	//	Point to the byte in front of 0xFFD9
	PWPS_CODE_PACKET *pstCodePack = GNull;
// 	GUInt8 *pbyBlock = GNull;
// 	GBool bRes;
	union{
		PW_SECURITY_FLAG	stFlagInfo;
		GUInt64				ullValue;
	}uFlagInfo;

	uFlagInfo.ullValue = ullSecurityFlag;

	eRes = PWPS_RETURN_VAL_NOT_DATA_ERR;
	PW_CHK( ERREXT, pstJpgBlock, GNull );
	PW_CHK( ERREXT, pstJpgBlock->pbyFrameData, GNull );
	if( pstJpgBlock->ulFrameLen <= 512 ) goto ERREXT;

	eRes = PWPS_RETURN_VAL_NOT_INIT;
// 	UNGO( pstEngine, ERREXT, pwss_FindEngine( m_lhEnineNo ), GNull );
	pstEngine = (PAS_VIDEO_SE_ENGINE*)m_hEnghdl;
	PW_CHK( ERREXT, pstEngine, GNull );

	eRes = PWPS_RETURN_VAL_OK;
	PW_CHK( ERREXT, uFlagInfo.stFlagInfo.ullCodeType, SECURITY_CODE_TYPE_NULL );

	lPack = PWPS_TYPE_2_PACKNO( uFlagInfo.stFlagInfo.ullCodeType );
	pstCodePack = pstEngine->stCodePackList + lPack;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_DEF_CODE;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_CUS_CODE;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_NEED_TMP_CODE;
	PW_CHK( ERREXT, pstCodePack->bHaveCode, GFalse );

	pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;

	if( SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_DEF_ERR;
	else if( SECURITY_CODE_TYPE_CUSTOM == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_CUS_ERR;
	else if( SECURITY_CODE_TYPE_TEMP == uFlagInfo.stFlagInfo.ullCodeType )
		eRes = PWPS_RETURN_VAL_CODE_TMP_ERR;

	if( ullSecurityFlag != pstCodePack->uFlagInfo.ullValue &&
		SECURITY_CODE_TYPE_DEFAULT == uFlagInfo.stFlagInfo.ullCodeType )
	{
		lPack = PWPS_TYPE_2_PACKNO( SECURITY_CODE_TYPE_DEF_OLD );
		pstCodePack = pstEngine->stCodePackList + lPack;
		pstCodePack->uFlagInfo.stFlagInfo.ullSecurityLv = uFlagInfo.stFlagInfo.ullSecurityLv;
	}

	PW_CHK_N( ERREXT, ullSecurityFlag, pstCodePack->uFlagInfo.ullValue );

	lDataStart = 256;
	lJpgLen = pstJpgBlock->ulFrameLen - pstJpgBlock->ulTailInfoLen - 2;
	lBlockLen = lJpgLen - lDataStart;
	lBlockInter = pstJpgBlock->ulBlockInterSize;
	lBlockInter += 512;

	for( lPack = 0; lPack * lBlockInter < lBlockLen; lPack++ )
	{
		GInt32 lBlockOff = 0, lOffSet = 0;
		GUInt8 *pbyPack = GNull;

		lBlockOff = lPack * lBlockInter + lDataStart;
		pbyPack = pstJpgBlock->pbyFrameData + lBlockOff;
		for ( lNo=0; lNo<8; lNo++ )
		{
			GBool bRes;
			lOffSet = pstEngine->byDefaultOffRate[lNo];
			lOffSet <<= 4;
//			lTemp = lPack % 40;
//			lTemp = pstEngine->byCustomOffSet[lTemp];
//			lOffSet += lTemp << 2;
			if( lBlockOff + lOffSet < lBlockLen - 16 )
				bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyPack + lOffSet, pbyPack + lOffSet );
		}
	}

// 	for ( lBlock=0, lBlockStart=0; lBlockStart < lJpgLen; 
// 		lBlock++, lBlockStart += pstJpgBlock->ulBlockInterSize )
// 	{
// 		pbyBlock = pstJpgBlock->pbyFrameData + lBlockStart;
// 
// 		lBlockLen = PW_MIN( lJpgLen - lBlockStart, pstJpgBlock->ulBlockInterSize );
// 
// 		for( lPack = 0; (lPack<<9) < lBlockLen; lPack++ )
// 		{
// 			GInt32 lBlockOff=0, lOffSet = 0;
// 			GUInt8 *pbyPack = GNull;
// 
// 			lBlockOff = (lPack << 9) + lDataStart;
// 			pbyPack = pbyBlock + lBlockOff;
// 			for ( lNo=0; lNo<8; lNo++ )
// 			{
// 				lOffSet = ( lPack + lBlock ) % 40;
// 				lOffSet = pstCodePack->byCustomOffSet[lOffSet] << 2;
// 				lOffSet += pstEngine->byDefaultOffRate[lNo] << 4;
// 
// 				if( lBlockOff + lOffSet < lBlockLen - 16 )
// 					bRes = pstCodePack->cDesClass[lNo].DES_Decrypt_16( pbyPack + lOffSet, pbyPack + lOffSet );
// 			}
// 		}
// 		lDataStart = 0;
// 	}

	return PWPS_RETURN_VAL_OK;
ERREXT:
	return eRes;

}
