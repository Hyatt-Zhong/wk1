

#ifndef _PW_PASS_VIDEO_SECURITY_H_
#define _PW_PASS_VIDEO_SECURITY_H_

#include "pw_datatype.h"
#include "pw_typedef.h"
#include "pwmacro.h"
#include "pwerror.h"

#ifdef VMDLL_EXPORTS
#define PWPS_API __declspec(dllexport)
#else
#define PWPS_API
#endif

enum PWPS_RETURN_VALUE
{
	PWPS_RETURN_VAL_OK				=0,
	PWPS_RETURN_VAL_IGNORE_BY_LV	,
	PWPS_RETURN_VAL_NEED_DEF_CODE	,
	PWPS_RETURN_VAL_NEED_CUS_CODE	,
	PWPS_RETURN_VAL_NEED_TMP_CODE	,
	PWPS_RETURN_VAL_CODE_DEF_ERR	,
	PWPS_RETURN_VAL_CODE_CUS_ERR	,
	PWPS_RETURN_VAL_CODE_TMP_ERR	,
	PWPS_RETURN_VAL_NOT_INIT		,
	PWPS_RETURN_VAL_NOT_DATA_ERR	,
	PWPS_RETURN_VAL_DEF_OLD_OK		,
	PWPS_RETURN_VAL_NO_CODE			=100,

};

enum PWPS_DATA_TYPE
{
	PWPS_DATA_TYPE_DATA				=0x1,
	PWPS_DATA_TYPE_I_NAL			=0x2,
	PWPS_DATA_TYPE_P_NAL			=0x4,
	PWPS_DATA_TYPE_AUDIO			=0x8,
	PWPS_DATA_TYPE_JPG				=0x10,
};

typedef struct _pw_strm_dec_block_info_
{
	GUInt8 *pbyFrameData;
	GUInt32	ulFrameLen;
	GUInt32	ulBlockInterSize:16;		
	GUInt32	ulDataSrcStart	:10;
	GUInt32	ulBeOnlyData	:1;	//	Without some head
	GUInt32	ulExtern		:5;
}PW_STRM_DEC_BLOCK_INFO;

typedef struct _pw_jpg_dec_block_info_
{
	GUInt8 *pbyFrameData;
	GUInt32	ulFrameLen;
	GUInt32	ulBlockInterSize	:16;		
	GUInt32	ulTailInfoLen		:10;
	GUInt32	ulBeOnlyData		:1;	
	GUInt32	ulExtern			:5;
}PW_JPG_DEC_BLOCK_INFO;

typedef struct PW_PASS_STREAM_SECURITY
{
	PWPS_API PW_PASS_STREAM_SECURITY();
	PWPS_API ~PW_PASS_STREAM_SECURITY();
	/*-- 
			pstrCodeOri		|	pstrCodeType			|	pstrSecurityLv
			<Original code>	|	"default"				|	""
			<Original code>	|	"custom"				|	""
			<Original code>	|	"temp"					|	""
	--*/
	PWPS_API GBool ResetCodeOri( const GChar *pstrCodeOri, const GChar *pstrCodeType );

	PWPS_API const GChar* GetCodeType();
	PWPS_API const GChar* GetCodePro( const GChar *pstrSecurityLv );
	PWPS_API PWPS_RETURN_VALUE CheckCode( GUInt64 ullSecurityFlag );
	PWPS_API PWPS_RETURN_VALUE PassStreamSecurity(	GUInt8 *pbyStreamData, 
													GInt32 lFrameLen, 
													PWPS_DATA_TYPE eDataType, 
													GUInt64 ullSecurityFlag );
	PWPS_API PWPS_RETURN_VALUE PassStreamSecurityBlock(	PW_STRM_DEC_BLOCK_INFO *pstStreamBlock, 
														PWPS_DATA_TYPE eDataType, 
														GUInt64 ullSecurityFlag );
	PWPS_API PWPS_RETURN_VALUE PassStreamSecurityOneBlock(	PW_STRM_DEC_BLOCK_INFO *pstStreamBlock, 
														PWPS_DATA_TYPE eDataType, 
														GUInt64 ullSecurityFlag );
	PWPS_API PWPS_RETURN_VALUE PassJpgSecurity( GUInt8 *pbyJpgData, GInt32 lBuffLen, GUInt64 ullSecurityFlag );
	PWPS_API PWPS_RETURN_VALUE PassJpgSecurityBlock( PW_JPG_DEC_BLOCK_INFO *pstJpgBlock, GUInt64 ullSecurityFlag );

private:
// 	GInt32	m_lhEnineNo;
	GHandle m_hEnghdl;

}*LP_PW_PASS_STREAM_SECURITY;


#endif // _PASS_VIDEO_SECURITY_H_