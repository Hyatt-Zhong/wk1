
#include "pw_desecu.h"
#include "pwPassStreamSecurity.h"
#include "pw_split_video.h"

typedef struct _pds_eng_
{
	PW_PASS_STREAM_SECURITY clPasSecu;

}PDS_ENG;

PDS_DESECU::PDS_DESECU()
{
	m_hEngHdl = new PDS_ENG;
	_Zero();
}

PDS_DESECU::~PDS_DESECU()
{
	PDS_ENG* pstEng = (PDS_ENG*)m_hEngHdl;
	PW_DELETE(pstEng);
}

GVoid PDS_DESECU::_Zero()
{
	m_bGotIFr = GFalse;
	m_ullSecurityFlag	= 0;
	m_ulSecuDataMaxLen	= 0;
	m_ulINalStart		= 0;
	m_ulPNalStart		= 0;
	m_ulVideoInterSize	= 0;
}

GBool	PDS_DESECU::ResetPswd( GChar* szPswd, GChar* szType )
{
	PDS_ENG* pstEng = (PDS_ENG*)m_hEngHdl;
	PW_CHK( ERREXT, pstEng, GNull );

	GOF( ERREXT, pstEng->clPasSecu.ResetCodeOri( szPswd, szType ), GTrue );

	return GTrue;
ERREXT:
	return GFalse;
}

const GChar*	PDS_DESECU::GetProcCode( GChar* szType )
{
	PDS_ENG* pstEng = (PDS_ENG*)m_hEngHdl;
	PW_CHK( ERREXT, pstEng, GNull );

	return pstEng->clPasSecu.GetCodePro( (const GChar*)szType );
ERREXT:
	return GNull;
}

PDS_RES	PDS_DESECU::CheckCode( GUInt64 ullSecurityFlag )
{
	PWPS_RETURN_VALUE eResI;
	PDS_RES eRes = PDS_RES_NOT_INIT;
	PDS_ENG* pstEng = (PDS_ENG*)m_hEngHdl;
	PW_CHK( ERREXT, pstEng, GNull );

	eResI = pstEng->clPasSecu.CheckCode( ullSecurityFlag );
	switch(eResI)
	{
	case PWPS_RETURN_VAL_OK:			eRes = PDS_RES_VAL_OK;			break;
	case PWPS_RETURN_VAL_IGNORE_BY_LV:	eRes = PDS_RES_IGNORE_BY_LV;	break;
	case PWPS_RETURN_VAL_NEED_DEF_CODE:	eRes = PDS_RES_NEED_DEF_CODE;	break;
	case PWPS_RETURN_VAL_NEED_CUS_CODE:	eRes = PDS_RES_NEED_CUS_CODE;	break;
	case PWPS_RETURN_VAL_NEED_TMP_CODE:	eRes = PDS_RES_NEED_TMP_CODE;	break;
	case PWPS_RETURN_VAL_CODE_DEF_ERR:	eRes = PDS_RES_CODE_DEF_ERR;	break;
	case PWPS_RETURN_VAL_CODE_CUS_ERR:	eRes = PDS_RES_CODE_CUS_ERR;	break;
	case PWPS_RETURN_VAL_CODE_TMP_ERR:	eRes = PDS_RES_CODE_TMP_ERR;	break;
	case PWPS_RETURN_VAL_NOT_INIT:		eRes = PDS_RES_NOT_INIT;		break;
	case PWPS_RETURN_VAL_NOT_DATA_ERR:	eRes = PDS_RES_NOT_DATA_ERR;	break;
	case PWPS_RETURN_VAL_DEF_OLD_OK:	eRes = PDS_RES_DEF_OLD_OK;		break;
	case PWPS_RETURN_VAL_NO_CODE:		eRes = PDS_RES_NO_CODE;			break;
	}


	return eRes;
ERREXT:
	return eRes;
}

PDS_RES	PDS_DESECU::DeSecurity( GUInt8 *pbyData, GInt32 lDataLen, GBool bReCkEncType )
{
	PW_STRM_DEC_BLOCK_INFO stBlock ={0};
	PWPS_RETURN_VALUE eResI;
	PSV_VIDEO_NAL stNal={0};
	PWPS_DATA_TYPE eDataType;
	PDS_RES eRes = PDS_RES_NOT_INIT;
	PDS_ENG* pstEng = (PDS_ENG*)m_hEngHdl;
	PW_CHK( ERREXT, pstEng, GNull );

	if( bReCkEncType )	_Zero();

	GOFV( ERREXT, psvSplitVideo( pbyData, lDataLen, &stNal ), GTrue, eRes, PDS_RES_PARSE_V_ERR );
	
	if( !m_bGotIFr ){
		PW_CHK_V( ERREXT, stNal.bIFrame, GFalse, eRes, PDS_RES_NEED_I_FR );
	}
	if( stNal.bIFrame ){
		PSV_SEI_INFO stSei={0};
		GOFV( ERREXT, psvParseSEI( stNal.pbyPWSEI, stNal.lLen_PWSEI, &stSei ), GTrue, eRes, PDS_RES_I_SEI_ERR );
		m_ullSecurityFlag		= stSei.ullSecurityFlag;
		m_ulSecuDataMaxLen		= stSei.ulSecuDataMaxLen;
		m_ulINalStart			= stSei.ullINalStart;
		m_ulPNalStart			= stSei.ullPNalStart;
		m_ulVideoInterSize		= stSei.usVideoInterSize;		
		m_bGotIFr = GTrue;
	}

	stBlock.ulFrameLen = PW_MIN( stNal.lLen_IPNal, m_ulSecuDataMaxLen );
	stBlock.pbyFrameData = stNal.pbyIPNal;
	stBlock.ulBeOnlyData = GTrue;	//	Without some head
	stBlock.ulBlockInterSize = m_ulVideoInterSize;
	if( GTrue == stNal.bIFrame ){
		eDataType = PWPS_DATA_TYPE_I_NAL;
		stBlock.ulDataSrcStart = m_ulINalStart;
	} else{
		eDataType = PWPS_DATA_TYPE_P_NAL;
		stBlock.ulDataSrcStart = m_ulPNalStart;
	}
	if( m_ullSecurityFlag )
		eResI = pstEng->clPasSecu.PassStreamSecurityOneBlock( &stBlock, eDataType, m_ullSecurityFlag );
	else
		eResI = PWPS_RETURN_VAL_OK;
	switch(eResI)
	{
	case PWPS_RETURN_VAL_OK:			eRes = PDS_RES_VAL_OK;			break;
	case PWPS_RETURN_VAL_IGNORE_BY_LV:	eRes = PDS_RES_IGNORE_BY_LV;	break;
	case PWPS_RETURN_VAL_NEED_DEF_CODE:	eRes = PDS_RES_NEED_DEF_CODE;	break;
	case PWPS_RETURN_VAL_NEED_CUS_CODE:	eRes = PDS_RES_NEED_CUS_CODE;	break;
	case PWPS_RETURN_VAL_NEED_TMP_CODE:	eRes = PDS_RES_NEED_TMP_CODE;	break;
	case PWPS_RETURN_VAL_CODE_DEF_ERR:	eRes = PDS_RES_CODE_DEF_ERR;	break;
	case PWPS_RETURN_VAL_CODE_CUS_ERR:	eRes = PDS_RES_CODE_CUS_ERR;	break;
	case PWPS_RETURN_VAL_CODE_TMP_ERR:	eRes = PDS_RES_CODE_TMP_ERR;	break;
	case PWPS_RETURN_VAL_NOT_INIT:		eRes = PDS_RES_NOT_INIT;		break;
	case PWPS_RETURN_VAL_NOT_DATA_ERR:	eRes = PDS_RES_NOT_DATA_ERR;	break;
	case PWPS_RETURN_VAL_DEF_OLD_OK:	eRes = PDS_RES_DEF_OLD_OK;		break;
	case PWPS_RETURN_VAL_NO_CODE:		eRes = PDS_RES_NO_CODE;			break;
	}

	return eRes;
ERREXT:
	return eRes;
}