/*----------------------------------------------------------------------------------------------
*
* This file is Puwell's property. It contains Puwell's trade secret, proprietary and 		
* confidential information. 
* 
* The information and code contained in this file is only for authorized Puwell employees 
* to design, create, modify, or review.
* 
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
* 
* If you are not an intended recipient of this file, you must not copy, distribute, modify, 
* or take any action in reliance on it. 
* 
* If you have received this file in error, please immediately notify Puwell and 
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/

#ifndef _PW_SECURITY_ENCRYPTION_H_
#define _PW_SECURITY_ENCRYPTION_H_

#include "pw_datatype.h"
#include "pw_typedef.h"


GInt32 pw_seEncryption(GChar *pstrSrc, GChar *pstrSeed, GChar *pstrDst, GInt32 lDstBufflen );

#endif // _PW_SECURITY_ENCRYPTION_H_