
#ifndef _DEDES_H_
#define _DEDES_H_

#include "pwPassStreamSecurity_indef.h"

#ifdef __cplusplus
extern "C" {
#endif	

typedef struct VIDEO_SEC_DEDES
{
	GBool DES_SetKey( char *pstrKey_8 );	//	pstrKey_8 must be 8 chars

	GBool DES_Decrypt_8( GUInt8 *pbySrcData, GUInt8 *pbyDstData, GInt32 lSrcLen );

	GBool DES_Decrypt_64( GUInt8 *pbySrcData, GUInt8 *pbyDstData, GInt32 lSrcLen );

	GBool DES_Decrypt_16( GUInt8 *pbySrcData, GUInt8 *pbyDstData );
private:

	GUInt64 m_ullSubKeys_48[16];

	GUInt64 DES_PC1_Transform_64(GUInt64 ullSrc_56 );
	GUInt64 DES_PC2_Transform_64(GUInt64 ullSrc_48 );
	GUInt64 DES_ROL_64( GUInt64 ullData_56, int time );
	GUInt64 DES_SBOX_64( GUInt64 ullData_48 );
	GUInt64 DES_XOR_64(GUInt64 ullDst, GUInt64 ullKey, GInt32 lBitCount );
	GUInt64 DES_Swap_64( GUInt64 ullData );
	GUInt64 DES_IP_Transform_64(GUInt64 ullSrc );
	GUInt64 DES_IP_1_Transform_64(GUInt64 ullSrc );
	GUInt64 DES_E_Transform_64(GUInt64 ullSrc_48 );
	GUInt64 DES_P_Transform_64(GUInt64 ullSrc_32 );
	GInt32 DES_MakeSubKeys_64(GUInt64 ullKey, GUInt64 ullSubKeys_48[16] );

// 	GInt32 DES_EncryptBlock( GByte plainBlock[8], GByte cipherBlock[8], GUInt64 ullSubKeys[16] );
	GInt32 DES_DecryptBlock( GByte cipherBlock[8], GByte plainBlock[8], GUInt64 ullSubKeys[16] );
// 	GUInt64 DES_EncryptBlock( GUInt64 ullSrc, GUInt64 *pullSubKeys_8 );
	GUInt64 DES_DecryptBlock( GUInt64 ullSrc, GUInt64 *pullSubKeys_8 );

	GUInt64	t_ullSrcMask;
	GUInt64 t_ullDstMask;
	GUInt64 t_ullDstMaskComp;
	GUInt64 t_ullTemp_56;
	GUInt64 t_ullVal1_56;
	GUInt64 t_ullVal2_56;


}*LPVIDEO_SEC_DEDES;



#ifdef __cplusplus
}
#endif

#endif // _DEDES_H_